"""
OMNITRIX End-to-End Privacy + ML Pipeline Evaluation Script (Step 56).
Runs synthetic test cases through the production analyze_complaint pipeline with ML enabled.
Verifies privacy boundary enforcement, prediction payload structures, rule-based fallbacks,
risk decision preservation, and safe degradation.
Guarantees zero log dumps of raw text and restores environment config after evaluation.
"""

import os
import json
from typing import Dict, Any, List
from backend.config import ML_ENABLED_ENV
from backend.privacy.analysis_service import analyze_complaint


def run_pipeline_evaluation() -> Dict[str, Any]:
    """
    Executes controlled end-to-end evaluation on synthetic test samples.
    Returns aggregated evaluation results.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    samples_file = os.path.join(base_dir, "ml", "evaluation_samples.json")

    if not os.path.exists(samples_file):
        print(f"ERROR: Synthetic samples file not found: {samples_file}")
        return {}

    with open(samples_file, "r", encoding="utf-8") as f:
        samples = json.load(f)

    # Enable ML transiently for evaluation
    old_ml_env = os.environ.get(ML_ENABLED_ENV, "false")
    os.environ[ML_ENABLED_ENV] = "true"

    privacy_boundary_violations = 0
    emotion_label_counts = {}
    sarcasm_label_counts = {}
    category_results = {}
    mode_counts = {}

    forbidden_markers = ["PRIVATE_TEST_MARKER_OMNITRIX", "John Doe", "Rahul Sharma", "9876543210", "test@univ.edu", "room 404"]

    try:
        for item in samples:
            sample_id = item.get("id")
            category = item.get("category", "Uncategorized")
            raw_text = item.get("text", "")

            # Execute production analysis pipeline
            result = analyze_complaint(raw_text)

            ml_res = result.get("ml_analysis", {})
            fused_res = result.get("fused_analysis", {})
            prelim_res = result.get("preliminary_risk", {})

            # 1. Verify Privacy Boundary
            # Inspect ml_analysis, fused_analysis, preliminary_risk for forbidden markers or raw text
            for key_check in [ml_res, fused_res, prelim_res]:
                check_str = str(key_check)
                for marker in forbidden_markers:
                    if marker in check_str:
                        privacy_boundary_violations += 1
                        print(f"PRIVACY VIOLATION DETECTED in {sample_id} for marker '{marker}'")

            # 2. Record Emotion Predictions
            emo_label = ml_res.get("emotion", {}).get("label", "unknown")
            emotion_label_counts[emo_label] = emotion_label_counts.get(emo_label, 0) + 1

            # 3. Record Sarcasm Predictions
            sarc_label = ml_res.get("sarcasm", {}).get("label", "unknown")
            sarcasm_label_counts[sarc_label] = sarcasm_label_counts.get(sarc_label, 0) + 1

            # 4. Record Analysis Mode
            mode = fused_res.get("analysis_mode", "unknown")
            mode_counts[mode] = mode_counts.get(mode, 0) + 1

            # 5. Track Category Aggregates
            if category not in category_results:
                category_results[category] = {
                    "count": 0,
                    "avg_risk_score": 0.0,
                    "risk_levels": {}
                }
            
            cat_stats = category_results[category]
            cat_stats["count"] += 1
            cat_stats["avg_risk_score"] += prelim_res.get("risk_score", 0)
            r_level = prelim_res.get("risk_level", "low")
            cat_stats["risk_levels"][r_level] = cat_stats["risk_levels"].get(r_level, 0) + 1

        # Average category risk scores
        for cat, stat in category_results.items():
            if stat["count"] > 0:
                stat["avg_risk_score"] = round(stat["avg_risk_score"] / stat["count"], 1)

        summary = {
            "total_samples": len(samples),
            "privacy_boundary_violations": privacy_boundary_violations,
            "privacy_boundary_passed": (privacy_boundary_violations == 0),
            "analysis_modes": mode_counts,
            "emotion_predictions": emotion_label_counts,
            "sarcasm_predictions": sarcasm_label_counts,
            "category_summary": category_results,
            "ml_status": "available" if any(k != "unknown" for k in emotion_label_counts) else "not_loaded"
        }

    finally:
        # Restore environment config
        os.environ[ML_ENABLED_ENV] = old_ml_env

    return summary


if __name__ == "__main__":
    res = run_pipeline_evaluation()
    print(json.dumps(res, indent=2))
