# OMNITRIX NLP Dataset & Model Feasibility Audit (Step 54)

## Executive Summary

This offline audit evaluates all local NLP datasets available in `backend/ml/data/` to determine their technical feasibility for training lightweight, low-RAM machine learning classifiers for OMNITRIX.

> [!IMPORTANT]
> **Audit Status**:
> - **Zero Model Training / Downloads**: No models were trained, fine-tuned, or downloaded during this step.
> - **Supported Tasks**: Supervised **Emotion Classification** (10 classes) and **Sarcasm Detection** (binary) are fully supported by existing datasets.
> - **Unsupported Tasks**: Supervised **Coded Distress Classification** and **Language Classification** are **NOT supported** because no datasets with these explicit target labels currently exist.
> - **Recommended Architecture**: Lightweight TF-IDF (word + char n-grams) + Logistic Regression / LinearSVC.

---

## 1. Dataset Inventory & Structural Metrics

| Dataset Identifier | Path | Format | Rows | Text Column | Label Column | Unique Labels | Text Length (Mean / Median) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`emotion_raw`** | `backend/ml/data/raw/emotion_hinghlish_dataset.xlsx` | Excel (`.xlsx`) | 25,688 | `text` | `emotion` | 10 | 84.9 / 81.0 chars |
| **`sarcasm_raw`** | `backend/ml/data/raw/sarcasm_hinghlish_dataset.csv` | CSV (`.csv`) | 9,593 | `text` | `label` | 2 | 77.1 / 71.0 chars |
| **`mlt_raw`** | `backend/ml/data/raw/mlt_hinghlish_dataset.csv` | CSV (`.csv`) | 30,000 | `hinglish_genz_text` | `label` | 10 | 77.5 / 74.0 chars |
| **`train_processed`**| `backend/ml/data/processed/train.csv` | CSV (`.csv`) | 20,548 | `text` | `label` | 10 | 85.0 / 81.0 chars |
| **`val_processed`** | `backend/ml/data/processed/val.csv` | CSV (`.csv`) | 2,569 | `text` | `label` | 10 | 85.6 / 82.0 chars |
| **`test_processed`** | `backend/ml/data/processed/test.csv` | CSV (`.csv`) | 2,569 | `text` | `label` | 10 | 83.7 / 80.0 chars |

---

## 2. Quality, Nulls, Duplicates, and Leakage Analysis

### Null & Empty Text Counts
- `emotion_raw`: 2 null text rows, 2 empty texts.
- `sarcasm_raw`: 0 nulls, 0 empty texts.
- `mlt_raw`: 0 nulls, 0 empty texts.
- Processed splits (`train`, `val`, `test`): 0 nulls, 0 empty texts.

### Duplicate Text Counts
- `emotion_raw`: 1 duplicate text.
- `sarcasm_raw`: 630 duplicate texts (6.6% of dataset).
- `mlt_raw`: 4,492 duplicate texts (15.0% of dataset).
- Processed splits (`train`, `val`, `test`): 0 duplicates within any split.

### Data Leakage Analysis across Processed Splits
- **Train vs. Validation Overlap**: 0 overlapping texts.
- **Train vs. Test Overlap**: 0 overlapping texts.
- **Validation vs. Test Overlap**: 0 overlapping texts.
- **Split Quality**: Clean 80 / 10 / 10 split of `emotion_hinghlish_dataset.xlsx` (20,548 / 2,569 / 2,569) with **zero data leakage**.

---

## 3. Class Distributions

### A. Emotion Classification (`emotion_raw` / `train_processed`)
- `admiration`: 3,018 (11.7%) [Train: 2,414]
- `disapproval`: 3,018 (11.7%) [Train: 2,414]
- `neutral`: 3,018 (11.7%) [Train: 2,414]
- `joy`: 2,898 (11.3%) [Train: 2,318]
- `anger`: 2,896 (11.3%) [Train: 2,317]
- `sadness`: 2,892 (11.3%) [Train: 2,313]
- `love`: 2,650 (10.3%) [Train: 2,120]
- `fear`: 1,984 (7.7%) [Train: 1,587]
- `surprise`: 1,689 (6.6%) [Train: 1,351]
- `disgust`: 1,625 (6.3%) [Train: 1,300]

### B. Sarcasm Detection (`sarcasm_raw`)
- `1` (Sarcastic): 5,544 (57.8%)
- `0` (Non-sarcastic): 4,049 (42.2%)

### C. MLT Dataset Inspection (`mlt_raw`)
- Inspection reveals `mlt_hinghlish_dataset.csv` contains 30,000 synthetic Hinglish/Gen-Z text rows.
- Labels are **exactly the 10 emotion categories** (3,000 rows per class): `anger`, `joy`, `love`, `disgust`, `fear`, `sadness`, `admiration`, `surprise`, `disapproval`, `neutral`.
- **Finding**: "MLT" does NOT stand for multi-language or coded-distress task labels; it is an augmented Hinglish Gen-Z emotion dataset.

---

## 4. Mapping Datasets to OMNITRIX Tasks

| OMNITRIX Task | Supervised Dataset | Target Column | Classes | Feasibility Status |
| :--- | :--- | :--- | :--- | :--- |
| **Emotion Classification** | `train.csv` / `emotion_hinghlish_dataset.xlsx` | `emotion` / `label` | 10 classes | **FEASIBLE** |
| **Sarcasm Detection** | `sarcasm_hinghlish_dataset.csv` | `label` | Binary (0 / 1) | **FEASIBLE** |
| **Coded Distress Classification**| None | N/A | N/A | **NOT SUPPORTED** *(Must use rule-based `sarcasm_signals.py`)* |
| **Language Classification** | None | N/A | N/A | **NOT SUPPORTED** *(Must use heuristic `representation.py`)* |

---

## 5. Dependency Audit

| Package | Status | Notes |
| :--- | :--- | :--- |
| **`pandas`** | **INSTALLED** | Version 2.2.2 available in primary runtime environment |
| **`openpyxl`** | **INSTALLED** | Version 3.1.5 available for `.xlsx` loading |
| **`numpy`** | **INSTALLED** | Version 1.26.4 available |
| **`scikit-learn`** | **MISSING** | Missing in local environment; required for future TF-IDF training |
| **`joblib`** | **MISSING** | Missing in local environment; required for model serialization |

*(Per guidelines, missing dependencies are reported without auto-installation).*

---

## 6. Recommended Lightweight Model Architecture

For an 8 GB RAM laptop target, heavy Transformer fine-tuning (e.g. BERT/MuRIL ~1 GB) is unnecessary when lightweight classical models yield fast, explainable results:

1. **Feature Extractor**:
   - `TfidfVectorizer` (ngram_range=(1, 3), sublinear_tf=True, max_features=15000, char_wb n-grams)
2. **Classifiers**:
   - `LogisticRegression(C=1.0, max_iter=500)` or `LinearSVC(C=1.0)`
3. **Performance Metrics**:
   - RAM usage: < 80 MB
   - Training time: < 3 seconds
   - Inference latency: < 1 ms per text sample
   - Fully offline execution and simple `joblib` model serialization.

---

## 7. Future Model Architecture & Training Order

When model training is requested in a future step, the recommended training sequence is:

1. **`EmotionClassifier`**: Train TF-IDF + LogisticRegression on `train.csv`, evaluate on `val.csv` and `test.csv`.
2. **`SarcasmClassifier`**: Deduplicate and split `sarcasm_hinghlish_dataset.csv`, train TF-IDF + LogisticRegression.
3. **`CodedDistressClassifier` & `LanguageClassifier`**: Maintain safe rule-based heuristic fallbacks (`sarcasm_signals.py` & `representation.py`).
