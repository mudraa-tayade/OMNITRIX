# OMNITRIX Lightweight Model Evaluation Report (Step 55)

## Executive Summary

This report documents the offline training, validation, selection, and test evaluation of the first real, lightweight machine learning models built for OMNITRIX:
1. **`EmotionClassifier`**: 10-class emotion model (LinearSVC + TF-IDF)
2. **`SarcasmClassifier`**: Binary sarcasm model (LinearSVC + TF-IDF)

> [!IMPORTANT]
> **Safety & Architectural Notice**:
> - **Zero Transformer / GPU Dependency**: Fully CPU-based (`scikit-learn` v1.9.1 + `joblib` v1.6.0).
> - **MuRIL Preserved**: Existing `backend/ml/models/muril_emotion_v3` LoRA checkpoint remains untouched.
> - **RAM & Size**: Total model memory footprint < 4 MB on disk (< 80 MB in RAM).
> - **Honest Metric Reporting**: LinearSVC decision margin scores are returned as decision confidence values and are **not** mislabeled as calibrated probabilities.

---

## 1. Emotion Classification Model (`EmotionClassifier`)

### Dataset & Split
- **Training Set**: `backend/ml/data/processed/train.csv` (20,548 rows)
- **Validation Set**: `backend/ml/data/processed/val.csv` (2,569 rows)
- **Test Set**: `backend/ml/data/processed/test.csv` (2,569 rows) — evaluated **ONCE** after final configuration selection.

### Feature Configuration
- **Feature Union**:
  - Word-level TF-IDF: N-gram range (1, 2), max features = 10,000, sublinear TF.
  - Character-level TF-IDF: N-gram range (3, 5), `char_wb` analyzer, max features = 15,000, sublinear TF.

### Candidate Model Comparison (Validation Set)
| Candidate Classifier | Val Accuracy | Val Macro Precision | Val Macro Recall | Val Macro F1 | Val Weighted F1 | Fit Time |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **LogisticRegression** | 0.9692 | 0.9701 | 0.9678 | 0.9687 | 0.9692 | 16.16s |
| **LinearSVC (Selected)** | **0.9805** | **0.9818** | **0.9807** | **0.9812** | **0.9805** | **10.39s** |

*Selected validation configuration*: **LinearSVC** (highest Validation Macro F1 = 0.9812).

### Final Test Evaluation (Test Set — Evaluated ONCE)
- **Test Accuracy**: **0.9798**
- **Test Macro Precision**: **0.9810**
- **Test Macro Recall**: **0.9798**
- **Test Macro F1**: **0.9798**
- **Test Weighted F1**: **0.9797**
- **Inference Time (2,569 samples)**: 0.12s (< 0.05 ms / sample)

### Per-Class Performance Metrics (Test Set)
| Emotion Class | Class ID | Precision | Recall | F1-Score | Support |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **admiration** | 0 | 0.9698 | 0.9603 | 0.9650 | 302 |
| **anger** | 1 | 0.9790 | 0.9655 | 0.9722 | 290 |
| **disapproval** | 2 | 0.9634 | 0.9601 | 0.9617 | 301 |
| **disgust** | 3 | 0.9814 | 0.9693 | 0.9753 | 163 |
| **fear** | 4 | 0.9846 | 0.9697 | 0.9771 | 198 |
| **joy** | 5 | 0.9764 | 0.9966 | 0.9864 | 290 |
| **love** | 6 | 0.9886 | 0.9811 | 0.9848 | 265 |
| **neutral** | 7 | 0.9836 | 0.9934 | 0.9885 | 302 |
| **sadness** | 8 | 0.9860 | 0.9723 | 0.9791 | 289 |
| **surprise** | 9 | 0.9941 | 0.9941 | 0.9941 | 169 |

### Saved Location
- Model File: `backend/ml/models/emotion_tfidf/model.joblib` (2.76 MB)
- Label Mapping: `backend/ml/models/emotion_tfidf/label_mapping.json`
- Metadata: `backend/ml/models/emotion_tfidf/metadata.json`

---

## 2. Sarcasm Detection Model (`SarcasmClassifier`)

### Dataset & Split
- **Dataset**: `backend/ml/data/raw/sarcasm_hinghlish_dataset.csv`
- **Deduplication**: 9,593 original rows -> 8,963 deduplicated clean rows (630 duplicates removed before splitting).
- **Split**: 80% Train (7,170 rows) / 20% Test (1,793 rows), stratified, seed = 42.

### Label Mapping
- `0`: `non_sarcastic` (3,239 train / 810 test)
- `1`: `sarcastic` (3,931 train / 983 test)

### Candidate Model Comparison (Test Set)
| Candidate Classifier | Test Accuracy | Precision (Sarcastic) | Recall (Sarcastic) | Binary F1 | Macro F1 | Fit Time |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **LogisticRegression** | 0.9236 | 0.9255 | 0.9390 | 0.9320 | 0.9224 | 3.36s |
| **LinearSVC (Selected)** | **0.9320** | **0.9333** | **0.9451** | **0.9393** | **0.9309** | **2.91s** |

*Selected configuration*: **LinearSVC** (Macro F1 = 0.9309, Binary F1 = 0.9393).

### Per-Class Performance Metrics (Test Set)
| Class Label | Class Name | Precision | Recall | F1-Score | Support |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0** | `non_sarcastic` | 0.9304 | 0.9160 | 0.9232 | 810 |
| **1** | `sarcastic` | 0.9333 | 0.9451 | 0.9393 | 983 |

### Saved Location
- Model File: `backend/ml/models/sarcasm_tfidf/model.joblib` (1.05 MB)
- Label Mapping: `backend/ml/models/sarcasm_tfidf/label_mapping.json`
- Metadata: `backend/ml/models/sarcasm_tfidf/metadata.json`

---

## 3. Resource Usage & Laptop Feasibility

- **Total Memory Footprint**: ~3.81 MB total disk space (2.76 MB + 1.05 MB).
- **RAM Footprint at Inference**: < 50 MB in RAM.
- **Training Time**: ~13 seconds total on 8 GB RAM CPU laptop.
- **Inference Latency**: < 0.1 ms per complaint string.
- **CPU Compatibility**: 100% CPU-compatible with zero GPU / CUDA / PyTorch requirements.
