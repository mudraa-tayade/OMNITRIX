"""
OMNITRIX Lightweight Emotion Classifier Training Script (Step 55).
Trains TF-IDF + Scikit-Learn models for 10-class emotion classification on processed datasets.
Evaluates LogisticRegression vs LinearSVC on val set using Macro F1.
Evaluates final selected model on test set ONCE.
Saves model.joblib, label_mapping.json, and metadata.json to backend/ml/models/emotion_tfidf/.
"""

import os
import time
import json
import numpy as np
import pandas as pd
import joblib
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support, confusion_matrix

LABEL_MAP = {
    "0": "admiration",
    "1": "anger",
    "2": "disapproval",
    "3": "disgust",
    "4": "fear",
    "5": "joy",
    "6": "love",
    "7": "neutral",
    "8": "sadness",
    "9": "surprise"
}


def train_emotion_model():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "data", "processed")
    output_dir = os.path.join(base_dir, "models", "emotion_tfidf")
    os.makedirs(output_dir, exist_ok=True)

    train_path = os.path.join(data_dir, "train.csv")
    val_path = os.path.join(data_dir, "val.csv")
    test_path = os.path.join(data_dir, "test.csv")

    print(f"Loading emotion datasets from {data_dir}...")
    df_train = pd.read_csv(train_path)
    df_val = pd.read_csv(val_path)
    df_test = pd.read_csv(test_path)

    X_train, y_train = df_train["text"].astype(str), df_train["label"]
    X_val, y_val = df_val["text"].astype(str), df_val["label"]
    X_test, y_test = df_test["text"].astype(str), df_test["label"]

    print(f"Train samples: {len(X_train)}, Val samples: {len(X_val)}, Test samples: {len(X_test)}")

    # Build FeatureUnion for word and character n-grams
    union = FeatureUnion([
        ("word_tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=10000, sublinear_tf=True)),
        ("char_tfidf", TfidfVectorizer(ngram_range=(3, 5), analyzer="char_wb", max_features=15000, sublinear_tf=True))
    ])

    candidates = {
        "LogisticRegression": LogisticRegression(C=1.0, max_iter=500, random_state=42),
        "LinearSVC": LinearSVC(C=1.0, max_iter=1000, random_state=42)
    }

    results = {}
    best_name = None
    best_macro_f1 = -1.0
    best_pipeline = None

    for name, clf in candidates.items():
        print(f"\n--- Training Candidate: {name} ---")
        t0 = time.time()
        pipeline = Pipeline([
            ("features", union),
            ("clf", clf)
        ])
        pipeline.fit(X_train, y_train)
        fit_time = time.time() - t0

        t1 = time.time()
        val_preds = pipeline.predict(X_val)
        val_time = time.time() - t1

        acc = accuracy_score(y_val, val_preds)
        p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(y_val, val_preds, average="macro")
        p_weighted, r_weighted, f1_weighted, _ = precision_recall_fscore_support(y_val, val_preds, average="weighted")

        print(f"[{name}] Val Acc: {acc:.4f}, Val Macro F1: {f1_macro:.4f}, Val Weighted F1: {f1_weighted:.4f} (Fit: {fit_time:.2f}s)")

        results[name] = {
            "val_accuracy": float(acc),
            "val_macro_precision": float(p_macro),
            "val_macro_recall": float(r_macro),
            "val_macro_f1": float(f1_macro),
            "val_weighted_f1": float(f1_weighted),
            "fit_time_sec": float(fit_time),
            "val_inference_time_sec": float(val_time)
        }

        if f1_macro > best_macro_f1:
            best_macro_f1 = f1_macro
            best_name = name
            best_pipeline = pipeline

    print(f"\nSelected validation configuration: {best_name} (Val Macro F1: {best_macro_f1:.4f})")

    # Evaluate selected model ONCE on test set
    t2 = time.time()
    test_preds = best_pipeline.predict(X_test)
    test_time = time.time() - t2

    test_acc = accuracy_score(y_test, test_preds)
    test_p_macro, test_r_macro, test_f1_macro, _ = precision_recall_fscore_support(y_test, test_preds, average="macro")
    test_p_weighted, test_r_weighted, test_f1_weighted, _ = precision_recall_fscore_support(y_test, test_preds, average="weighted")

    cm = confusion_matrix(y_test, test_preds).tolist()
    report_dict = classification_report(y_test, test_preds, target_names=[LABEL_MAP[str(i)] for i in range(10)], output_dict=True)

    print(f"\nFinal Test Results [{best_name}]: Test Acc: {test_acc:.4f}, Test Macro F1: {test_f1_macro:.4f}, Test Weighted F1: {test_f1_weighted:.4f}")

    # Save artifacts
    model_file = os.path.join(output_dir, "model.joblib")
    joblib.dump(best_pipeline, model_file)
    print(f"Saved model to {model_file} (Size: {os.path.getsize(model_file)/1024/1024:.2f} MB)")

    label_map_file = os.path.join(output_dir, "label_mapping.json")
    with open(label_map_file, "w", encoding="utf-8") as f:
        json.dump(LABEL_MAP, f, indent=2)

    metadata = {
        "model_name": f"Emotion_{best_name}_TFIDF",
        "task": "emotion_classification",
        "dataset_train": "backend/ml/data/processed/train.csv",
        "train_size": len(X_train),
        "val_size": len(X_val),
        "test_size": len(X_test),
        "selected_classifier": best_name,
        "feature_config": {
            "word_ngram": [1, 2],
            "word_max_features": 10000,
            "char_ngram": [3, 5],
            "char_max_features": 15000,
            "sublinear_tf": True
        },
        "sklearn_version": sklearn.__version__,
        "candidates_comparison": results,
        "validation_metrics": results[best_name],
        "test_metrics": {
            "accuracy": float(test_acc),
            "macro_precision": float(test_p_macro),
            "macro_recall": float(test_r_macro),
            "macro_f1": float(test_f1_macro),
            "weighted_f1": float(test_f1_weighted),
            "inference_time_sec": float(test_time)
        },
        "per_class_metrics": report_dict,
        "confusion_matrix": cm,
        "label_mapping": LABEL_MAP
    }

    meta_file = os.path.join(output_dir, "metadata.json")
    with open(meta_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"Saved metadata to {meta_file}")
    return metadata


if __name__ == "__main__":
    train_emotion_model()
