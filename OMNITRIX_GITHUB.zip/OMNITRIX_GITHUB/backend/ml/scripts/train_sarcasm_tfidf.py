"""
OMNITRIX Lightweight Sarcasm Classifier Training Script (Step 55).
Deduplicates sarcasm_hinghlish_dataset.csv, splits 80% train / 20% test,
trains TF-IDF + Scikit-Learn models for binary sarcasm detection.
Evaluates LogisticRegression vs LinearSVC using F1 score.
Saves model.joblib, label_mapping.json, and metadata.json to backend/ml/models/sarcasm_tfidf/.
"""

import os
import time
import json
import numpy as np
import pandas as pd
import joblib
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support, confusion_matrix

LABEL_MAP = {
    "0": "non_sarcastic",
    "1": "sarcastic"
}


def train_sarcasm_model():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_file = os.path.join(base_dir, "data", "raw", "sarcasm_hinghlish_dataset.csv")
    output_dir = os.path.join(base_dir, "models", "sarcasm_tfidf")
    os.makedirs(output_dir, exist_ok=True)

    print(f"Loading sarcasm dataset from {data_file}...")
    df = pd.read_csv(data_file)
    original_rows = len(df)

    # Deduplicate text before splitting to avoid data leakage
    df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)
    dedup_rows = len(df)
    print(f"Original rows: {original_rows}, Deduplicated rows: {dedup_rows} ({original_rows - dedup_rows} duplicates removed)")

    # 80/20 train/test split with fixed random seed
    df_train, df_test = train_test_split(df, test_size=0.2, random_state=42, stratify=df["label"])

    X_train, y_train = df_train["text"].astype(str), df_train["label"]
    X_test, y_test = df_test["text"].astype(str), df_test["label"]

    print(f"Train samples: {len(X_train)}, Test samples: {len(X_test)}")
    print("Train label counts:\n", y_train.value_counts().to_dict())

    # Build FeatureUnion for word and character n-grams
    union = FeatureUnion([
        ("word_tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=10000, sublinear_tf=True)),
        ("char_tfidf", TfidfVectorizer(ngram_range=(3, 5), analyzer="char_wb", max_features=15000, sublinear_tf=True))
    ])

    candidates = {
        "LogisticRegression": LogisticRegression(C=1.0, max_iter=500, random_state=42),
        "LinearSVC": LinearSVC(C=1.0, max_iter=1000, random_state=42)
    }

    results = {}
    best_name = None
    best_f1 = -1.0
    best_pipeline = None

    for name, clf in candidates.items():
        print(f"\n--- Training Candidate: {name} ---")
        t0 = time.time()
        pipeline = Pipeline([
            ("features", union),
            ("clf", clf)
        ])
        pipeline.fit(X_train, y_train)
        fit_time = time.time() - t0

        t1 = time.time()
        preds = pipeline.predict(X_test)
        test_time = time.time() - t1

        acc = accuracy_score(y_test, preds)
        p, r, f1, _ = precision_recall_fscore_support(y_test, preds, average="binary")
        p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(y_test, preds, average="macro")

        print(f"[{name}] Test Acc: {acc:.4f}, Binary F1: {f1:.4f}, Macro F1: {f1_macro:.4f} (Fit: {fit_time:.2f}s)")

        results[name] = {
            "accuracy": float(acc),
            "precision": float(p),
            "recall": float(r),
            "f1_score": float(f1),
            "macro_f1": float(f1_macro),
            "fit_time_sec": float(fit_time),
            "inference_time_sec": float(test_time)
        }

        if f1_macro > best_f1:
            best_f1 = f1_macro
            best_name = name
            best_pipeline = pipeline

    print(f"\nSelected final configuration: {best_name} (Macro F1: {best_f1:.4f})")

    # Evaluate final selected model on test set
    t2 = time.time()
    final_preds = best_pipeline.predict(X_test)
    final_time = time.time() - t2

    final_acc = accuracy_score(y_test, final_preds)
    p_final, r_final, f1_final, _ = precision_recall_fscore_support(y_test, final_preds, average="binary")
    p_macro_final, r_macro_final, f1_macro_final, _ = precision_recall_fscore_support(y_test, final_preds, average="macro")

    cm = confusion_matrix(y_test, final_preds).tolist()
    report_dict = classification_report(y_test, final_preds, target_names=["non_sarcastic", "sarcastic"], output_dict=True)

    print(f"\nFinal Test Metrics [{best_name}]: Acc: {final_acc:.4f}, Binary F1: {f1_final:.4f}, Macro F1: {f1_macro_final:.4f}")

    # Save artifacts
    model_file = os.path.join(output_dir, "model.joblib")
    joblib.dump(best_pipeline, model_file)
    print(f"Saved model to {model_file} (Size: {os.path.getsize(model_file)/1024/1024:.2f} MB)")

    label_map_file = os.path.join(output_dir, "label_mapping.json")
    with open(label_map_file, "w", encoding="utf-8") as f:
        json.dump(LABEL_MAP, f, indent=2)

    metadata = {
        "model_name": f"Sarcasm_{best_name}_TFIDF",
        "task": "sarcasm_detection",
        "dataset_raw": "backend/ml/data/raw/sarcasm_hinghlish_dataset.csv",
        "original_size": original_rows,
        "deduplicated_size": dedup_rows,
        "train_size": len(X_train),
        "test_size": len(X_test),
        "selected_classifier": best_name,
        "feature_config": {
            "word_ngram": [1, 2],
            "word_max_features": 10000,
            "char_ngram": [3, 5],
            "char_max_features": 15000,
            "sublinear_tf": True
        },
        "sklearn_version": sklearn.__version__,
        "candidates_comparison": results,
        "final_test_metrics": {
            "accuracy": float(final_acc),
            "precision": float(p_final),
            "recall": float(r_final),
            "f1_score": float(f1_final),
            "macro_f1": float(f1_macro_final),
            "inference_time_sec": float(final_time)
        },
        "per_class_metrics": report_dict,
        "confusion_matrix": cm,
        "label_mapping": LABEL_MAP
    }

    meta_file = os.path.join(output_dir, "metadata.json")
    with open(meta_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"Saved metadata to {meta_file}")
    return metadata


if __name__ == "__main__":
    train_sarcasm_model()
