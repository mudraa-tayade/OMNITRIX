"""
OMNITRIX Dataset Audit & Model Feasibility Inspection Script (Step 54).
Inspects all existing raw and processed NLP datasets in the repository,
calculates aggregate statistics (shapes, nulls, duplicates, class distributions, text lengths),
verifies train/val/test data leakage, and outputs structured diagnostic reports.
Guarantees zero model downloads, zero file mutations, and zero PII exposure.
"""

import os
import json
from typing import Dict, Any


def run_dataset_audit() -> Dict[str, Any]:
    """
    Executes an offline audit of all project NLP datasets.
    Returns structured metrics for reporting and testing.
    """
    try:
        import pandas as pd
    except ImportError:
        print("ERROR: pandas is not installed in the active environment.")
        return {}

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "ml", "data")

    datasets = [
        ("emotion_raw", os.path.join(data_dir, "raw", "emotion_hinghlish_dataset.xlsx")),
        ("sarcasm_raw", os.path.join(data_dir, "raw", "sarcasm_hinghlish_dataset.csv")),
        ("mlt_raw", os.path.join(data_dir, "raw", "mlt_hinghlish_dataset.csv")),
        ("train_processed", os.path.join(data_dir, "processed", "train.csv")),
        ("val_processed", os.path.join(data_dir, "processed", "val.csv")),
        ("test_processed", os.path.join(data_dir, "processed", "test.csv"))
    ]

    report = {}

    for name, filepath in datasets:
        if not os.path.exists(filepath):
            report[name] = {"error": f"File not found: {filepath}"}
            continue

        if filepath.endswith(".xlsx"):
            df = pd.read_excel(filepath)
        else:
            df = pd.read_csv(filepath)

        text_col = "text" if "text" in df.columns else ("hinglish_genz_text" if "hinglish_genz_text" in df.columns else df.columns[0])
        label_col = "label" if "label" in df.columns else ("emotion" if "emotion" in df.columns else df.columns[-1])

        lengths = df[text_col].astype(str).str.len()
        empty_count = int((df[text_col].isna() | (df[text_col].astype(str).str.strip() == "")).sum())
        null_count = int(df[text_col].isna().sum())
        dup_texts = int(df[text_col].duplicated().sum())

        class_dist = df[label_col].value_counts().to_dict()

        report[name] = {
            "path": filepath,
            "rows": len(df),
            "columns": list(df.columns),
            "text_column": text_col,
            "label_column": label_col,
            "null_text_count": null_count,
            "empty_text_count": empty_count,
            "duplicate_text_count": dup_texts,
            "text_length_min": int(lengths.min()),
            "text_length_max": int(lengths.max()),
            "text_length_mean": round(float(lengths.mean()), 1),
            "text_length_median": round(float(lengths.median()), 1),
            "unique_labels": len(class_dist),
            "label_distribution": class_dist
        }

    # Verify cross-split data leakage if processed datasets exist
    train_path = os.path.join(data_dir, "processed", "train.csv")
    val_path = os.path.join(data_dir, "processed", "val.csv")
    test_path = os.path.join(data_dir, "processed", "test.csv")

    if os.path.exists(train_path) and os.path.exists(val_path) and os.path.exists(test_path):
        df_tr = pd.read_csv(train_path)
        df_va = pd.read_csv(val_path)
        df_te = pd.read_csv(test_path)

        set_tr = set(df_tr["text"].astype(str))
        set_va = set(df_va["text"].astype(str))
        set_te = set(df_te["text"].astype(str))

        report["leakage_analysis"] = {
            "train_val_overlap": len(set_tr.intersection(set_va)),
            "train_test_overlap": len(set_tr.intersection(set_te)),
            "val_test_overlap": len(set_va.intersection(set_te)),
            "clean_splits": (
                len(set_tr.intersection(set_va)) == 0 and
                len(set_tr.intersection(set_te)) == 0 and
                len(set_va.intersection(set_te)) == 0
            )
        }

    return report


if __name__ == "__main__":
    results = run_dataset_audit()
    print(json.dumps(results, indent=2))
