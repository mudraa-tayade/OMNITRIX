"""
Unit tests for FastAPI Complaint API Endpoint with SQLite Persistence (backend/main.py).
Tests use isolated temporary SQLite databases and clean up completely afterward.
Standard library unittest - no persistent server, no ML models, no external network calls.
"""

import os
import shutil
import tempfile
import sqlite3
import unittest
from unittest.mock import patch

from backend.main import analyze_complaint, ComplaintRequest, HTTPException
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    get_complaint_record,
    get_all_complaint_records,
    DEFAULT_DB_PATH
)


class TestApiPersistence(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        # Create an isolated temporary directory for test database
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_api_complaints.db")
        init_database(self.test_db_path)

    def tearDown(self):
        reset_rate_limiter()
        # Clean up temporary test directory
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_01_api_creates_privacy_safe_record(self):
        """Test 1: POST /api/complaint processes complaint and returns complaint_id, status, and preliminary_risk."""
        req = ComplaintRequest(text="First year students are asked to gather in the hall.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIsInstance(res_dict, dict)
        self.assertIn("complaint_id", res_dict)
        self.assertEqual(res_dict["status"], "new")
        self.assertIn("preliminary_risk", res_dict)

    def test_02_response_contains_complaint_id(self):
        """Test 2: API response contains a non-empty UUID string complaint_id."""
        req = ComplaintRequest(text="Incident happened near campus library.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)
        self.assertIsInstance(res_dict["complaint_id"], str)
        self.assertGreater(len(res_dict["complaint_id"]), 10)

    def test_03_response_contains_status_new(self):
        """Test 3: API response sets initial triage status to 'new'."""
        req = ComplaintRequest(text="Help required in wing C.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict.get("status"), "new")

    def test_04_response_contains_privacy_safe_sections(self):
        """Test 4: Response contains strictly complaint_id, status, and preliminary_risk."""
        req = ComplaintRequest(text="Such friendly seniors beating juniors every night!")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        expected_keys = {
            "complaint_id",
            "status",
            "preliminary_risk"
        }
        self.assertEqual(set(res_dict.keys()), expected_keys)

    def test_05_record_actually_exists_in_sqlite(self):
        """Test 5: Record is physically persisted in the SQLite database table after API invocation."""
        req = ComplaintRequest(text="Ragging happening in room 204.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM complaints WHERE complaint_id=?", (res_dict["complaint_id"],))
        count = cursor.fetchone()[0]
        conn.close()

        self.assertEqual(count, 1)

    def test_06_retrieved_database_record_matches_returned_complaint(self):
        """Test 6: Querying the database by complaint_id returns stored complaint data matching API response."""
        req = ComplaintRequest(text="Please help me urgently seniors are threatening me.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertIsNotNone(stored)
        self.assertEqual(stored["complaint_id"], res_dict["complaint_id"])
        self.assertEqual(stored["status"], res_dict["status"])
        self.assertEqual(stored["preliminary_risk"], res_dict["preliminary_risk"])

    def test_07_phone_number_is_not_stored(self):
        """Test 7: Phone number in raw complaint is masked and never stored in SQLite."""
        raw_phone = "9876543210"
        req = ComplaintRequest(text=f"Call me on {raw_phone} for proof.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertNotIn(raw_phone, stored["protected_text"])
        self.assertIn("[PHONE]", stored["protected_text"])

        # Also inspect raw SQLite row directly
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT protected_text, safe_representation, privacy_audit FROM complaints WHERE complaint_id=?", (res_dict["complaint_id"],))
        row = cursor.fetchone()
        conn.close()

        for col in row:
            self.assertNotIn(raw_phone, str(col))

    def test_08_email_is_not_stored(self):
        """Test 8: Email address in raw complaint is masked and never stored in SQLite."""
        raw_email = "student.target@college.edu.in"
        req = ComplaintRequest(text=f"Contact {raw_email} regarding the incident.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertNotIn(raw_email, stored["protected_text"])
        self.assertIn("[EMAIL]", stored["protected_text"])

    def test_09_person_name_is_not_stored(self):
        """Test 9: Person name in raw complaint is contextually masked and never stored in SQLite."""
        raw_name = "Rohan Sharma"
        req = ComplaintRequest(text=f"My name is {raw_name} and I am being tortured.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertNotIn(raw_name, stored["protected_text"])
        self.assertIn("[PERSON]", stored["protected_text"])

    def test_10_room_number_is_not_stored(self):
        """Test 10: Hostel room number is masked to [ROOM] and never stored in SQLite."""
        req = ComplaintRequest(text="They dragged juniors to room 302 after lights out.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertNotIn("302", stored["protected_text"])
        self.assertIn("[ROOM]", stored["protected_text"])

    def test_11_raw_complaint_is_not_stored(self):
        """Test 11: Entire raw text and forbidden columns are never stored in SQLite."""
        secret_content = "RAW_SECRET_STUDENT_ID_99999 in hostel room 101"
        req = ComplaintRequest(text=secret_content)
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("raw_text", res_dict)
        self.assertNotIn("original_text", res_dict)

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM complaints WHERE complaint_id=?", (res_dict["complaint_id"],))
        row = cursor.fetchone()
        conn.close()

        self.assertNotIn(secret_content, str(row))

    def test_12_multiple_complaints_receive_different_ids(self):
        """Test 12: Multiple incoming complaints receive distinct UUID complaint IDs."""
        req1 = ComplaintRequest(text="First complaint from hostel A.")
        req2 = ComplaintRequest(text="Second complaint from canteen.")

        res1 = analyze_complaint(req1, db_path=self.test_db_path)
        res2 = analyze_complaint(req2, db_path=self.test_db_path)

        dict1 = res1 if isinstance(res1, dict) else res1.__dict__
        dict2 = res2 if isinstance(res2, dict) else res2.__dict__

        self.assertNotEqual(dict1["complaint_id"], dict2["complaint_id"])

        all_records = get_all_complaint_records(db_path=self.test_db_path)
        self.assertEqual(len(all_records), 2)

    def test_13_empty_complaint_raises_http_400(self):
        """Test 13: Empty complaint text raises HTTP 400 without persistence."""
        req = ComplaintRequest(text="")
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req, db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 400)
        self.assertEqual(ctx.exception.detail, "Complaint text cannot be empty")

    def test_14_whitespace_only_complaint_raises_http_400(self):
        """Test 14: Whitespace-only string input raises HTTP 400 without persistence."""
        req = ComplaintRequest(text="   \t\n   ")
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req, db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 400)
        self.assertEqual(ctx.exception.detail, "Complaint text cannot be empty")

    def test_15_database_save_failure_does_not_produce_false_success(self):
        """Test 15: If database write fails, an HTTPException (500) is raised without exposing raw text."""
        req = ComplaintRequest(text="Important emergency complaint")

        # Mock save_complaint_record to simulate a database failure (e.g. disk I/O error)
        with patch("backend.main.save_complaint_record", side_effect=sqlite3.OperationalError("disk I/O error")):
            with self.assertRaises(HTTPException) as ctx:
                analyze_complaint(req, db_path=self.test_db_path)
            
            # Error detail must not leak raw complaint
            self.assertEqual(ctx.exception.status_code, 500)
            self.assertNotIn("Important emergency complaint", str(ctx.exception.detail))

    def test_16_endpoint_uses_existing_functions_pipeline(self):
        """Test 16: Verifies that analyze_complaint calls analyze_complaint_service, create_complaint_record, save_complaint_record."""
        with patch("backend.main.analyze_complaint_service", wraps=lambda t: {"protected_text": "mocked", "pii_masked": False}) as mock_analysis, \
             patch("backend.main.create_complaint_record", wraps=lambda p: {"complaint_id": "test-uuid", "status": "new", "protected_text": "mocked", "pii_masked": False}) as mock_record, \
             patch("backend.main.save_complaint_record") as mock_save:

            req = ComplaintRequest(text="Test pipeline delegation")
            res = analyze_complaint(req, db_path=self.test_db_path)

            mock_analysis.assert_called_once_with("Test pipeline delegation")
            mock_record.assert_called_once()
            mock_save.assert_called_once()

    def test_17_tests_use_temporary_database(self):
        """Test 17: Verifies tests execute strictly against temporary test db."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
