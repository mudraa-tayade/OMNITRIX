"""
OMNITRIX Authentication Foundation
Lightweight API key authentication for backend admin endpoints.
Uses OMNITRIX_ADMIN_API_KEY environment variable and X-Admin-API-Key HTTP header.
Uses hmac.compare_digest for timing-attack resistant credential verification.
"""

import os
import hmac
from typing import Optional

try:
    from fastapi import Header, HTTPException
except ImportError:
    # Lightweight fallback for test environments without web dependencies installed
    def Header(default=None, **kwargs):  # type: ignore
        return default

    class HTTPException(Exception):  # type: ignore
        def __init__(self, status_code: int, detail: str):
            self.status_code = status_code
            self.detail = detail
            super().__init__(detail)


from backend.config import ADMIN_API_KEY_ENV

ADMIN_API_KEY_ENV_VAR = ADMIN_API_KEY_ENV
ADMIN_API_KEY_HEADER_NAME = "X-Admin-API-Key"


def verify_admin_api_key(api_key: Optional[str]) -> None:
    """
    Verifies that admin authentication is configured and the supplied API key is valid.

    Rules:
      1. If OMNITRIX_ADMIN_API_KEY environment variable is missing or empty:
         -> raise HTTPException(status_code=500, detail="Admin authentication is not configured")
      2. If api_key header is missing, None, or empty:
         -> raise HTTPException(status_code=401, detail="Admin authentication required")
      3. If api_key does not match OMNITRIX_ADMIN_API_KEY (compared via hmac.compare_digest):
         -> raise HTTPException(status_code=403, detail="Invalid admin credentials")
      4. If key matches:
         -> allow request to proceed
    """
    configured_key = os.environ.get(ADMIN_API_KEY_ENV_VAR)
    if not configured_key or not configured_key.strip():
        raise HTTPException(
            status_code=500,
            detail="Admin authentication is not configured"
        )

    if not api_key or not isinstance(api_key, str) or not api_key.strip():
        raise HTTPException(
            status_code=401,
            detail="Admin authentication required"
        )

    # Constant-time string comparison to prevent timing side-channel attacks
    if not hmac.compare_digest(api_key.strip(), configured_key.strip()):
        raise HTTPException(
            status_code=403,
            detail="Invalid admin credentials"
        )


def require_admin_api_key(x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")) -> None:
    """FastAPI dependency wrapper for admin API key authentication."""
    verify_admin_api_key(x_admin_api_key)
