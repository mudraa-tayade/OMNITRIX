"""
Unit tests for OMNITRIX Public API Version Endpoint (GET /api/version in backend/main.py).
Standard library unittest verifying HTTP 200 response, exact {"api_version": "1.0"} structure,
public access without authentication, presence of X-Request-ID header, and non-exposure of PII or internal fields.
"""

import os
import uuid
import asyncio
import unittest
from unittest.mock import patch

from backend.main import (
    get_api_version,
    add_request_id_header,
    API_VERSION,
    JSONResponse,
    Request
)


class TestVersionEndpoint(unittest.TestCase):
    def setUp(self):
        self.dummy_req = Request("127.0.0.1")

    def _run(self, coro):
        return asyncio.run(coro)

    def test_01_version_endpoint_returns_200_and_exact_structure(self):
        """Test 1: GET /api/version returns HTTP 200 with exact content {"api_version": "1.0"}."""
        res = get_api_version()
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict, {"api_version": "1.0"})
        self.assertEqual(res_dict["api_version"], API_VERSION)

    def test_02_version_endpoint_response_contains_only_api_version_field(self):
        """Test 2: Response dictionary contains strictly the 'api_version' key."""
        res = get_api_version()
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(set(res_dict.keys()), {"api_version"})

    def test_03_endpoint_is_publicly_accessible_without_authentication(self):
        """Test 3: GET /api/version functions without X-Admin-API-Key or env key set."""
        with patch.dict(os.environ, {}, clear=True):
            res = get_api_version()
            res_dict = res if isinstance(res, dict) else res.__dict__

            self.assertEqual(res_dict["api_version"], "1.0")

    def test_04_x_request_id_header_is_present_via_middleware(self):
        """Test 4: Response processed through HTTP middleware automatically receives X-Request-ID header."""
        async def mock_call_next(req):
            v_dict = get_api_version()
            return JSONResponse(v_dict, status_code=200)

        res = self._run(add_request_id_header(self.dummy_req, mock_call_next))

        self.assertEqual(res.status_code, 200)
        self.assertIn("X-Request-ID", res.headers)
        
        req_id = res.headers["X-Request-ID"]
        parsed_uuid = uuid.UUID(req_id, version=4)
        self.assertEqual(str(parsed_uuid), req_id)

    def test_05_no_complaint_pii_or_internal_fields_exposed(self):
        """Test 5: Version response never contains complaint text, complaint IDs, PII, DB paths, or secret keys."""
        res = get_api_version()
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("complaint_id", res_str)
        self.assertNotIn("protected_text", res_str)
        self.assertNotIn("raw_text", res_str)
        self.assertNotIn("risk", res_str)
        self.assertNotIn("database", res_str)
        self.assertNotIn("secret", res_str)
        self.assertNotIn("key", res_str)


if __name__ == "__main__":
    unittest.main()
