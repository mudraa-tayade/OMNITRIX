"""
OMNITRIX Backend Database Configuration & Helper Module
Centralizes database path resolution via backend.config and re-exports core persistence layer functions.
"""

from typing import Optional, Dict, Any, List
from backend.config import get_db_path as resolve_db_path
from backend.privacy.database import (
    init_database as privacy_init_database,
    save_complaint_record as privacy_save_complaint_record,
    get_complaint_record as privacy_get_complaint_record,
    get_all_complaint_records as privacy_get_all_complaint_records,
    update_complaint_status as privacy_update_complaint_status,
    get_status_history as privacy_get_status_history,
    ALLOWED_STATUSES,
    DEFAULT_DB_PATH
)


def get_db_path(override_path: Optional[str] = None) -> str:
    """Returns resolved database file path from backend.config."""
    return resolve_db_path(override_path)


def init_database(db_path: Optional[str] = None) -> None:
    """Initializes SQLite database schema using resolved database path."""
    target_path = resolve_db_path(db_path)
    privacy_init_database(db_path=target_path)


def save_complaint_record(record: Dict[str, Any], db_path: Optional[str] = None) -> None:
    """Saves a privacy-safe complaint record using resolved database path."""
    target_path = resolve_db_path(db_path)
    privacy_save_complaint_record(record, db_path=target_path)


def get_complaint_record(complaint_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Retrieves a complaint record by ID using resolved database path."""
    target_path = resolve_db_path(db_path)
    return privacy_get_complaint_record(complaint_id, db_path=target_path)


def get_all_complaint_records(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Retrieves all complaint records using resolved database path."""
    target_path = resolve_db_path(db_path)
    return privacy_get_all_complaint_records(db_path=target_path)


def update_complaint_status(complaint_id: str, new_status: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Updates complaint status and logs audit trail using resolved database path."""
    target_path = resolve_db_path(db_path)
    return privacy_update_complaint_status(complaint_id, new_status, db_path=target_path)


def get_status_history(complaint_id: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Retrieves complaint status transition audit history using resolved database path."""
    target_path = resolve_db_path(db_path)
    return privacy_get_status_history(complaint_id, db_path=target_path)
