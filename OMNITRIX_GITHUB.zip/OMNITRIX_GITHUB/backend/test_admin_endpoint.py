"""
Unit tests for FastAPI Admin Complaint Listing API Endpoint (GET /api/admin/complaints).
Tests verify that administrative analytical signals and preliminary_risk are exposed while strictly hiding
raw complaint text, protected text, personal identities, and audit telemetry.
Uses isolated temporary SQLite databases and cleans up completely afterward.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    analyze_complaint,
    list_admin_complaints,
    ComplaintRequest,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH
)

TEST_ADMIN_KEY = "test-admin-secret-key-98765"


class TestAdminEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_admin.db")
        init_database(self.test_db_path)
        self._orig_key = os.environ.get("OMNITRIX_ADMIN_API_KEY")
        os.environ["OMNITRIX_ADMIN_API_KEY"] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_key is None:
            os.environ.pop("OMNITRIX_ADMIN_API_KEY", None)
        else:
            os.environ["OMNITRIX_ADMIN_API_KEY"] = self._orig_key

    def _create_sample_complaint(self, text: str) -> dict:
        req = ComplaintRequest(text=text)
        res = analyze_complaint(req, db_path=self.test_db_path)
        return res if isinstance(res, dict) else res.__dict__

    def _list_admin(self, key=TEST_ADMIN_KEY):
        return list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=key)

    def test_01_empty_database_returns_empty_list_200(self):
        """Test 1: Empty database returns empty list [] with HTTP 200."""
        results = self._list_admin()
        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 0)
        self.assertEqual(results, [])

    def test_02_auth_missing_header_returns_401(self):
        """Test 2: Missing X-Admin-API-Key header raises HTTP 401."""
        with self.assertRaises(HTTPException) as ctx:
            list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=None)
        self.assertEqual(ctx.exception.status_code, 401)

    def test_03_auth_wrong_header_returns_403(self):
        """Test 3: Incorrect X-Admin-API-Key header raises HTTP 403."""
        with self.assertRaises(HTTPException) as ctx:
            list_admin_complaints(db_path=self.test_db_path, x_admin_api_key="wrong-admin-key")
        self.assertEqual(ctx.exception.status_code, 403)

    def test_04_auth_correct_key_returns_200(self):
        """Test 4: Correct X-Admin-API-Key header succeeds."""
        results = self._list_admin(key=TEST_ADMIN_KEY)
        self.assertIsInstance(results, list)

    def test_05_one_complaint_appears_in_listing(self):
        """Test 5: A single saved complaint appears in the admin listing."""
        saved = self._create_sample_complaint("First year students facing issues in canteen.")
        results = self._list_admin()

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["complaint_id"], saved["complaint_id"])

    def test_06_multiple_complaints_appear_in_listing(self):
        """Test 6: Multiple saved complaints all appear in the admin listing."""
        self._create_sample_complaint("Complaint 1: library issue.")
        self._create_sample_complaint("Complaint 2: hostel wing A problem.")
        self._create_sample_complaint("Complaint 3: mess hall harassment.")

        results = self._list_admin()
        self.assertEqual(len(results), 3)

    def test_07_complaint_ids_are_present(self):
        """Test 7: Each returned admin item contains a valid complaint_id string."""
        self._create_sample_complaint("Incident in block 4.")
        results = self._list_admin()

        for item in results:
            self.assertIn("complaint_id", item)
            self.assertIsInstance(item["complaint_id"], str)
            self.assertGreater(len(item["complaint_id"]), 10)

    def test_08_status_is_present(self):
        """Test 8: Each returned admin item contains status 'new'."""
        self._create_sample_complaint("Incident in block 5.")
        results = self._list_admin()

        for item in results:
            self.assertIn("status", item)
            self.assertEqual(item["status"], "new")

    def test_09_safe_representation_is_present(self):
        """Test 9: Each returned admin item contains safe_representation structure."""
        self._create_sample_complaint("Bhai hostel me ragging chal rahi hai emergency help")
        results = self._list_admin()

        for item in results:
            self.assertIn("safe_representation", item)
            self.assertIn("language_hint", item["safe_representation"])
            self.assertIn("token_count", item["safe_representation"])

    def test_10_risk_signals_are_present(self):
        """Test 10: Each returned admin item contains risk_signals structure."""
        self._create_sample_complaint("Please help urgently seniors threatened to beat me.")
        results = self._list_admin()

        for item in results:
            self.assertIn("risk_signals", item)
            self.assertTrue(item["risk_signals"]["has_threat_language"])
            self.assertTrue(item["risk_signals"]["has_help_seeking"])

    def test_11_sarcasm_signals_are_present(self):
        """Test 11: Each returned admin item contains sarcasm_signals structure."""
        self._create_sample_complaint("Such a welcoming department truly wonderful hostel experience.")
        results = self._list_admin()

        for item in results:
            self.assertIn("sarcasm_signals", item)
            self.assertIn("has_sarcasm_markers", item["sarcasm_signals"])

    def test_12_feature_summary_is_present(self):
        """Test 12: Each returned admin item contains unified feature_summary vector."""
        self._create_sample_complaint("Urgent hostel issue in room 101.")
        results = self._list_admin()

        for item in results:
            self.assertIn("feature_summary", item)
            self.assertIn("has_threat_language", item["feature_summary"])
            self.assertIn("distress_keyword_count", item["feature_summary"])

    def test_13_preliminary_risk_is_present_with_correct_schema(self):
        """Test 13: Each returned admin item contains preliminary_risk with level, score, and reasons."""
        self._create_sample_complaint("Seniors threatened to beat me urgently.")
        results = self._list_admin()

        for item in results:
            self.assertIn("preliminary_risk", item)
            risk = item["preliminary_risk"]
            if not isinstance(risk, dict):
                risk = risk.__dict__

            self.assertIn("risk_level", risk)
            self.assertIn("risk_score", risk)
            self.assertIn("reasons", risk)

            self.assertIn(risk["risk_level"], ["low", "medium", "high", "critical"])
            self.assertIsInstance(risk["risk_score"], int)
            self.assertTrue(0 <= risk["risk_score"] <= 100)
            self.assertIsInstance(risk["reasons"], list)

    def test_14_reasons_are_generic_and_privacy_safe(self):
        """Test 14: Reasons in preliminary_risk do not contain raw text or PII."""
        self._create_sample_complaint("My name is Rohan Sharma call 9876543210 urgently.")
        results = self._list_admin()

        for item in results:
            risk = item["preliminary_risk"]
            if not isinstance(risk, dict):
                risk = risk.__dict__
            for reason in risk["reasons"]:
                self.assertNotIn("Rohan Sharma", reason)
                self.assertNotIn("9876543210", reason)

    def test_15_protected_text_is_not_present(self):
        """Test 15: protected_text is strictly excluded from admin listing."""
        self._create_sample_complaint("Seniors forced freshers to do chores.")
        results = self._list_admin()

        for item in results:
            self.assertNotIn("protected_text", item)
            self.assertNotIn("forced freshers", str(item))

    def test_16_raw_text_is_not_present(self):
        """Test 16: raw_text and original_text are strictly excluded from admin listing."""
        secret = "RAW_SECRET_ID_99999_SUPER_PRIVATE"
        self._create_sample_complaint(secret)
        results = self._list_admin()

        for item in results:
            self.assertNotIn("raw_text", item)
            self.assertNotIn("original_text", item)
            self.assertNotIn(secret, str(item))

    def test_17_privacy_audit_is_not_present(self):
        """Test 17: privacy_audit telemetry is strictly excluded from admin listing."""
        self._create_sample_complaint("Call 9876543210 or email target@univ.edu in room 302.")
        results = self._list_admin()

        for item in results:
            self.assertNotIn("privacy_audit", item)
            self.assertNotIn("pii_detected", item)
            self.assertNotIn("transformations_applied", item)

    def test_18_phone_email_name_room_not_exposed(self):
        """Test 18: Phone, email, name, and room numbers never appear anywhere in the admin output."""
        raw_phone = "9876543210"
        raw_email = "student@college.edu.in"
        raw_name = "Vikram Aditya"
        raw_room = "777888999"
        complaint_text = f"My name is {raw_name}, phone {raw_phone}, email {raw_email}, room {raw_room}. Help."

        self._create_sample_complaint(complaint_text)
        results = self._list_admin()

        for item in results:
            item_str = str(item)
            self.assertNotIn(raw_phone, item_str)
            self.assertNotIn(raw_email, item_str)
            self.assertNotIn(raw_name, item_str)
            self.assertNotIn(raw_room, item_str)
            self.assertNotIn("[PHONE]", item_str)
            self.assertNotIn("[EMAIL]", item_str)
            self.assertNotIn("[PERSON]", item_str)
            self.assertNotIn("[ROOM]", item_str)

    def test_19_endpoint_uses_get_all_complaint_records_without_recalculating_risk(self):
        """Test 19: Verifies that list_admin_complaints relies on get_all_complaint_records and does not recalculate risk."""
        mock_risk = {"risk_level": "medium", "risk_score": 55, "reasons": ["Coded language marker detected"]}
        with patch("backend.main.get_all_complaint_records", wraps=lambda db_path=None: [{
            "complaint_id": "mock-uuid-1",
            "status": "new",
            "safe_representation": {},
            "risk_signals": {},
            "sarcasm_signals": {},
            "feature_summary": {},
            "preliminary_risk": mock_risk
        }]) as mock_get_all:
            with patch("backend.privacy.risk_decision.classify_preliminary_risk") as mock_classify:
                results = self._list_admin()
                mock_get_all.assert_called_once_with(db_path=self.test_db_path)
                mock_classify.assert_not_called()
                self.assertEqual(len(results), 1)
                self.assertEqual(results[0]["complaint_id"], "mock-uuid-1")
                self.assertEqual(results[0]["preliminary_risk"], mock_risk)

    def test_20_multiple_records_remain_distinct(self):
        """Test 20: Multiple saved records preserve their own separate IDs, statuses, signals, and preliminary_risk."""
        c1 = self._create_sample_complaint("Complaint A: extreme danger and threat beating")
        c2 = self._create_sample_complaint("Complaint B: wonderful peaceful friendly seniors")

        results = self._list_admin()
        self.assertEqual(len(results), 2)

        ids = [item["complaint_id"] for item in results]
        self.assertIn(c1["complaint_id"], ids)
        self.assertIn(c2["complaint_id"], ids)
        self.assertNotEqual(ids[0], ids[1])

        item1 = next(item for item in results if item["complaint_id"] == c1["complaint_id"])
        item2 = next(item for item in results if item["complaint_id"] == c2["complaint_id"])

        self.assertTrue(item1["risk_signals"]["has_threat_language"])
        self.assertFalse(item2["risk_signals"]["has_threat_language"])
        self.assertIn("preliminary_risk", item1)
        self.assertIn("preliminary_risk", item2)

    def test_21_tests_use_temporary_database(self):
        """Test 21: Verifies tests execute against temporary database without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
