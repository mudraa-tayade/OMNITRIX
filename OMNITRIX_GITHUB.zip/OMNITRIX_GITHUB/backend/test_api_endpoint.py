"""
Unit tests for FastAPI Student Complaint Submission API Endpoint (POST /api/complaint in backend/main.py).
Verifies anonymous submission response structure containing complaint_id, status, and preliminary_risk ONLY.
Guarantees zero leakage of raw_text, protected_text, PII, privacy_audit, risk_signals, or feature_summary.
"""

import os
import shutil
import tempfile
import sqlite3
import unittest
from unittest.mock import patch

from backend.main import analyze_complaint, ComplaintRequest, HTTPException
from backend.privacy import get_complaint_record, init_database
from backend.rate_limit import reset_rate_limiter


class TestComplaintEndpoint(unittest.TestCase):

    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_complaints.db")
        init_database(self.test_db_path)

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_01_successful_post_response_keys(self):
        """Test 1: Successful POST /api/complaint returns ONLY complaint_id, status, and preliminary_risk."""
        req = ComplaintRequest(text="First year students are asked to gather in the hall.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        expected_keys = {"complaint_id", "status", "preliminary_risk"}
        self.assertEqual(set(res_dict.keys()), expected_keys)

    def test_02_complaint_id_and_status_fields(self):
        """Test 2: Response contains valid UUID complaint_id and 'new' status."""
        req = ComplaintRequest(text="Incident happened near campus library.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIsInstance(res_dict["complaint_id"], str)
        self.assertGreater(len(res_dict["complaint_id"]), 10)
        self.assertEqual(res_dict["status"], "new")

    def test_03_preliminary_risk_structure_and_types(self):
        """Test 3: preliminary_risk contains risk_level, risk_score (int 0-100), and reasons (list)."""
        req = ComplaintRequest(text="Seniors threatened to beat me in room 101. Help immediately!")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("preliminary_risk", res_dict)
        risk = res_dict["preliminary_risk"]

        self.assertIn("risk_level", risk)
        self.assertIn("risk_score", risk)
        self.assertIn("reasons", risk)

        self.assertIsInstance(risk["risk_score"], int)
        self.assertGreaterEqual(risk["risk_score"], 0)
        self.assertLessEqual(risk["risk_score"], 100)
        self.assertIn(risk["risk_level"], {"low", "medium", "high", "critical"})
        self.assertIsInstance(risk["reasons"], list)

    def test_04_reasons_are_generic_privacy_safe_descriptions(self):
        """Test 4: Reasons in preliminary_risk contain generic strings without PII or raw text."""
        raw_input = "My name is Rahul Sharma, phone 9876543210 in room 204. Help me!"
        req = ComplaintRequest(text=raw_input)
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        for reason in res_dict["preliminary_risk"]["reasons"]:
            self.assertNotIn("Rahul", reason)
            self.assertNotIn("9876543210", reason)
            self.assertNotIn("204", reason)
            self.assertNotIn(raw_input, reason)

    def test_05_excluded_internal_fields_not_in_response(self):
        """Test 5: Excludes protected_text, privacy_audit, risk_signals, sarcasm_signals, feature_summary."""
        req = ComplaintRequest(text="Seniors are threatening freshers.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        excluded_fields = [
            "raw_text", "protected_text", "pii_masked", "safe_representation",
            "privacy_audit", "risk_signals", "sarcasm_signals", "feature_summary"
        ]
        for field in excluded_fields:
            self.assertNotIn(field, res_dict)

    def test_06_database_persistence_still_works(self):
        """Test 6: Database physically stores full sanitized complaint record including preliminary_risk."""
        req = ComplaintRequest(text="Hostel incident near study hall.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        stored = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertIsNotNone(stored)
        self.assertEqual(stored["complaint_id"], res_dict["complaint_id"])
        self.assertEqual(stored["preliminary_risk"], res_dict["preliminary_risk"])
        self.assertIn("protected_text", stored)
        self.assertIn("feature_summary", stored)

    def test_07_main_py_does_not_recalculate_risk(self):
        """Test 7: Response preliminary_risk is taken directly from the record without recalculation."""
        with patch("backend.main.create_complaint_record", wraps=lambda p: {
            "complaint_id": "mock-uuid-9999",
            "status": "new",
            "preliminary_risk": {"risk_level": "medium", "risk_score": 35, "reasons": ["Threat-related language detected"]}
        }) as mock_create:

            req = ComplaintRequest(text="Test mock risk pipeline flow")
            res = analyze_complaint(req, db_path=self.test_db_path)
            res_dict = res if isinstance(res, dict) else res.__dict__

            mock_create.assert_called_once()
            self.assertEqual(res_dict["preliminary_risk"]["risk_score"], 35)
            self.assertEqual(res_dict["preliminary_risk"]["risk_level"], "medium")

    def test_08_empty_or_invalid_complaint_rejected_with_http_400(self):
        """Test 8: Invalid or empty text returns HTTP 400 before creating record or database write."""
        req_empty = ComplaintRequest(text="")
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req_empty, db_path=self.test_db_path)
        self.assertEqual(ctx.exception.status_code, 400)


if __name__ == "__main__":
    unittest.main()
