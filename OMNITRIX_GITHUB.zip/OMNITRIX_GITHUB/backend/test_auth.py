"""
Unit tests for OMNITRIX Admin Authentication Layer (backend/auth.py and backend/main.py).
Verifies API key header validation, environment variable isolation, protected vs student endpoint security,
and zero key leakage guarantees.
"""

import hmac
import os
import shutil
import tempfile
import sqlite3
import unittest
from unittest.mock import patch

from backend.auth import (
    verify_admin_api_key,
    HTTPException,
    ADMIN_API_KEY_ENV_VAR,
    ADMIN_API_KEY_HEADER_NAME
)
from backend.main import (
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    modify_complaint_status,
    view_complaint_status_history,
    ComplaintRequest,
    ComplaintStatusUpdateRequest
)
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH
)
from backend.rate_limit import reset_rate_limiter

TEST_SECRET = "top-secret-admin-key-12345"


class TestAdminAuth(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_auth.db")
        init_database(self.test_db_path)
        self._orig_env = os.environ.get(ADMIN_API_KEY_ENV_VAR)

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_env is None:
            os.environ.pop(ADMIN_API_KEY_ENV_VAR, None)
        else:
            os.environ[ADMIN_API_KEY_ENV_VAR] = self._orig_env

    def _create_sample_complaint(self) -> str:
        req = ComplaintRequest(text="Sample issue in canteen.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        return res_dict["complaint_id"]

    def test_01_missing_environment_variable_returns_500(self):
        """Test 1: If OMNITRIX_ADMIN_API_KEY env var is unset/empty, authentication raises HTTP 500."""
        os.environ.pop(ADMIN_API_KEY_ENV_VAR, None)
        with self.assertRaises(HTTPException) as ctx:
            verify_admin_api_key("some-key")

        self.assertEqual(ctx.exception.status_code, 500)
        self.assertEqual(ctx.exception.detail, "Admin authentication is not configured")

    def test_02_missing_api_key_header_returns_401(self):
        """Test 2: If X-Admin-API-Key is missing or empty, authentication raises HTTP 401."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET

        for missing in [None, "", "   "]:
            with self.assertRaises(HTTPException) as ctx:
                verify_admin_api_key(missing)
            self.assertEqual(ctx.exception.status_code, 401)
            self.assertEqual(ctx.exception.detail, "Admin authentication required")

    def test_03_incorrect_api_key_returns_403(self):
        """Test 3: If X-Admin-API-Key is invalid, authentication raises HTTP 403."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET

        with self.assertRaises(HTTPException) as ctx:
            verify_admin_api_key("wrong-secret-key")

        self.assertEqual(ctx.exception.status_code, 403)
        self.assertEqual(ctx.exception.detail, "Invalid admin credentials")

    def test_04_correct_api_key_succeeds(self):
        """Test 4: Correct API key passes validation without raising exception."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        # Should not raise any exception
        verify_admin_api_key(TEST_SECRET)

    def test_05_api_key_never_returned_in_responses(self):
        """Test 5: Valid API key is never echoed or present in response dictionaries or exceptions."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()

        res_list = list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=TEST_SECRET)
        res_status = modify_complaint_status(cid, ComplaintStatusUpdateRequest(status="in_review"), db_path=self.test_db_path, x_admin_api_key=TEST_SECRET)
        res_hist = view_complaint_status_history(cid, db_path=self.test_db_path, x_admin_api_key=TEST_SECRET)

        for payload in [res_list, res_status, res_hist]:
            self.assertNotIn(TEST_SECRET, str(payload))

    def test_06_api_key_never_written_to_sqlite(self):
        """Test 6: Secret API key is never persisted in SQLite database tables."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()
        modify_complaint_status(cid, ComplaintStatusUpdateRequest(status="in_review"), db_path=self.test_db_path, x_admin_api_key=TEST_SECRET)

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM complaints;")
        complaint_rows = cursor.fetchall()
        cursor.execute("SELECT * FROM complaint_status_history;")
        history_rows = cursor.fetchall()
        conn.close()

        self.assertNotIn(TEST_SECRET, str(complaint_rows))
        self.assertNotIn(TEST_SECRET, str(history_rows))

    def test_07_api_key_not_accepted_via_query_or_body(self):
        """Test 7: Admin authentication checks strictly the header/auth parameter."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        # Calling without header argument (or with None) raises 401 regardless of query/body
        with self.assertRaises(HTTPException) as ctx:
            list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=None)
        self.assertEqual(ctx.exception.status_code, 401)

    def test_08_admin_listing_requires_authentication(self):
        """Test 8: GET /api/admin/complaints rejects requests without valid API key."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET

        # Missing key -> 401
        with self.assertRaises(HTTPException) as ctx1:
            list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=None)
        self.assertEqual(ctx1.exception.status_code, 401)

        # Invalid key -> 403
        with self.assertRaises(HTTPException) as ctx2:
            list_admin_complaints(db_path=self.test_db_path, x_admin_api_key="wrong-key")
        self.assertEqual(ctx2.exception.status_code, 403)

    def test_09_admin_status_update_requires_authentication(self):
        """Test 9: PATCH /api/admin/complaints/{id}/status rejects requests without valid API key."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()
        req = ComplaintStatusUpdateRequest(status="in_review")

        # Missing key -> 401
        with self.assertRaises(HTTPException) as ctx1:
            modify_complaint_status(cid, req, db_path=self.test_db_path, x_admin_api_key=None)
        self.assertEqual(ctx1.exception.status_code, 401)

        # Invalid key -> 403
        with self.assertRaises(HTTPException) as ctx2:
            modify_complaint_status(cid, req, db_path=self.test_db_path, x_admin_api_key="wrong-key")
        self.assertEqual(ctx2.exception.status_code, 403)

    def test_10_admin_history_requires_authentication(self):
        """Test 10: GET /api/admin/complaints/{id}/history rejects requests without valid API key."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()

        # Missing key -> 401
        with self.assertRaises(HTTPException) as ctx1:
            view_complaint_status_history(cid, db_path=self.test_db_path, x_admin_api_key=None)
        self.assertEqual(ctx1.exception.status_code, 401)

        # Invalid key -> 403
        with self.assertRaises(HTTPException) as ctx2:
            view_complaint_status_history(cid, db_path=self.test_db_path, x_admin_api_key="wrong-key")
        self.assertEqual(ctx2.exception.status_code, 403)

    def test_11_student_complaint_submission_unprotected(self):
        """Test 11: POST /api/complaint remains accessible without admin API key."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        res = analyze_complaint(ComplaintRequest(text="Student submission without key"), db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)
        self.assertEqual(res_dict["status"], "new")

    def test_12_student_tracking_unprotected(self):
        """Test 12: GET /api/complaint/{id} remains accessible without admin API key."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()

        res = track_complaint(cid, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict["complaint_id"], cid)
        self.assertEqual(res_dict["status"], "new")

    def test_13_failed_auth_prevents_database_query(self):
        """Test 13: Database functions are not called if authentication fails."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        cid = self._create_sample_complaint()
        req = ComplaintStatusUpdateRequest(status="in_review")

        with patch("backend.main.update_complaint_status") as mock_db:
            with self.assertRaises(HTTPException):
                modify_complaint_status(cid, req, db_path=self.test_db_path, x_admin_api_key="invalid-key")
            mock_db.assert_not_called()

    def test_14_environment_variable_is_used(self):
        """Test 14: Dynamic key changes in OMNITRIX_ADMIN_API_KEY are reflected immediately."""
        dynamic_key = "dynamic-admin-secret-77777"
        os.environ[ADMIN_API_KEY_ENV_VAR] = dynamic_key

        # Old key fails
        with self.assertRaises(HTTPException) as ctx:
            verify_admin_api_key(TEST_SECRET)
        self.assertEqual(ctx.exception.status_code, 403)

        # Dynamic key passes
        verify_admin_api_key(dynamic_key)

    def test_15_test_db_isolation(self):
        """Test 15: Verifies tests execute against temporary test DB without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)

    def test_16_uses_hmac_compare_digest(self):
        """Test 16: hmac.compare_digest is called for actual credential comparison."""
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_SECRET
        with patch("backend.auth.hmac.compare_digest", wraps=hmac.compare_digest) as mock_compare:
            verify_admin_api_key(TEST_SECRET)
            mock_compare.assert_called_once_with(TEST_SECRET, TEST_SECRET)


if __name__ == "__main__":
    unittest.main()
