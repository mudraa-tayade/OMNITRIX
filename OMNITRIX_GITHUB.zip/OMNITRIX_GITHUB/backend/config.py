"""
OMNITRIX Backend Configuration & Environment Module.
Centralizes backend constants, environment variable parsing, validation, and defaults.
Does not store or expose secrets, database contents, file paths, or PII.
"""

import os
from typing import List, Dict, Any, Optional

# Constants & Environment Variable Keys
API_VERSION = "1.0"
ADMIN_API_KEY_ENV = "OMNITRIX_ADMIN_API_KEY"
FRONTEND_ORIGINS_ENV = "OMNITRIX_FRONTEND_ORIGINS"
DB_PATH_ENV = "OMNITRIX_DB_PATH"

MAX_COMPLAINT_LENGTH_ENV = "OMNITRIX_MAX_COMPLAINT_LENGTH"
RATE_LIMIT_MAX_REQUESTS_ENV = "OMNITRIX_RATE_LIMIT_MAX_REQUESTS"
RATE_LIMIT_WINDOW_SECONDS_ENV = "OMNITRIX_RATE_LIMIT_WINDOW_SECONDS"

# Default values
DEFAULT_MAX_COMPLAINT_LENGTH = 1000
DEFAULT_RATE_LIMIT_MAX_REQUESTS = 5
DEFAULT_RATE_LIMIT_WINDOW_SECONDS = 60

# Back-compatibility constant aliases
MAX_COMPLAINT_LENGTH = DEFAULT_MAX_COMPLAINT_LENGTH
RATE_LIMIT_MAX_REQUESTS = DEFAULT_RATE_LIMIT_MAX_REQUESTS
RATE_LIMIT_WINDOW_SECONDS = DEFAULT_RATE_LIMIT_WINDOW_SECONDS

DEFAULT_FRONTEND_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173"
]

# Default SQLite database storage location: backend/data/complaints.db
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DEFAULT_DB_DIR = os.path.join(BASE_DIR, "data")
DEFAULT_DB_PATH = os.path.join(DEFAULT_DB_DIR, "complaints.db")


def _parse_positive_int(env_name: str, default: int) -> int:
    """
    Safely parses a positive integer from an environment variable.
    If absent, empty, invalid, zero, or negative, safely returns the default value without crashing.
    """
    raw_val = os.environ.get(env_name)
    if not raw_val or not raw_val.strip():
        return default
    try:
        parsed = int(raw_val.strip())
        if parsed <= 0:
            return default
        return parsed
    except (ValueError, TypeError):
        return default


def get_max_complaint_length() -> int:
    """Returns configured maximum complaint character length (fallback: 1000)."""
    return _parse_positive_int(MAX_COMPLAINT_LENGTH_ENV, DEFAULT_MAX_COMPLAINT_LENGTH)


def get_rate_limit_max_requests() -> int:
    """Returns configured maximum requests per rate limit window (fallback: 5)."""
    return _parse_positive_int(RATE_LIMIT_MAX_REQUESTS_ENV, DEFAULT_RATE_LIMIT_MAX_REQUESTS)


def get_rate_limit_window_seconds() -> int:
    """Returns configured rate limit sliding window duration in seconds (fallback: 60)."""
    return _parse_positive_int(RATE_LIMIT_WINDOW_SECONDS_ENV, DEFAULT_RATE_LIMIT_WINDOW_SECONDS)


def get_allowed_frontend_origins() -> List[str]:
    """
    Parses allowed CORS origins from OMNITRIX_FRONTEND_ORIGINS environment variable.
    Trims whitespace, ignores empty entries, and strictly forbids wildcards ('*').
    Falls back to safe local development defaults if unconfigured, empty, or invalid.
    """
    raw_env = os.environ.get(FRONTEND_ORIGINS_ENV)
    if not raw_env or not raw_env.strip():
        return list(DEFAULT_FRONTEND_ORIGINS)

    items = [item.strip() for item in raw_env.split(",") if item.strip()]
    # Filter out wildcards and invalid empty items
    valid_origins = [origin for origin in items if origin != "*"]

    return valid_origins if valid_origins else list(DEFAULT_FRONTEND_ORIGINS)


def get_db_path(override_path: Optional[str] = None) -> str:
    """
    Resolves the SQLite database file path.
    Precedence:
      1. Explicit override_path parameter (used in unit test isolation).
      2. OMNITRIX_DB_PATH environment variable.
      3. Default path: backend/data/complaints.db.
    """
    if override_path is not None and isinstance(override_path, str) and override_path.strip():
        return override_path.strip()

    env_path = os.environ.get(DB_PATH_ENV)
    if env_path and env_path.strip():
        return env_path.strip()

    return DEFAULT_DB_PATH


ML_ENABLED_ENV = "OMNITRIX_ML_ENABLED"
ML_MODEL_PATH_ENV = "OMNITRIX_ML_MODEL_PATH"

DEFAULT_ML_ENABLED = False
DEFAULT_ML_MODEL_PATH = "backend/ml/models/muril_emotion_v3"


def get_ml_enabled() -> bool:
    """
    Checks if ML analysis is enabled via OMNITRIX_ML_ENABLED environment variable.
    Defaults to False (disabled) for lightweight, zero-model execution.
    """
    raw_val = os.environ.get(ML_ENABLED_ENV, "").strip().lower()
    return raw_val in ("true", "1", "yes")


def get_ml_model_path() -> str:
    """
    Returns configured ML model directory path (fallback: backend/ml/models/muril_emotion_v3).
    """
    env_path = os.environ.get(ML_MODEL_PATH_ENV, "").strip()
    return env_path if env_path else DEFAULT_ML_MODEL_PATH


def validate_config() -> Dict[str, Any]:
    """
    Lightweight startup/configuration validation helper.
    Verifies that backend configuration settings are valid and usable.
    Does NOT require the admin API key to exist at startup.
    Returns a summary dictionary of validated settings (without secret values or absolute paths).
    """
    has_admin_key = bool(os.environ.get(ADMIN_API_KEY_ENV, "").strip())

    return {
        "status": "ok",
        "api_version": API_VERSION,
        "max_complaint_length": get_max_complaint_length(),
        "rate_limit_max_requests": get_rate_limit_max_requests(),
        "rate_limit_window_seconds": get_rate_limit_window_seconds(),
        "allowed_origins_count": len(get_allowed_frontend_origins()),
        "has_admin_api_key": has_admin_key,
        "ml_enabled": get_ml_enabled()
    }
