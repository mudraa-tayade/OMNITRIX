"""
Unit tests for OMNITRIX Global Safe Exception Handler (backend/main.py).
Verifies that unexpected exceptions return a generic HTTP 500 response without exposing stack traces,
internal exception messages, file paths, database paths, secrets, or PII.
Guarantees expected HTTPExceptions (400, 401, 403, 404, 503) remain unaffected.
"""

import os
import tempfile
import shutil
import unittest
from unittest.mock import patch

from backend.main import (
    global_exception_handler,
    health_check,
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    ComplaintRequest,
    HTTPException,
    JSONResponse,
    Request
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import init_database


class TestErrorHandler(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_error_handler.db")
        init_database(self.test_db_path)
        self.dummy_req = Request("127.0.0.1")

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_01_unexpected_exception_converts_to_http_500(self):
        """Test 1: Any unexpected Exception produces a JSONResponse with status_code = 500."""
        exc = Exception("Catastrophic internal failure in engine.py")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertIsInstance(res, JSONResponse)
        self.assertEqual(res.status_code, 500)

    def test_02_unexpected_exception_response_structure_is_strictly_generic(self):
        """Test 2: Response content is exactly {'detail': 'Internal server error'}."""
        exc = RuntimeError("Secret DB path /etc/omnitrix/prod.db corrupt")
        res = global_exception_handler(self.dummy_req, exc)

        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Internal server error"})

    def test_03_exception_message_is_not_exposed(self):
        """Test 3: Raw exception string message is never present in response."""
        sensitive_msg = "FAILED_TO_CONNECT_KEY_SECRET_987654"
        exc = ValueError(sensitive_msg)
        res = global_exception_handler(self.dummy_req, exc)

        res_str = str(res.content if hasattr(res, "content") else res.__dict__)
        self.assertNotIn(sensitive_msg, res_str)

    def test_04_file_path_information_is_not_exposed(self):
        """Test 4: File paths, directory paths, and stack trace paths are never present in response."""
        path_msg = "Error at D:\\MUSA-CODEX\\backend\\privacy\\engine.py line 142"
        exc = FileNotFoundError(path_msg)
        res = global_exception_handler(self.dummy_req, exc)

        res_str = str(res.content if hasattr(res, "content") else res.__dict__)
        self.assertNotIn("D:\\MUSA-CODEX", res_str)
        self.assertNotIn("engine.py", res_str)

    def test_05_secret_key_is_not_exposed(self):
        """Test 5: API keys, environment credentials, and secrets are never present in response."""
        secret_msg = "API Key Verification Failed for OMNITRIX_ADMIN_API_KEY=supersecretkey999"
        exc = KeyError(secret_msg)
        res = global_exception_handler(self.dummy_req, exc)

        res_str = str(res.content if hasattr(res, "content") else res.__dict__)
        self.assertNotIn("supersecretkey999", res_str)

    def test_06_http_exception_400_passes_through_unchanged(self):
        """Test 6: Expected HTTP 400 validation exception passes through with original status and detail."""
        exc = HTTPException(status_code=400, detail="Complaint text cannot be empty")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 400)
        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Complaint text cannot be empty"})

    def test_07_http_exception_401_passes_through_unchanged(self):
        """Test 7: Expected HTTP 401 missing admin API key exception passes through unchanged."""
        exc = HTTPException(status_code=401, detail="Admin authentication required")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 401)
        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Admin authentication required"})

    def test_08_http_exception_403_passes_through_unchanged(self):
        """Test 8: Expected HTTP 403 invalid admin key exception passes through unchanged."""
        exc = HTTPException(status_code=403, detail="Invalid admin credentials")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 403)
        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Invalid admin credentials"})

    def test_09_http_exception_404_passes_through_unchanged(self):
        """Test 9: Expected HTTP 404 unknown complaint exception passes through unchanged."""
        exc = HTTPException(status_code=404, detail="Complaint not found")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 404)
        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Complaint not found"})

    def test_10_health_database_failure_503_remains_unchanged(self):
        """Test 10: /health database access failure continues to return its safe HTTP 503 response."""
        with patch("backend.main.get_all_complaint_records", side_effect=Exception("Database lock error")):
            res = health_check(db_path=self.test_db_path)
            if isinstance(res, JSONResponse):
                self.assertEqual(res.status_code, 503)
                content = res.content if hasattr(res, "content") else res.__dict__
                self.assertEqual(content, {
                    "status": "error",
                    "database": "unavailable"
                })


if __name__ == "__main__":
    unittest.main()
