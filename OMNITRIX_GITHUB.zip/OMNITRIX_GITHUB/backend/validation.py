"""
OMNITRIX Complaint Request Validation Module
Lightweight validation for anonymous student complaint text input.
Enforces type, non-emptiness, and character length boundaries before privacy pipeline execution.
"""

from typing import Any
from backend.auth import HTTPException
from backend.config import get_max_complaint_length, DEFAULT_MAX_COMPLAINT_LENGTH

MAX_COMPLAINT_LENGTH = DEFAULT_MAX_COMPLAINT_LENGTH


def validate_complaint_text(text: Any) -> str:
    """
    Validates complaint text input.

    Rules:
      1. Must be a string. Otherwise -> HTTP 400 {"detail": "Invalid complaint text"}
      2. Must not be empty or whitespace-only. Otherwise -> HTTP 400 {"detail": "Complaint text cannot be empty"}
      3. Stripped text length must not exceed maximum complaint length from config. Otherwise -> HTTP 400 {"detail": "Complaint text exceeds maximum length"}

    Guarantees:
      - Returns raw, un-modified complaint text for valid inputs.
      - Never exposes submitted invalid text in exception details or logs.
      - Zero side-effects (no file I/O, no DB writes, no logging).
    """
    if text is None or not isinstance(text, str):
        raise HTTPException(
            status_code=400,
            detail="Invalid complaint text"
        )

    stripped = text.strip()
    if not stripped:
        raise HTTPException(
            status_code=400,
            detail="Complaint text cannot be empty"
        )

    max_len = get_max_complaint_length()
    if len(stripped) > max_len:
        raise HTTPException(
            status_code=400,
            detail="Complaint text exceeds maximum length"
        )

    return text
