"""
Unit tests for FastAPI Admin Complaint Status Update API Endpoint
(PATCH /api/admin/complaints/{complaint_id}/status).
Standard library unittest using isolated temporary SQLite databases.
Guarantees strict status validation, zero leakage of complaint content or private signals, and return of persisted preliminary_risk.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    analyze_complaint,
    modify_complaint_status,
    view_complaint_status_history,
    ComplaintRequest,
    ComplaintStatusUpdateRequest,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    get_complaint_record,
    DEFAULT_DB_PATH
)

TEST_ADMIN_KEY = "test-admin-secret-key-98765"


class TestStatusEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_status.db")
        init_database(self.test_db_path)
        self._orig_key = os.environ.get("OMNITRIX_ADMIN_API_KEY")
        os.environ["OMNITRIX_ADMIN_API_KEY"] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_key is None:
            os.environ.pop("OMNITRIX_ADMIN_API_KEY", None)
        else:
            os.environ["OMNITRIX_ADMIN_API_KEY"] = self._orig_key

    def _create_sample_complaint(self, text: str) -> dict:
        req = ComplaintRequest(text=text)
        res = analyze_complaint(req, db_path=self.test_db_path)
        return res if isinstance(res, dict) else res.__dict__

    def _modify_status(self, complaint_id: str, req: ComplaintStatusUpdateRequest, key=TEST_ADMIN_KEY):
        return modify_complaint_status(complaint_id, req, db_path=self.test_db_path, x_admin_api_key=key)

    def test_01_existing_complaint_status_can_be_updated(self):
        """Test 1: Existing complaint status can be successfully updated to 'in_review'."""
        saved = self._create_sample_complaint("Seniors harassing juniors in hostel wing A.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIsInstance(res_dict, dict)
        self.assertEqual(res_dict["status"], "in_review")

    def test_02_auth_missing_key_returns_401(self):
        """Test 2: Missing admin API key returns HTTP 401."""
        req = ComplaintStatusUpdateRequest(status="in_review")
        with self.assertRaises(HTTPException) as ctx:
            self._modify_status("some-id", req, key=None)
        self.assertEqual(ctx.exception.status_code, 401)

    def test_03_auth_wrong_key_returns_403(self):
        """Test 3: Incorrect admin API key returns HTTP 403."""
        req = ComplaintStatusUpdateRequest(status="in_review")
        with self.assertRaises(HTTPException) as ctx:
            self._modify_status("some-id", req, key="wrong-key")
        self.assertEqual(ctx.exception.status_code, 403)

    def test_04_response_contains_complaint_id_and_status(self):
        """Test 4: Response contains the correct complaint_id string and status."""
        saved = self._create_sample_complaint("Incident in library reading room.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="resolved")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict.get("complaint_id"), complaint_id)
        self.assertEqual(res_dict.get("status"), "resolved")

    def test_05_response_contains_preliminary_risk_structure(self):
        """Test 5: Response contains preliminary_risk with risk_level, risk_score, and reasons."""
        saved = self._create_sample_complaint("Seniors threatened to beat me urgently.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("preliminary_risk", res_dict)
        risk = res_dict["preliminary_risk"]
        if not isinstance(risk, dict):
            risk = risk.__dict__

        self.assertIn("risk_level", risk)
        self.assertIn("risk_score", risk)
        self.assertIn("reasons", risk)

        self.assertIn(risk["risk_level"], ["low", "medium", "high", "critical"])
        self.assertIsInstance(risk["risk_score"], int)
        self.assertTrue(0 <= risk["risk_score"] <= 100)
        self.assertIsInstance(risk["reasons"], list)

    def test_06_preliminary_risk_remains_unchanged_after_status_updates(self):
        """Test 6: Status updates do not mutate or clear preliminary_risk."""
        saved = self._create_sample_complaint("Threat language in room 101 urgently.")
        complaint_id = saved["complaint_id"]
        initial_risk = saved["preliminary_risk"]

        for target_status in ["in_review", "resolved", "closed"]:
            req = ComplaintStatusUpdateRequest(status=target_status)
            res = self._modify_status(complaint_id, req)
            res_dict = res if isinstance(res, dict) else res.__dict__
            risk = res_dict["preliminary_risk"]
            if not isinstance(risk, dict):
                risk = risk.__dict__
            self.assertEqual(risk["risk_level"], initial_risk["risk_level"])
            self.assertEqual(risk["risk_score"], initial_risk["risk_score"])
            self.assertEqual(risk["reasons"], initial_risk["reasons"])

    def test_07_unknown_complaint_id_returns_404(self):
        """Test 7: Non-existent complaint_id raises HTTPException with detail 'Complaint not found'."""
        req = ComplaintStatusUpdateRequest(status="in_review")
        with self.assertRaises(HTTPException) as ctx:
            self._modify_status("non-existent-uuid-9999", req)

        self.assertEqual(ctx.exception.status_code, 404)
        self.assertEqual(ctx.exception.detail, "Complaint not found")

    def test_08_invalid_status_returns_400(self):
        """Test 8: Unapproved status strings raise HTTPException with detail 'Invalid complaint status'."""
        saved = self._create_sample_complaint("Complaint for status test.")
        complaint_id = saved["complaint_id"]

        invalid_statuses = ["pending", "deleted", "active", "IN_REVIEW", "arbitrary_status", "", None]
        for inv in invalid_statuses:
            req = ComplaintStatusUpdateRequest(status=inv)  # type: ignore
            with self.assertRaises(HTTPException) as ctx:
                self._modify_status(complaint_id, req)

            self.assertEqual(ctx.exception.status_code, 400)
            self.assertEqual(ctx.exception.detail, "Invalid complaint status")

    def test_09_raw_complaint_is_never_returned(self):
        """Test 9: Raw complaint text is strictly excluded from the status response."""
        secret = "RAW_SECRET_ID_99999_VICTIM"
        saved = self._create_sample_complaint(secret)
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("raw_text", res_dict)
        self.assertNotIn("original_text", res_dict)
        self.assertNotIn(secret, str(res_dict))

    def test_10_protected_text_is_never_returned(self):
        """Test 10: Protected complaint text is strictly excluded from the status response."""
        saved = self._create_sample_complaint("Seniors forced freshers to do tasks.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("protected_text", res_dict)
        self.assertNotIn("forced freshers", str(res_dict))

    def test_11_privacy_and_analytical_fields_never_returned(self):
        """Test 11: Privacy audit, risk signals, sarcasm signals, and feature summaries are not returned."""
        saved = self._create_sample_complaint("Urgent beating and threat report in room 204.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="resolved")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("privacy_audit", res_dict)
        self.assertNotIn("risk_signals", res_dict)
        self.assertNotIn("sarcasm_signals", res_dict)
        self.assertNotIn("safe_representation", res_dict)
        self.assertNotIn("feature_summary", res_dict)
        self.assertEqual(set(res_dict.keys()), {"complaint_id", "status", "preliminary_risk"})

    def test_12_person_name_and_pii_not_returned(self):
        """Test 12: Person names, phone numbers, emails, room numbers mentioned in complaint are NOT returned."""
        saved = self._create_sample_complaint("My name is Rohit call 9876543210 email test@univ.edu room 404.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        res = self._modify_status(complaint_id, req)
        res_dict = res if isinstance(res, dict) else res.__dict__
        res_dict_check = {k: v for k, v in res_dict.items() if k != "complaint_id"}
        s = str(res_dict_check)
        self.assertNotIn("Rohit", s)
        self.assertNotIn("9876543210", s)
        self.assertNotIn("test@univ.edu", s)
        self.assertNotIn("404", s)

    def test_13_database_persists_status_without_mutating_signals(self):
        """Test 13: Verifies that database updates only status and preserves all signals intact."""
        saved = self._create_sample_complaint("Call Rahul at 9876543210 regarding threats in room 101.")
        complaint_id = saved["complaint_id"]

        initial_record = get_complaint_record(complaint_id, db_path=self.test_db_path)
        self.assertEqual(initial_record["status"], "new")

        req = ComplaintStatusUpdateRequest(status="in_review")
        self._modify_status(complaint_id, req)

        after_record = get_complaint_record(complaint_id, db_path=self.test_db_path)
        self.assertEqual(after_record["status"], "in_review")
        self.assertEqual(after_record["protected_text"], initial_record["protected_text"])
        self.assertEqual(after_record["risk_signals"], initial_record["risk_signals"])
        self.assertEqual(after_record["sarcasm_signals"], initial_record["sarcasm_signals"])
        self.assertEqual(after_record["feature_summary"], initial_record["feature_summary"])
        self.assertEqual(after_record["privacy_audit"], initial_record["privacy_audit"])
        self.assertEqual(after_record["preliminary_risk"], initial_record["preliminary_risk"])

    def test_14_endpoint_delegates_to_update_complaint_status_without_recalculating_risk(self):
        """Test 14: Verifies that modify_complaint_status delegates to update_complaint_status and does not recalculate risk."""
        mock_risk = {"risk_level": "high", "risk_score": 80, "reasons": ["Urgent language"]}
        with patch("backend.main.update_complaint_status", wraps=lambda cid, st, db_path=None: {"complaint_id": cid, "status": st, "preliminary_risk": mock_risk}) as mock_update:
            with patch("backend.privacy.risk_decision.classify_preliminary_risk") as mock_classify:
                req = ComplaintStatusUpdateRequest(status="in_review")
                res = self._modify_status("mock-uuid-1", req)
                res_dict = res if isinstance(res, dict) else res.__dict__

                mock_update.assert_called_once_with("mock-uuid-1", "in_review", db_path=self.test_db_path)
                mock_classify.assert_not_called()
                self.assertEqual(res_dict["complaint_id"], "mock-uuid-1")
                self.assertEqual(res_dict["status"], "in_review")
                self.assertEqual(res_dict["preliminary_risk"], mock_risk)

    def test_15_status_history_remains_functional(self):
        """Test 15: Verifies that status history records transition accurately after status updates."""
        saved = self._create_sample_complaint("History test complaint.")
        complaint_id = saved["complaint_id"]

        req = ComplaintStatusUpdateRequest(status="in_review")
        self._modify_status(complaint_id, req)

        history_res = view_complaint_status_history(complaint_id, db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        hist_dict = history_res if isinstance(history_res, dict) else history_res.__dict__

        self.assertEqual(hist_dict["complaint_id"], complaint_id)
        self.assertEqual(len(hist_dict["history"]), 1)
        self.assertEqual(hist_dict["history"][0]["previous_status"], "new")
        self.assertEqual(hist_dict["history"][0]["new_status"], "in_review")

    def test_16_tests_use_temporary_database(self):
        """Test 16: Verifies tests execute against temporary database without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
