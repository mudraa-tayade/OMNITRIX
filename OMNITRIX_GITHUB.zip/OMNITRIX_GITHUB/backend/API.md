# OMNITRIX Backend API Documentation

This document describes the HTTP API endpoints provided by the OMNITRIX privacy-preserving backend for integration by frontend and client applications.

---

## 🔒 Privacy Architecture & Boundary

OMNITRIX enforces a strict privacy boundary across all endpoints:

1. **Public Tracking Isolation**: Public complaint tracking (`GET /api/complaint/{complaint_id}`) returns only status and generic preliminary risk information. It never returns raw text, protected text, signals, or personal identifiers.
2. **Admin API Isolation**: Administrative endpoints expose privacy-safe analytical signals, feature vectors, and risk classifications for institutional triage, but **never** return raw complaint text, `protected_text`, or personal identifiers (names, phone numbers, email addresses, hostel room numbers, student IDs, IP addresses, or device IDs).
3. **Admin Summary Aggregation**: The administrative summary endpoint (`GET /api/admin/summary`) provides strictly aggregate counts without exposing any complaint IDs, timestamps, or individual complaint records.
4. **Health Check Safety**: The health check endpoint (`GET /health`) verifies service readiness without exposing database file paths, internal exceptions, API keys, or complaint records.
5. **Internal Persistence**: The backend applies PII masking, name scrubbing, and stylometry normalization before saving records. The resulting privacy-safe `protected_text` is stored internally in the SQLite database for institutional record-keeping, while `raw_text` is permanently discarded.
6. **Preliminary Risk Classification**: `preliminary_risk` is a deterministic, rule-based heuristic assessment (`low`, `medium`, `high`, `critical`) derived from privacy-safe distress and threat signals. **`risk_score` is a deterministic internal heuristic score from 0–100 and is NOT a probability, diagnostic confidence score, or clinical diagnosis.**

---

## 🔑 Authentication

All administrative endpoints require API key authentication supplied via an HTTP header.

- **Header Name**: `X-Admin-API-Key`
- **Configured Environment Variable**: `OMNITRIX_ADMIN_API_KEY`
- **Authentication Responses**:
  - **Missing Header**: `HTTP 401 Unauthorized` — `{"detail": "Missing X-Admin-API-Key header"}`
  - **Invalid Key**: `HTTP 403 Forbidden` — `{"detail": "Invalid admin API key"}`

Public student and health endpoints require zero authentication.

---

## 🌐 CORS / Frontend Integration

The backend is configured with restricted Cross-Origin Resource Sharing (CORS) using FastAPI's `CORSMiddleware`.

### 1. Configuration & Allowed Origins
Allowed origins are configured using the `OMNITRIX_FRONTEND_ORIGINS` environment variable:

```bash
OMNITRIX_FRONTEND_ORIGINS=http://localhost:3000,http://localhost:5173
```

- **Multiple Origins**: Comma-separated. Whitespace is automatically trimmed and empty entries are ignored.
- **Default Origins**: If `OMNITRIX_FRONTEND_ORIGINS` is missing or empty, the backend defaults to:
  - `http://localhost:3000`
  - `http://localhost:5173`
- **No Wildcard Origins**: Wildcard origins (`allow_origins=["*"]`) are strictly **prohibited**.

### 2. Credentials, Methods & Headers
- **Credentials**: Disabled (`allow_credentials=False`). Cookies and authorization credentials are not exposed across origins.
- **Allowed HTTP Methods**: `GET`, `POST`, `PATCH`, `OPTIONS`.
- **Allowed Request Headers**: `Content-Type`, `X-Admin-API-Key`.

> [!IMPORTANT]
> **Security Note**: CORS controls browser access cross-origin; it does **not** replace authentication. Administrative endpoints still strictly require a valid `X-Admin-API-Key` header even when requests originate from an allowed frontend origin.

### 3. Frontend React Example
Below is a simple example showing how a React application running on `http://localhost:5173` calls `POST /api/complaint`:

```javascript
async function submitComplaint(complaintText) {
  const response = await fetch("http://localhost:8000/api/complaint", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      text: complaintText,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.detail || "Failed to submit complaint");
  }

  const data = await response.json();
  console.log("Complaint ID:", data.complaint_id);
  console.log("Preliminary Risk:", data.preliminary_risk);
  return data;
}
```

## 📱 Student API

The Student API provides anonymous, unauthenticated endpoints designed specifically for the Android student application and frontend user interfaces.

---

### 1. Submit Anonymous Complaint
`POST /api/complaint`

Submits a new anonymous complaint. Validates text, executes privacy transformations (PII masking and style normalization), evaluates preliminary risk, and persists the sanitized record to SQLite.

- **Rate Limit**: Maximum 5 requests per 60-second window per IP address (`HTTP 429 Too Many Requests`).
- **Validation Rules**:
  - `text` must be a string.
  - `text` must not be empty or whitespace-only (`HTTP 400 Bad Request`).
  - `text` length must not exceed 1000 characters (`HTTP 400 Bad Request`).

#### Request Body
```json
{
  "text": "Seniors in wing B are threatening freshers urgently."
}
```

#### Response (`HTTP 200 OK`)
```json
{
  "complaint_id": "c1234567-89ab-cdef-0123-456789abcdef",
  "status": "new",
  "preliminary_risk": {
    "risk_level": "high",
    "risk_score": 75,
    "reasons": [
      "Threatening or coercive language pattern detected",
      "Urgent assistance or distress requested"
    ]
  }
}
```

---

### 2. Track Complaint Status
`GET /api/complaint/{complaint_id}`

Retrieves the current status and preliminary risk of an existing complaint. Anonymous endpoint intended for students using their generated `complaint_id`.

- **Parameters**: `complaint_id` (UUID string path parameter).
- **Error Behavior**: Unknown or invalid `complaint_id` returns `HTTP 404 Not Found` `{"detail": "Complaint not found"}`.

#### Response (`HTTP 200 OK`)
```json
{
  "complaint_id": "c1234567-89ab-cdef-0123-456789abcdef",
  "status": "new",
  "preliminary_risk": {
    "risk_level": "high",
    "risk_score": 75,
    "reasons": [
      "Threatening or coercive language pattern detected",
      "Urgent assistance or distress requested"
    ]
  },
  "created_at": "2026-09-20 18:00:00"
}
```

---

### 3. Backend Health & Readiness Check
`GET /health`

Lightweight health and readiness check endpoint for frontend applications and deployment monitoring environments.

- **Access**: Public endpoint. No `X-Admin-API-Key` required.
- **Execution**: Performs lightweight SQLite connectivity check. Does **not** execute ML inference or analyze complaints.
- **Privacy & Security Guarantees**: Exposes zero complaint IDs, complaint text, `protected_text`, PII, API keys, database file paths, or internal exception tracebacks.

#### Healthy Response (`HTTP 200 OK`)
```json
{
  "status": "ok",
  "database": "ok"
}
```

#### Database Unavailable Response (`HTTP 503 Service Unavailable`)
```json
{
  "status": "error",
  "database": "unavailable"
}
```

---

### 4. API Version Check
`GET /api/version`

Reports the current backend API version for frontend integration and deployment verification.

- **Access**: Public endpoint. No `X-Admin-API-Key` required.
- **Headers**: Automatically includes the existing `X-Request-ID` HTTP response header.
- **Privacy & Security Guarantees**: Exposes no complaint content, complaint IDs, `protected_text`, PII, database information, file paths, model details, or internal system implementation specifics.

#### Response (`HTTP 200 OK`)
```json
{
  "api_version": "1.0"
}
```

---

## 🛡️ Admin API

All endpoints in this section are intended exclusively for institutional administrators and anti-ragging committee staff. They require the header: `X-Admin-API-Key: <admin-api-key>`.

### 5. List All Complaints
`GET /api/admin/complaints`

Returns all saved complaints formatted for the administrative dashboard. Exposes analytical signals, sarcasm/coded language indicators, feature summary vectors, and preliminary risk, while strictly omitting raw text, `protected_text`, and personal identifiers.

#### Headers
```http
X-Admin-API-Key: <your-configured-admin-api-key>
```

#### Response (`HTTP 200 OK`)
```json
[
  {
    "complaint_id": "c1234567-89ab-cdef-0123-456789abcdef",
    "status": "new",
    "safe_representation": {
      "language_hint": "english",
      "token_count": 8,
      "character_count": 52,
      "has_question": false,
      "has_exclamation": false,
      "has_repeated_punctuation": false
    },
    "risk_signals": {
      "distress_keyword_count": 1,
      "threat_keyword_count": 1,
      "urgency_keyword_count": 1,
      "help_seeking_count": 1,
      "negative_emotion_count": 1,
      "has_threat_language": true,
      "has_help_seeking": true,
      "has_urgent_language": true
    },
    "sarcasm_signals": {
      "sarcasm_marker_count": 0,
      "coded_language_marker_count": 0,
      "indirect_distress_marker_count": 0,
      "has_sarcasm_markers": false,
      "has_coded_language_markers": false,
      "has_indirect_distress": false
    },
    "feature_summary": {
      "language_hint": "english",
      "token_count": 8,
      "character_count": 52,
      "has_question": false,
      "has_exclamation": false,
      "has_repeated_punctuation": false,
      "distress_keyword_count": 1,
      "threat_keyword_count": 1,
      "urgency_keyword_count": 1,
      "help_seeking_count": 1,
      "negative_emotion_count": 1,
      "sarcasm_marker_count": 0,
      "coded_language_marker_count": 0,
      "indirect_distress_marker_count": 0,
      "has_threat_language": true,
      "has_help_seeking": true,
      "has_urgent_language": true,
      "has_sarcasm_markers": false,
      "has_coded_language_markers": false,
      "has_indirect_distress": false
    },
    "preliminary_risk": {
      "risk_level": "high",
      "risk_score": 75,
      "reasons": [
        "Threatening or coercive language pattern detected",
        "Urgent assistance or distress requested"
      ]
    },
    "created_at": "2026-09-20 18:00:00"
  }
]
```

---

### 6. Update Complaint Status
`PATCH /api/admin/complaints/{complaint_id}/status`

Updates the lifecycle status of a complaint and records a status transition audit entry in SQLite.

- **Allowed Status Values**: `"new"`, `"in_review"`, `"resolved"`, `"closed"`
- **Error Behavior**:
  - Invalid status value returns `HTTP 400 Bad Request` `{"detail": "Invalid complaint status"}`.
  - Unknown `complaint_id` returns `HTTP 404 Not Found` `{"detail": "Complaint not found"}`.

#### Headers
```http
X-Admin-API-Key: <your-configured-admin-api-key>
```

#### Request Body
```json
{
  "status": "in_review"
}
```

#### Response (`HTTP 200 OK`)
```json
{
  "complaint_id": "c1234567-89ab-cdef-0123-456789abcdef",
  "status": "in_review",
  "preliminary_risk": {
    "risk_level": "high",
    "risk_score": 75,
    "reasons": [
      "Threatening or coercive language pattern detected",
      "Urgent assistance or distress requested"
    ]
  }
}
```

---

### 7. View Complaint Status History
`GET /api/admin/complaints/{complaint_id}/history`

Retrieves the audit trail of status transitions for a specific complaint.

#### Headers
```http
X-Admin-API-Key: <your-configured-admin-api-key>
```

#### Response (`HTTP 200 OK`)
```json
{
  "complaint_id": "c1234567-89ab-cdef-0123-456789abcdef",
  "preliminary_risk": {
    "risk_level": "high",
    "risk_score": 75,
    "reasons": [
      "Threatening or coercive language pattern detected",
      "Urgent assistance or distress requested"
    ]
  },
  "history": [
    {
      "history_id": 1,
      "previous_status": "new",
      "new_status": "in_review",
      "changed_at": "2026-09-20 18:00:00"
    }
  ]
}
```

---

### 8. View Admin Dashboard Summary
`GET /api/admin/summary`

Provides aggregate complaint metrics for the administration dashboard, including total complaint count, status breakdown, and preliminary risk distribution.

#### Headers
```http
X-Admin-API-Key: <your-configured-admin-api-key>
```

#### Response (`HTTP 200 OK`)
```json
{
  "total_complaints": 10,
  "status_counts": {
    "new": 5,
    "in_review": 3,
    "resolved": 1,
    "closed": 1
  },
  "risk_counts": {
    "low": 2,
    "medium": 4,
    "high": 3,
    "critical": 1
  }
}
```
*(On an empty database, returns `total_complaints`: 0 and all status/risk counts equal to 0).*

---

## 🚨 Error Responses

The backend enforces consistent, safe error response structures across all endpoints.

### 400 Bad Request
Used for invalid complaint input or invalid complaint status values.

Examples:

```json
{
  "detail": "Complaint text must be a string"
}
```

```json
{
  "detail": "Invalid complaint status"
}
```

### 401 Unauthorized
Missing admin API key header on protected administrative endpoints:

```json
{
  "detail": "Missing X-Admin-API-Key header"
}
```

### 403 Forbidden
Invalid or incorrect admin API key provided:

```json
{
  "detail": "Invalid admin API key"
}
```

### 404 Not Found
Unknown complaint ID requested:

```json
{
  "detail": "Complaint not found"
}
```

### 503 Service Unavailable
Database connectivity failure on health check:

```json
{
  "status": "error",
  "database": "unavailable"
}
```

### 500 Internal Server Error
Unexpected unhandled backend exception:

```json
{
  "detail": "Internal server error"
}
```

> [!IMPORTANT]
> **Security Guarantees**:
> - Unexpected exception details are intentionally not returned to clients.
> - Stack traces, Python exception messages, file paths, database paths, API keys/secrets, complaint text, and PII are never exposed.
> - Frontend applications should treat `HTTP 500` as a generic server-side failure and should not expect internal debugging information.

---

## 🆔 Request ID / Debugging

The backend attaches a unique, privacy-safe request ID header to every HTTP response for boundary tracking and debugging.

### 1. Response Header Format
Every HTTP response issued by the backend includes the header:

```http
X-Request-ID: <uuid4>
```

Example:
```http
X-Request-ID: 7a8b9c0d-1234-4567-89ab-cdef01234567
```

### 2. Request ID Behavior & Privacy Rules
- **Server-Generated**: The backend generates a fresh, random `UUID4` for every incoming HTTP request.
- **Client Header Ignored**: Client-supplied `X-Request-ID` header values are **never** trusted or reused; they are automatically replaced with a fresh server-generated UUID4.
- **Header Only**: The request ID is present in HTTP response headers only. It is **never** included inside JSON response bodies.
- **Privacy & Security Boundaries**:
  - **NOT** derived from complaint text
  - **NOT** derived from personal identifiers (PII)
  - **NOT** derived from client IP addresses or network telemetry
  - **NOT** stored in the complaints database or status transition history
  - **NOT** used as an authentication or authorization credential
  - **NOT** stored or logged in backend database tables

### 3. Presence Across Response Types
The `X-Request-ID` header is attached to all responses, including:
- Successful responses (`200 OK`)
- Client input errors (`400 Bad Request`)
- Authentication errors (`401 Unauthorized`)
- Authorization errors (`403 Forbidden`)
- Resource errors (`404 Not Found`)
- Unexpected backend errors (`500 Internal Server Error`)
- Service readiness errors (`503 Service Unavailable`)

### 4. Frontend Debugging Guidance
If an API request fails or returns an unexpected HTTP error code, the frontend application can extract and report the `X-Request-ID` response header value to the backend team. This enables identifying and referencing specific request transactions at the application boundary without logging or exposing any complaint text, student identities, or PII.


