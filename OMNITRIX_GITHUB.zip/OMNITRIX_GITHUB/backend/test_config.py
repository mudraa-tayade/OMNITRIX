"""
Unit tests for OMNITRIX Backend Configuration & Environment Layer (backend/config.py & backend/database.py).
Verifies:
  - Defaults for constants, numbers, CORS origins, and DB path.
  - Environment overrides for numeric limits, CORS origins, and DB path.
  - Safe fallback for invalid, zero, or negative numeric environment values without crashing.
  - Strict wildcard ('*') rejection in CORS configuration.
  - Clean startup & import in the absence of OMNITRIX_ADMIN_API_KEY.
  - Complete non-exposure of admin API keys or absolute secrets in validation/config helpers.
"""

import os
import sys
import unittest
from unittest.mock import patch

from backend.config import (
    API_VERSION,
    ADMIN_API_KEY_ENV,
    FRONTEND_ORIGINS_ENV,
    DB_PATH_ENV,
    MAX_COMPLAINT_LENGTH_ENV,
    RATE_LIMIT_MAX_REQUESTS_ENV,
    RATE_LIMIT_WINDOW_SECONDS_ENV,
    DEFAULT_MAX_COMPLAINT_LENGTH,
    DEFAULT_RATE_LIMIT_MAX_REQUESTS,
    DEFAULT_RATE_LIMIT_WINDOW_SECONDS,
    DEFAULT_FRONTEND_ORIGINS,
    DEFAULT_DB_PATH,
    get_max_complaint_length,
    get_rate_limit_max_requests,
    get_rate_limit_window_seconds,
    get_allowed_frontend_origins,
    get_db_path,
    validate_config
)
import backend.database as database_module


class TestConfig(unittest.TestCase):
    def setUp(self):
        self._orig_env = dict(os.environ)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._orig_env)

    def test_01_default_configuration_values(self):
        """Test 1: Default configuration values when environment variables are absent."""
        os.environ.pop(MAX_COMPLAINT_LENGTH_ENV, None)
        os.environ.pop(RATE_LIMIT_MAX_REQUESTS_ENV, None)
        os.environ.pop(RATE_LIMIT_WINDOW_SECONDS_ENV, None)
        os.environ.pop(FRONTEND_ORIGINS_ENV, None)
        os.environ.pop(DB_PATH_ENV, None)

        self.assertEqual(API_VERSION, "1.0")
        self.assertEqual(get_max_complaint_length(), 1000)
        self.assertEqual(get_rate_limit_max_requests(), 5)
        self.assertEqual(get_rate_limit_window_seconds(), 60)
        self.assertEqual(get_allowed_frontend_origins(), ["http://localhost:3000", "http://localhost:5173"])
        self.assertEqual(get_db_path(), DEFAULT_DB_PATH)

    def test_02_valid_numeric_environment_overrides(self):
        """Test 2: Valid numeric environment variables override default settings."""
        os.environ[MAX_COMPLAINT_LENGTH_ENV] = "2000"
        os.environ[RATE_LIMIT_MAX_REQUESTS_ENV] = "10"
        os.environ[RATE_LIMIT_WINDOW_SECONDS_ENV] = "120"

        self.assertEqual(get_max_complaint_length(), 2000)
        self.assertEqual(get_rate_limit_max_requests(), 10)
        self.assertEqual(get_rate_limit_window_seconds(), 120)

    def test_03_invalid_numeric_environment_values_fallback_safely(self):
        """Test 3: Non-numeric environment values fall back safely to defaults without crashing."""
        os.environ[MAX_COMPLAINT_LENGTH_ENV] = "invalid_number_abc"
        os.environ[RATE_LIMIT_MAX_REQUESTS_ENV] = "not_an_int"
        os.environ[RATE_LIMIT_WINDOW_SECONDS_ENV] = "xyz123"

        self.assertEqual(get_max_complaint_length(), DEFAULT_MAX_COMPLAINT_LENGTH)
        self.assertEqual(get_rate_limit_max_requests(), DEFAULT_RATE_LIMIT_MAX_REQUESTS)
        self.assertEqual(get_rate_limit_window_seconds(), DEFAULT_RATE_LIMIT_WINDOW_SECONDS)

    def test_04_zero_and_negative_numeric_values_fallback_safely(self):
        """Test 4: Zero and negative numeric environment values fall back safely to defaults."""
        os.environ[MAX_COMPLAINT_LENGTH_ENV] = "0"
        os.environ[RATE_LIMIT_MAX_REQUESTS_ENV] = "-5"
        os.environ[RATE_LIMIT_WINDOW_SECONDS_ENV] = "-60"

        self.assertEqual(get_max_complaint_length(), DEFAULT_MAX_COMPLAINT_LENGTH)
        self.assertEqual(get_rate_limit_max_requests(), DEFAULT_RATE_LIMIT_MAX_REQUESTS)
        self.assertEqual(get_rate_limit_window_seconds(), DEFAULT_RATE_LIMIT_WINDOW_SECONDS)

    def test_05_cors_origins_defaults_and_environment_override(self):
        """Test 5: CORS origins read from OMNITRIX_FRONTEND_ORIGINS and trim whitespace."""
        os.environ[FRONTEND_ORIGINS_ENV] = "http://localhost:4000, http://dashboard.omnitrix.edu "
        origins = get_allowed_frontend_origins()

        self.assertEqual(origins, ["http://localhost:4000", "http://dashboard.omnitrix.edu"])

    def test_06_cors_wildcard_rejection(self):
        """Test 6: Wildcard '*' origin is strictly forbidden and rejected from allowed origins."""
        os.environ[FRONTEND_ORIGINS_ENV] = "*"
        origins_star_only = get_allowed_frontend_origins()
        self.assertNotIn("*", origins_star_only)
        self.assertEqual(origins_star_only, DEFAULT_FRONTEND_ORIGINS)

        os.environ[FRONTEND_ORIGINS_ENV] = "*, http://localhost:3000, *, http://app.local "
        origins_mixed = get_allowed_frontend_origins()
        self.assertNotIn("*", origins_mixed)
        self.assertEqual(origins_mixed, ["http://localhost:3000", "http://app.local"])

    def test_07_database_path_default_and_environment_override(self):
        """Test 7: DB path resolves default path or reads OMNITRIX_DB_PATH override."""
        os.environ.pop(DB_PATH_ENV, None)
        self.assertEqual(get_db_path(), DEFAULT_DB_PATH)
        self.assertEqual(database_module.get_db_path(), DEFAULT_DB_PATH)

        custom_path = "/tmp/custom_omnitrix_test.db"
        os.environ[DB_PATH_ENV] = custom_path
        self.assertEqual(get_db_path(), custom_path)
        self.assertEqual(database_module.get_db_path(), custom_path)

    def test_08_absence_of_admin_api_key_allows_clean_startup(self):
        """Test 8: Module imports and validate_config() function properly when ADMIN_API_KEY is missing."""
        os.environ.pop(ADMIN_API_KEY_ENV, None)

        config_summary = validate_config()
        self.assertEqual(config_summary["status"], "ok")
        self.assertFalse(config_summary["has_admin_api_key"])
        self.assertEqual(config_summary["api_version"], "1.0")

    def test_09_secrets_not_returned_by_configuration_helpers(self):
        """Test 9: Configuration summary dictionary never returns actual secret values or credentials."""
        os.environ[ADMIN_API_KEY_ENV] = "super-secret-admin-key-12345"

        summary = validate_config()
        summary_str = str(summary)

        self.assertNotIn("super-secret-admin-key-12345", summary_str)
        self.assertTrue(summary["has_admin_api_key"])
        self.assertNotIn("secret", summary_str.lower())
        self.assertNotIn("password", summary_str.lower())


if __name__ == "__main__":
    unittest.main()
