"""
OMNITRIX In-Memory Rate Limiter
Lightweight, process-local rate limiting for anonymous student complaint submission.
Protects POST /api/complaint using sliding time window algorithm and client network address key.
"""

import time
from typing import Dict, List, Optional, Any

from backend.auth import HTTPException

try:
    from fastapi import Request
except ImportError:
    class Request:  # type: ignore
        def __init__(self, client_host: str = "127.0.0.1"):
            self.client = type("Client", (), {"host": client_host})()


from backend.config import (
    get_rate_limit_max_requests,
    get_rate_limit_window_seconds,
    DEFAULT_RATE_LIMIT_MAX_REQUESTS,
    DEFAULT_RATE_LIMIT_WINDOW_SECONDS
)

MAX_REQUESTS = DEFAULT_RATE_LIMIT_MAX_REQUESTS
WINDOW_SECONDS = DEFAULT_RATE_LIMIT_WINDOW_SECONDS

# In-memory sliding window timestamps: { client_identifier: [timestamp_1, timestamp_2, ...] }
_rate_limit_store: Dict[str, List[float]] = {}


def get_client_identifier(request: Optional[Any] = None) -> str:
    """
    Extracts client network address from FastAPI/Starlette Request object.
    Does NOT inspect proxy headers (X-Forwarded-For, X-Real-IP).
    Falls back safely to 'unknown-client' if client info is unavailable.
    """
    if request is not None and hasattr(request, "client") and request.client is not None:
        host = getattr(request.client, "host", None)
        if host and isinstance(host, str) and host.strip():
            return host.strip()
    return "unknown-client"


def check_rate_limit(
    request: Optional[Any] = None,
    client_identifier: Optional[str] = None,
    max_requests: Optional[int] = None,
    window_seconds: Optional[int] = None,
    now: Optional[float] = None
) -> None:
    """
    Enforces sliding time window rate limiting based strictly on client network address.
    
    Guarantees:
      1. Key is client IP / identifier (fallback: 'unknown-client').
      2. NEVER uses complaint text, protected text, student PII, names, phone numbers, or style as key.
      3. NEVER logs, returns, or persists client IP in SQLite or any record.
      4. Exceeding limit raises HTTP 429 detail: 'Too many complaint submissions. Please try again later.'
    """
    limit_max = max_requests if max_requests is not None else get_rate_limit_max_requests()
    limit_win = window_seconds if window_seconds is not None else get_rate_limit_window_seconds()

    if client_identifier is not None and isinstance(client_identifier, str) and client_identifier.strip():
        key = client_identifier.strip()
    else:
        key = get_client_identifier(request)

    current_time = now if now is not None else time.time()
    cutoff_time = current_time - limit_win

    timestamps = _rate_limit_store.get(key, [])
    # Remove timestamps outside the sliding window
    valid_timestamps = [ts for ts in timestamps if ts > cutoff_time]

    if len(valid_timestamps) >= limit_max:
        _rate_limit_store[key] = valid_timestamps
        raise HTTPException(
            status_code=429,
            detail="Too many complaint submissions. Please try again later."
        )

    valid_timestamps.append(current_time)
    _rate_limit_store[key] = valid_timestamps


def reset_rate_limiter() -> None:
    """Clears all in-memory rate limit tracking state."""
    _rate_limit_store.clear()
