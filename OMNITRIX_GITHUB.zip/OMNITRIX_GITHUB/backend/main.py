"""
OMNITRIX FastAPI Backend
Privacy-preserving student safety intelligence API.
Connects privacy transformation pipeline to local SQLite persistence layer.
Provides anonymous student complaint submission/tracking endpoints and
admin-protected listing, status update, and history endpoints.
"""

from typing import Optional, List, Dict, Any

import os
import uuid
from typing import Optional, List, Dict, Any

try:
    from fastapi import FastAPI, Header, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel
except ImportError:
    # Lightweight fallback for test environments without web dependencies installed
    def Header(default=None, **kwargs):  # type: ignore
        return default

    class Request:  # type: ignore
        def __init__(self, client_host: str = "127.0.0.1"):
            self.client = type("Client", (), {"host": client_host})()

    class CORSMiddleware:  # type: ignore
        pass

    class Middleware:  # type: ignore
        def __init__(self, cls, options):
            self.cls = cls
            self.options = options
            self.kwargs = options

    class FastAPI:  # type: ignore
        def __init__(self, *args, **kwargs):
            self.user_middleware = []
            self.exception_handlers = {}
            self.middleware_funcs = []
        def add_middleware(self, middleware_class, **kwargs):
            self.user_middleware.append(Middleware(middleware_class, kwargs))
        def middleware(self, middleware_type: str):
            def decorator(fn):
                self.middleware_funcs.append(fn)
                return fn
            return decorator
        def exception_handler(self, exc_class_or_status_code):
            def decorator(fn):
                self.exception_handlers[exc_class_or_status_code] = fn
                return fn
            return decorator
        def get(self, path, **kwargs):
            def decorator(fn):
                return fn
            return decorator
        def post(self, path, **kwargs):
            def decorator(fn):
                return fn
            return decorator
        def patch(self, path, **kwargs):
            def decorator(fn):
                return fn
            return decorator
        def on_event(self, event_type: str):
            def decorator(fn):
                return fn
            return decorator

    class JSONResponse:  # type: ignore
        def __init__(self, content: dict, status_code: int = 200, headers: Optional[dict] = None):
            self.content = content
            self.status_code = status_code
            self.headers = headers if headers is not None else {}

    class BaseModel:  # type: ignore
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

from backend.privacy import (
    analyze_complaint as analyze_complaint_service,
    protect_complaint,
    create_complaint_record,
    save_complaint_record,
    get_complaint_record,
    get_all_complaint_records,
    update_complaint_status,
    get_status_history,
    ALLOWED_STATUSES,
    init_database
)
from backend.privacy.encryption import encrypt_complaint_text, decrypt_complaint_text
from backend.auth import verify_admin_api_key, HTTPException
from backend.rate_limit import check_rate_limit
from backend.validation import validate_complaint_text
from backend.config import (
    API_VERSION,
    FRONTEND_ORIGINS_ENV,
    DEFAULT_FRONTEND_ORIGINS,
    get_allowed_frontend_origins,
    validate_config
)

allowed_origins = get_allowed_frontend_origins()

# Initialize database schema explicitly during backend application startup
init_database()

app = FastAPI(
    title="OMNITRIX API",
    description="Privacy-preserving student safety analysis API",
    version="0.2.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_allowed_frontend_origins(),
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type", "X-Admin-API-Key"],
)

@app.middleware("http")
async def add_request_id_header(request: Request, call_next):
    """
    Middleware generating a unique, privacy-safe UUID4 request ID for every incoming HTTP request.
    Attaches X-Request-ID header to all responses without inspecting/logging request body or PII.
    Ignores and replaces any client-supplied X-Request-ID header.
    """
    request_id = str(uuid.uuid4())
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response

@app.exception_handler(Exception)
def global_exception_handler(request: Request, exc: Exception):
    """
    Global safe exception handler for unexpected backend failures.
    Prevents leakage of stack traces, exception messages, file paths, secrets, or PII.
    Passes through expected application HTTPExceptions (400, 401, 403, 404, 500, 503).
    """
    if isinstance(exc, HTTPException):
        res = JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail}
        )
    else:
        res = JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"}
        )
    if not hasattr(res, "headers") or res.headers is None:
        res.headers = {}
    if "X-Request-ID" not in res.headers:
        res.headers["X-Request-ID"] = str(uuid.uuid4())
    return res

@app.on_event("startup")
def on_startup():
    """Ensure database and configuration are initialized and validated on application startup."""
    validate_config()
    init_database()


# ─────────────────────────────────────────────
# PYDANTIC DATA MODELS
# ─────────────────────────────────────────────

class ComplaintRequest(BaseModel):
    text: Optional[str] = ""

class SafeRepresentationModel(BaseModel):
    language_hint: str
    token_count: int
    character_count: int
    has_question: bool
    has_exclamation: bool
    has_repeated_punctuation: bool

class PrivacyAuditModel(BaseModel):
    pii_detected: bool
    phone_count: int
    email_count: int
    url_count: int
    student_id_count: int
    room_count: int
    date_count: int
    person_name_count: int
    name_detected: bool
    style_normalized: bool
    transformations_applied: List[str]

class RiskSignalsModel(BaseModel):
    distress_keyword_count: int
    threat_keyword_count: int
    urgency_keyword_count: int
    help_seeking_count: int
    negative_emotion_count: int
    has_threat_language: bool
    has_help_seeking: bool
    has_urgent_language: bool

class SarcasmSignalsModel(BaseModel):
    sarcasm_marker_count: int
    coded_language_marker_count: int
    indirect_distress_marker_count: int
    has_sarcasm_markers: bool
    has_coded_language_markers: bool
    has_indirect_distress: bool

class FeatureSummaryModel(BaseModel):
    language_hint: str
    token_count: int
    character_count: int
    has_question: bool
    has_exclamation: bool
    has_repeated_punctuation: bool
    distress_keyword_count: int
    threat_keyword_count: int
    urgency_keyword_count: int
    help_seeking_count: int
    negative_emotion_count: int
    sarcasm_marker_count: int
    coded_language_marker_count: int
    indirect_distress_marker_count: int
    has_threat_language: bool
    has_help_seeking: bool
    has_urgent_language: bool
    has_sarcasm_markers: bool
    has_coded_language_markers: bool
    has_indirect_distress: bool

class PreliminaryRiskModel(BaseModel):
    risk_level: str
    risk_score: int
    reasons: List[str]

class ComplaintResponse(BaseModel):
    complaint_id: str
    status: str
    preliminary_risk: PreliminaryRiskModel

class ComplaintTrackingResponse(BaseModel):
    complaint_id: str
    status: str
    preliminary_risk: PreliminaryRiskModel
    created_at: Optional[str] = None

class AdminComplaintItem(BaseModel):
    complaint_id: str
    status: str
    safe_representation: SafeRepresentationModel
    risk_signals: RiskSignalsModel
    sarcasm_signals: SarcasmSignalsModel
    feature_summary: FeatureSummaryModel
    preliminary_risk: PreliminaryRiskModel
    created_at: Optional[str] = None

class ComplaintStatusUpdateRequest(BaseModel):
    status: str

class ComplaintStatusUpdateResponse(BaseModel):
    complaint_id: str
    status: str
    preliminary_risk: PreliminaryRiskModel

class StatusHistoryItemModel(BaseModel):
    history_id: int
    previous_status: str
    new_status: str
    changed_at: str

class ComplaintHistoryResponse(BaseModel):
    complaint_id: str
    preliminary_risk: PreliminaryRiskModel
    history: List[StatusHistoryItemModel]

class StatusCountsModel(BaseModel):
    new: int
    in_review: int
    resolved: int
    closed: int

class RiskCountsModel(BaseModel):
    low: int
    medium: int
    high: int
    critical: int

class AdminSummaryResponse(BaseModel):
    total_complaints: int
    status_counts: StatusCountsModel
    risk_counts: RiskCountsModel

class HealthResponse(BaseModel):
    status: str
    database: str

class VersionResponse(BaseModel):
    api_version: str


# ─────────────────────────────────────────────
# STUDENT & SYSTEM ENDPOINTS (UNPROTECTED)
# ─────────────────────────────────────────────

@app.get("/api/version", response_model=VersionResponse)
def get_api_version():
    """
    Public API version endpoint.
    Returns the current backend API version for frontend integration and deployment verification.
    
    Guarantees:
      - Public endpoint; requires ZERO authentication headers.
      - Returns HTTP 200 {"api_version": "1.0"}.
      - Contains zero complaint data, IDs, PII, risk details, DB info, or internal details.
    """
    return {
        "api_version": API_VERSION
    }

@app.get("/health", response_model=HealthResponse)
def health_check(db_path: Optional[str] = None):
    """
    Public health and readiness check endpoint.
    
    Processing Flow:
      1. Attempt database access via get_all_complaint_records(db_path=db_path).
      2. If database is accessible, return HTTP 200 {"status": "ok", "database": "ok"}.
      3. If database fails/inaccessible, return HTTP 503 {"status": "error", "database": "unavailable"}.
      
    Guarantees:
      - Public endpoint; requires ZERO authentication headers.
      - Zero complaint data, IDs, PII, risk details, or database file paths exposed.
      - Lightweight; zero ML model execution or complaint analysis.
    """
    try:
        get_all_complaint_records(db_path=db_path)
        return {
            "status": "ok",
            "database": "ok"
        }
    except Exception:
        return JSONResponse(
            status_code=503,
            content={
                "status": "error",
                "database": "unavailable"
            }
        )

@app.get("/")
def root():
    return {
        "service": "OMNITRIX",
        "status": "online",
        "version": "0.2.0"
    }

@app.post("/api/complaint", response_model=ComplaintResponse)
def analyze_complaint(
    request: ComplaintRequest,
    http_request: Optional[Request] = None,
    db_path: Optional[str] = None
):
    """
    Primary student complaint endpoint with input validation, privacy transformation, and SQLite persistence.
    Protected against excessive repeated submissions by an in-memory rate limiter.
    
    Processing Flow:
      1. Check rate limit using client network address via check_rate_limit().
      2. Validate complaint text type, non-emptiness, and 1000 char length via validate_complaint_text().
      3. Call protect_complaint(raw_text) to sanitize PII, names, and stylometry.
      4. Call create_complaint_record(protected_result) to form an anonymous record.
      5. Call save_complaint_record(record) to persist into SQLite.
      6. Return safe anonymous response containing complaint_id, status, and preliminary_risk ONLY.
      
    Guarantees:
      - Anonymous endpoint; requires zero admin authentication.
      - Invalid/empty/oversized text rejected with HTTP 400 before privacy processing or DB writes.
      - Raw complaint text, protected text, signals, feature summary, and privacy audit are NEVER returned in response.
      - Database receives strictly sanitized records from create_complaint_record().
      - Zero student identities or device telemetry retained.
    """
    check_rate_limit(http_request)

    text_input = request.text if request and hasattr(request, "text") else None
    raw_text = validate_complaint_text(text_input)

    encrypted_raw_text = encrypt_complaint_text(raw_text)
    analysis_result = analyze_complaint_service(raw_text)
    record = create_complaint_record(analysis_result, encrypted_raw_text=encrypted_raw_text)

    try:
        save_complaint_record(record, db_path=db_path)
    except Exception:
        # Never expose raw complaint or internal database specifics in error
        raise HTTPException(
            status_code=500,
            detail="Failed to persist privacy-safe complaint record."
        ) from None

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    return {
        "complaint_id": record["complaint_id"],
        "status": record.get("status", "new"),
        "preliminary_risk": record.get("preliminary_risk", default_risk)
    }


@app.get("/api/complaint/{complaint_id}", response_model=ComplaintTrackingResponse)
def track_complaint(complaint_id: str, db_path: Optional[str] = None):
    """
    Privacy-safe anonymous complaint tracking endpoint for students.
    
    Processing Flow:
      1. Receive complaint_id (UUID string).
      2. Query database via get_complaint_record(complaint_id).
      3. If found, return complaint_id, status ("new", "in_review", etc.), preliminary_risk, and creation timestamp.
      4. If not found or invalid, return HTTP 404 {"detail": "Complaint not found"}.
      
    Guarantees:
      - Anonymous endpoint; requires zero admin authentication.
      - Never returns protected_text, raw_text, risk signals, or analytical metadata.
      - Knowing a complaint_id reveals ONLY status, preliminary_risk, and creation timestamp, never complaint contents or identity.
      - Zero SQL queries written in main.py; reuses get_complaint_record().
      - Zero risk recalculation; relies on persisted preliminary_risk from SQLite record.
    """
    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        raise HTTPException(status_code=404, detail="Complaint not found")

    record = get_complaint_record(complaint_id.strip(), db_path=db_path)
    if not record:
        raise HTTPException(status_code=404, detail="Complaint not found")

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    return {
        "complaint_id": record["complaint_id"],
        "status": record.get("status", "new"),
        "preliminary_risk": record.get("preliminary_risk", default_risk),
        "created_at": record.get("created_at")
    }


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN DASHBOARD ENDPOINTS (PROTECTED VIA API KEY)
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/admin/complaints", response_model=List[AdminComplaintItem])
def list_admin_complaints(
    db_path: Optional[str] = None,
    x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
):
    """
    Privacy-safe complaint listing endpoint for the anti-ragging administration dashboard.
    Protected by OMNITRIX_ADMIN_API_KEY header authentication.
    
    Processing Flow:
      1. Verify X-Admin-API-Key header BEFORE querying database.
      2. Query SQLite database using get_all_complaint_records().
      3. Filter each record to return strictly analytical signals, status, and creation timestamp.
      4. Strip out protected_text, raw_text, privacy_audit, and any personal identifiers.
      5. Return list of sanitized admin complaint records.
      
    Guarantees:
      - Requires valid X-Admin-API-Key header matching OMNITRIX_ADMIN_API_KEY.
      - NEVER returns raw_text, protected_text, or privacy_audit details.
      - NEVER returns names, phones, emails, room numbers, roll numbers, IP or device telemetry.
      - Returns [] (HTTP 200) when the database is empty.
      - Reuses get_all_complaint_records(); zero raw SQL in main.py.
    """
    verify_admin_api_key(x_admin_api_key)

    try:
        records = get_all_complaint_records(db_path=db_path)
    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve complaint records."
        ) from None

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    sanitized_list = []
    for rec in records:
        sanitized_list.append({
            "complaint_id": rec["complaint_id"],
            "status": rec.get("status", "new"),
            "safe_representation": rec.get("safe_representation", {}),
            "risk_signals": rec.get("risk_signals", {}),
            "sarcasm_signals": rec.get("sarcasm_signals", {}),
            "feature_summary": rec.get("feature_summary", {}),
            "preliminary_risk": rec.get("preliminary_risk", default_risk),
            "created_at": rec.get("created_at")
        })

    return sanitized_list


@app.get("/api/admin/complaints/{complaint_id}")
def get_admin_complaint_detail(
    complaint_id: str,
    db_path: Optional[str] = None,
    x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
):
    """
    Privacy-safe complaint detail endpoint for the anti-ragging administration dashboard.
    Protected by OMNITRIX_ADMIN_API_KEY header authentication.
    Decrypts original complaint narrative text strictly for authorized case reviewers.
    """
    verify_admin_api_key(x_admin_api_key)

    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        raise HTTPException(status_code=404, detail="Complaint not found")

    cid = complaint_id.strip()
    record = get_complaint_record(cid, db_path=db_path)
    if not record:
        raise HTTPException(status_code=404, detail="Complaint not found")

    encrypted_text = record.get("encrypted_raw_text", "")
    decrypted = decrypt_complaint_text(encrypted_text) if encrypted_text else None

    if not decrypted:
        original_complaint_display = "Original complaint unavailable for this case."
    else:
        original_complaint_display = decrypted

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    return {
        "complaint_id": record["complaint_id"],
        "original_complaint": original_complaint_display,
        "status": record.get("status", "new"),
        "preliminary_risk": record.get("preliminary_risk", default_risk),
        "safe_representation": record.get("safe_representation", {}),
        "risk_signals": record.get("risk_signals", {}),
        "sarcasm_signals": record.get("sarcasm_signals", {}),
        "feature_summary": record.get("feature_summary", {}),
        "created_at": record.get("created_at")
    }


@app.patch("/api/admin/complaints/{complaint_id}/status", response_model=ComplaintStatusUpdateResponse)
def modify_complaint_status(
    complaint_id: str,
    request: ComplaintStatusUpdateRequest,
    db_path: Optional[str] = None,
    x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
):
    """
    Controlled complaint status update endpoint for the administration dashboard.
    Protected by OMNITRIX_ADMIN_API_KEY header authentication.
    
    Processing Flow:
      1. Verify X-Admin-API-Key header BEFORE mutating database.
      2. Receive complaint_id and desired status.
      3. Validate that status is in {'new', 'in_review', 'resolved', 'closed'}; reject otherwise with HTTP 400.
      4. Call update_complaint_status(complaint_id, status) in persistence layer.
      5. If complaint not found, return HTTP 404 {"detail": "Complaint not found"}.
      6. Return ONLY complaint_id and updated status.
      
    Guarantees:
      - Requires valid X-Admin-API-Key header matching OMNITRIX_ADMIN_API_KEY.
      - Modifies strictly the status column; analytical/privacy fields remain unchanged.
      - NEVER exposes raw complaint text, protected text, signals, or audit data.
      - Zero raw SQL written in main.py; reuses update_complaint_status().
    """
    verify_admin_api_key(x_admin_api_key)

    if not request or not hasattr(request, "status") or request.status not in ALLOWED_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid complaint status")

    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        raise HTTPException(status_code=404, detail="Complaint not found")

    cid = complaint_id.strip()

    try:
        updated_record = update_complaint_status(cid, request.status, db_path=db_path)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid complaint status")
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update complaint status")

    if not updated_record:
        raise HTTPException(status_code=404, detail="Complaint not found")

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    return {
        "complaint_id": updated_record["complaint_id"],
        "status": updated_record["status"],
        "preliminary_risk": updated_record.get("preliminary_risk", default_risk)
    }


@app.get("/api/admin/complaints/{complaint_id}/history", response_model=ComplaintHistoryResponse)
def view_complaint_status_history(
    complaint_id: str,
    db_path: Optional[str] = None,
    x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
):
    """
    Privacy-safe complaint status history endpoint for the administration dashboard.
    Protected by OMNITRIX_ADMIN_API_KEY header authentication.
    
    Processing Flow:
      1. Verify X-Admin-API-Key header BEFORE querying database.
      2. Verify complaint existence via get_complaint_record(complaint_id).
      3. If complaint does not exist, return HTTP 404 {"detail": "Complaint not found"}.
      4. Retrieve transition audit entries via get_status_history(complaint_id).
      5. Return complaint_id and formatted list of status history records.
      
    Guarantees:
      - Requires valid X-Admin-API-Key header matching OMNITRIX_ADMIN_API_KEY.
      - Read-only endpoint; does not alter database state or complaint status.
      - NEVER returns raw_text, protected_text, signals, audit details, or PII.
      - Reuses existing database functions; zero raw SQL in main.py.
    """
    verify_admin_api_key(x_admin_api_key)

    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        raise HTTPException(status_code=404, detail="Complaint not found")

    cid = complaint_id.strip()
    record = get_complaint_record(cid, db_path=db_path)
    if not record:
        raise HTTPException(status_code=404, detail="Complaint not found")

    raw_history = get_status_history(cid, db_path=db_path)
    formatted_history = []
    for item in raw_history:
        formatted_history.append({
            "history_id": item["history_id"],
            "previous_status": item["previous_status"],
            "new_status": item["new_status"],
            "changed_at": str(item["changed_at"])
        })

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }

    return {
        "complaint_id": cid,
        "preliminary_risk": record.get("preliminary_risk", default_risk),
        "history": formatted_history
    }


@app.get("/api/admin/summary", response_model=AdminSummaryResponse)
def get_admin_summary(
    db_path: Optional[str] = None,
    x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
):
    """
    Privacy-safe aggregate summary endpoint for the anti-ragging administration dashboard.
    Protected by OMNITRIX_ADMIN_API_KEY header authentication.
    
    Processing Flow:
      1. Verify X-Admin-API-Key header BEFORE querying database.
      2. Query all complaint records via get_all_complaint_records().
      3. Compute total complaints, status counts, and risk level counts.
      4. Return ONLY aggregate statistics. Zero individual complaint data or PII exposed.
      
    Guarantees:
      - Requires valid X-Admin-API-Key header matching OMNITRIX_ADMIN_API_KEY.
      - Returns zero counts when database is empty.
      - NEVER returns complaint IDs, raw text, protected text, or any personal identifiers.
      - Reuses existing database functions; zero ML re-execution.
    """
    verify_admin_api_key(x_admin_api_key)

    try:
        records = get_all_complaint_records(db_path=db_path)
    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve complaint summary."
        ) from None

    status_counts = {"new": 0, "in_review": 0, "resolved": 0, "closed": 0}
    risk_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0}

    for rec in records:
        st = rec.get("status", "new")
        if st in status_counts:
            status_counts[st] += 1

        risk_obj = rec.get("preliminary_risk")
        if isinstance(risk_obj, dict):
            lvl = risk_obj.get("risk_level", "low")
            if lvl in risk_counts:
                risk_counts[lvl] += 1

    return {
        "total_complaints": len(records),
        "status_counts": status_counts,
        "risk_counts": risk_counts
    }