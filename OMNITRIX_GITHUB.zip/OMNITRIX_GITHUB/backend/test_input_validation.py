"""
Unit tests for OMNITRIX Complaint Input Validation (backend/validation.py and backend/main.py).
Verifies strict string, non-emptiness, and 1000-character boundary checks on POST /api/complaint.
Guarantees rejected requests do not reach privacy transformations or SQLite storage.
"""

import os
import shutil
import tempfile
import sqlite3
import unittest
from unittest.mock import patch

from backend.validation import (
    validate_complaint_text,
    MAX_COMPLAINT_LENGTH,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.main import (
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    modify_complaint_status,
    view_complaint_status_history,
    ComplaintRequest,
    ComplaintStatusUpdateRequest
)
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH,
    get_complaint_record
)
from backend.auth import ADMIN_API_KEY_ENV_VAR

TEST_ADMIN_KEY = "test-admin-secret-key-11111"


class DummyRequest:
    def __init__(self, host: str = "192.168.1.50"):
        self.client = type("Client", (), {"host": host})()


class TestInputValidation(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_validation.db")
        init_database(self.test_db_path)
        self._orig_env = os.environ.get(ADMIN_API_KEY_ENV_VAR)
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_env is None:
            os.environ.pop(ADMIN_API_KEY_ENV_VAR, None)
        else:
            os.environ[ADMIN_API_KEY_ENV_VAR] = self._orig_env

    def test_01_normal_valid_complaint_succeeds(self):
        """Test 1: Normal valid complaint text succeeds without exception."""
        req = ComplaintRequest(text="Regular complaint regarding noise in hostel block B.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)
        self.assertEqual(res_dict["status"], "new")

    def test_02_empty_string_returns_http_400(self):
        """Test 2: Empty string "" raises HTTP 400 'Complaint text cannot be empty'."""
        req = ComplaintRequest(text="")
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req, db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 400)
        self.assertEqual(ctx.exception.detail, "Complaint text cannot be empty")

    def test_03_whitespace_only_returns_http_400(self):
        """Test 3: Whitespace-only string "   \n\t  " raises HTTP 400 'Complaint text cannot be empty'."""
        for ws in ["   ", "\t\t\n", " \n \t "]:
            req = ComplaintRequest(text=ws)
            with self.assertRaises(HTTPException) as ctx:
                analyze_complaint(req, db_path=self.test_db_path)

            self.assertEqual(ctx.exception.status_code, 400)
            self.assertEqual(ctx.exception.detail, "Complaint text cannot be empty")

    def test_04_text_exactly_1000_chars_is_accepted(self):
        """Test 4: Complaint text with length exactly 1000 characters is accepted."""
        text_1000 = "a" * 1000
        req = ComplaintRequest(text=text_1000)
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)
        rec = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)
        self.assertIsInstance(rec["protected_text"], str)
        self.assertGreater(len(rec["protected_text"]), 0)

    def test_05_text_over_1000_chars_returns_http_400(self):
        """Test 5: Complaint text with 1001 characters raises HTTP 400 'Complaint text exceeds maximum length'."""
        text_1001 = "a" * 1001
        req = ComplaintRequest(text=text_1001)
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req, db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 400)
        self.assertEqual(ctx.exception.detail, "Complaint text exceeds maximum length")

    def test_06_leading_whitespace_does_not_cause_rejection(self):
        """Test 6: Valid complaint with leading whitespace is accepted."""
        text_with_leading = "    Valid complaint text."
        req = ComplaintRequest(text=text_with_leading)
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)

    def test_07_trailing_whitespace_does_not_cause_rejection(self):
        """Test 7: Valid complaint with trailing whitespace is accepted."""
        text_with_trailing = "Valid complaint text.    \n"
        req = ComplaintRequest(text=text_with_trailing)
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("complaint_id", res_dict)

    def test_08_invalid_non_string_text_returns_http_400(self):
        """Test 8: Non-string values (int, list, None) raise HTTP 400 'Invalid complaint text'."""
        for invalid_val in [12345, ["invalid"], {"key": "val"}, None]:
            req = ComplaintRequest()
            req.text = invalid_val  # type: ignore
            with self.assertRaises(HTTPException) as ctx:
                analyze_complaint(req, db_path=self.test_db_path)

            self.assertEqual(ctx.exception.status_code, 400)
            self.assertEqual(ctx.exception.detail, "Invalid complaint text")

    def test_09_empty_complaint_does_not_reach_protect_complaint(self):
        """Test 9: Empty complaint does not trigger protect_complaint execution."""
        with patch("backend.main.protect_complaint") as mock_protect:
            req = ComplaintRequest(text="")
            with self.assertRaises(HTTPException):
                analyze_complaint(req, db_path=self.test_db_path)

            mock_protect.assert_not_called()

    def test_10_oversized_complaint_does_not_reach_protect_complaint(self):
        """Test 10: Oversized complaint (>1000 chars) does not trigger protect_complaint execution."""
        with patch("backend.main.protect_complaint") as mock_protect:
            req = ComplaintRequest(text="x" * 1001)
            with self.assertRaises(HTTPException):
                analyze_complaint(req, db_path=self.test_db_path)

            mock_protect.assert_not_called()

    def test_11_invalid_complaint_does_not_reach_sqlite_persistence(self):
        """Test 11: Invalid complaint does not attempt SQLite database insertion."""
        with patch("backend.main.save_complaint_record") as mock_save:
            req = ComplaintRequest(text="   ")
            with self.assertRaises(HTTPException):
                analyze_complaint(req, db_path=self.test_db_path)

            mock_save.assert_not_called()

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM complaints;")
        count = cursor.fetchone()[0]
        conn.close()
        self.assertEqual(count, 0)

    def test_12_rejected_input_does_not_create_complaint_id(self):
        """Test 12: Rejected request does not generate a complaint ID record."""
        with patch("backend.main.create_complaint_record") as mock_record:
            req = ComplaintRequest(text="")
            with self.assertRaises(HTTPException):
                analyze_complaint(req, db_path=self.test_db_path)

            mock_record.assert_not_called()

    def test_13_rejected_input_is_not_returned_in_response(self):
        """Test 13: Exception detail never echoes invalid/rejected raw text."""
        oversized = "INVALID_SECRET_TEXT_" + ("a" * 1000)
        req = ComplaintRequest(text=oversized)
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(req, db_path=self.test_db_path)

        self.assertNotIn("INVALID_SECRET_TEXT_", str(ctx.exception.detail))
        self.assertNotIn(oversized, str(ctx.exception.detail))

    def test_14_existing_rate_limiting_still_works(self):
        """Test 14: Rate limit check triggers (429) BEFORE input validation step."""
        req_client = DummyRequest("10.10.10.10")
        valid_req = ComplaintRequest(text="Valid issue")

        # Submit 5 valid complaints from client to hit rate limit
        for _ in range(5):
            analyze_complaint(valid_req, http_request=req_client, db_path=self.test_db_path)

        # 6th request with invalid empty text should get 429 (rate limit first), not 400
        invalid_req = ComplaintRequest(text="")
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(invalid_req, http_request=req_client, db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 429)
        self.assertEqual(ctx.exception.detail, "Too many complaint submissions. Please try again later.")

    def test_15_existing_privacy_transformation_remains_unchanged(self):
        """Test 15: Valid complaint text preserves PII masking and privacy protections."""
        req = ComplaintRequest(text="My name is Rohan Sharma and call 9876543210 urgently.")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        rec = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)

        self.assertTrue(rec["pii_masked"])
        self.assertNotIn("9876543210", rec["protected_text"])
        self.assertNotIn("Rohan Sharma", rec["protected_text"])

    def test_16_existing_response_structure_remains_unchanged(self):
        """Test 16: Response payload for valid complaints maintains required keys."""
        req = ComplaintRequest(text="Schema check request")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        expected_keys = {
            "complaint_id", "status", "preliminary_risk"
        }
        self.assertEqual(set(res_dict.keys()), expected_keys)

    def test_17_student_tracking_endpoint_remains_unchanged(self):
        """Test 17: GET /api/complaint/{id} works normally for existing complaint IDs."""
        req = ComplaintRequest(text="Trackable complaint text")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        cid = res_dict["complaint_id"]

        track_res = track_complaint(cid, db_path=self.test_db_path)
        track_dict = track_res if isinstance(track_res, dict) else track_res.__dict__

        self.assertEqual(track_dict["complaint_id"], cid)
        self.assertEqual(track_dict["status"], "new")

    def test_18_admin_endpoints_remain_unchanged(self):
        """Test 18: Admin listing, status update, and history endpoints function normally."""
        req = ComplaintRequest(text="Admin inspection complaint")
        res = analyze_complaint(req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        cid = res_dict["complaint_id"]

        # Admin listing
        admin_list = list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        self.assertEqual(len(admin_list), 1)

        # Admin status update
        update_res = modify_complaint_status(cid, ComplaintStatusUpdateRequest(status="in_review"), db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        update_dict = update_res if isinstance(update_res, dict) else update_res.__dict__
        self.assertEqual(update_dict["status"], "in_review")

        # Admin status history
        hist_res = view_complaint_status_history(cid, db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        hist_dict = hist_res if isinstance(hist_res, dict) else hist_res.__dict__
        self.assertEqual(hist_dict["complaint_id"], cid)


if __name__ == "__main__":
    unittest.main()
