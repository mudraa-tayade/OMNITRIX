"""
OMNITRIX TF-IDF ML Model Adapter Unit Tests (Step 55).
Tests offline scikit-learn emotion and sarcasm model adapters, lazy loading, metadata integrity,
prediction outputs, privacy boundaries, safe fallback states, and analysis pipeline integration.
"""

import os
import json
import unittest
import tempfile
import shutil

from backend.config import (
    get_ml_enabled,
    ML_ENABLED_ENV,
    ML_MODEL_PATH_ENV
)
from backend.privacy.ml.tfidf_adapter import TfidfEmotionAdapter, TfidfSarcasmAdapter
from backend.privacy.ml_analyzer import analyze_ml
from backend.privacy.analysis_service import analyze_complaint


class TestTfidfAdapters(unittest.TestCase):

    def setUp(self):
        os.environ[ML_ENABLED_ENV] = "false"
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.emotion_dir = os.path.join(base_dir, "backend", "ml", "models", "emotion_tfidf")
        self.sarcasm_dir = os.path.join(base_dir, "backend", "ml", "models", "sarcasm_tfidf")

    def tearDown(self):
        os.environ.pop(ML_ENABLED_ENV, None)
        os.environ.pop(ML_MODEL_PATH_ENV, None)

    def test_01_emotion_model_files_exist(self):
        """Test 1: Emotion model artifacts exist after training."""
        self.assertTrue(os.path.exists(self.emotion_dir))
        self.assertTrue(os.path.exists(os.path.join(self.emotion_dir, "model.joblib")))
        self.assertTrue(os.path.exists(os.path.join(self.emotion_dir, "label_mapping.json")))
        self.assertTrue(os.path.exists(os.path.join(self.emotion_dir, "metadata.json")))

    def test_02_sarcasm_model_files_exist(self):
        """Test 2: Sarcasm model artifacts exist after training."""
        self.assertTrue(os.path.exists(self.sarcasm_dir))
        self.assertTrue(os.path.exists(os.path.join(self.sarcasm_dir, "model.joblib")))
        self.assertTrue(os.path.exists(os.path.join(self.sarcasm_dir, "label_mapping.json")))
        self.assertTrue(os.path.exists(os.path.join(self.sarcasm_dir, "metadata.json")))

    def test_03_metadata_is_valid(self):
        """Test 3: Metadata files contain expected training details and metrics."""
        with open(os.path.join(self.emotion_dir, "metadata.json"), "r", encoding="utf-8") as f:
            meta_emo = json.load(f)
        self.assertEqual(meta_emo["task"], "emotion_classification")
        self.assertIn("selected_classifier", meta_emo)
        self.assertIn("test_metrics", meta_emo)

        with open(os.path.join(self.sarcasm_dir, "metadata.json"), "r", encoding="utf-8") as f:
            meta_sarc = json.load(f)
        self.assertEqual(meta_sarc["task"], "sarcasm_detection")
        self.assertIn("selected_classifier", meta_sarc)
        self.assertIn("final_test_metrics", meta_sarc)

    def test_04_label_mappings_are_valid(self):
        """Test 4: Label mappings contain correct class maps."""
        with open(os.path.join(self.emotion_dir, "label_mapping.json"), "r") as f:
            map_emo = json.load(f)
        self.assertEqual(len(map_emo), 10)

        with open(os.path.join(self.sarcasm_dir, "label_mapping.json"), "r") as f:
            map_sarc = json.load(f)
        self.assertEqual(map_sarc, {"0": "non_sarcastic", "1": "sarcastic"})

    def test_05_lazy_loading(self):
        """Test 5: Instantiation does not load weights until load() or predict()."""
        adapter_emo = TfidfEmotionAdapter()
        self.assertFalse(adapter_emo.loaded)
        self.assertIsNone(adapter_emo.model)

        adapter_sarc = TfidfSarcasmAdapter()
        self.assertFalse(adapter_sarc.loaded)
        self.assertIsNone(adapter_sarc.model)

    def test_06_prediction_with_enabled_ml(self):
        """Test 6: When ML is enabled, adapters load and produce structured predictions."""
        os.environ[ML_ENABLED_ENV] = "true"

        adapter_emo = TfidfEmotionAdapter()
        self.assertTrue(adapter_emo.is_available())
        res_emo = adapter_emo.predict("Seniors are threatening freshers in the hostel.")
        self.assertIn("label", res_emo)
        self.assertIn("score", res_emo)
        self.assertIsInstance(res_emo["score"], float)
        self.assertGreaterEqual(res_emo["score"], 0.0)
        self.assertLessEqual(res_emo["score"], 1.0)

        adapter_sarc = TfidfSarcasmAdapter()
        self.assertTrue(adapter_sarc.is_available())
        res_sarc = adapter_sarc.predict("Yeah right best day ever so helpful.")
        self.assertIn("label", res_sarc)
        self.assertIn("score", res_sarc)
        self.assertIn(res_sarc["label"], ["sarcastic", "non_sarcastic"])

    def test_07_missing_model_directory_fails_safely(self):
        """Test 7: Non-existent model directory returns is_available False and default prediction."""
        os.environ[ML_ENABLED_ENV] = "true"
        tmpdir = tempfile.mkdtemp()
        try:
            adapter = TfidfEmotionAdapter(model_dir=tmpdir)
            self.assertFalse(adapter.is_available())
            res = adapter.predict("Test text")
            self.assertEqual(res["label"], "unknown")
            self.assertEqual(res["score"], 0.0)
        finally:
            shutil.rmtree(tmpdir)

    def test_08_no_raw_text_returned_or_stored(self):
        """Test 8: Prediction outputs contain zero text fields or raw complaints."""
        os.environ[ML_ENABLED_ENV] = "true"
        adapter = TfidfEmotionAdapter()
        res = adapter.predict("John Doe at 9876543210 in room 402 is scared")
        self.assertNotIn("text", res)
        self.assertNotIn("raw_text", res)
        self.assertNotIn("protected_text", res)

    def test_09_ml_analyzer_integration_when_enabled(self):
        """Test 9: analyze_ml executes TF-IDF emotion and sarcasm models when enabled."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("Seniors are threatening freshers in the hostel wing B urgently.")
        self.assertEqual(res["model_status"], "available")
        self.assertNotEqual(res["emotion"]["label"], "unknown")
        self.assertNotEqual(res["sarcasm"]["label"], "unknown")
        self.assertEqual(res["coded_distress"]["label"], "unknown")  # Rule-based fallback

    def test_10_ml_analyzer_integration_when_disabled(self):
        """Test 10: When ML is disabled, analyze_ml returns model_status 'not_loaded'."""
        os.environ[ML_ENABLED_ENV] = "false"
        res = analyze_ml("Seniors are threatening freshers in the hostel wing B urgently.")
        self.assertEqual(res["model_status"], "not_loaded")
        self.assertEqual(res["emotion"]["label"], "unknown")
        self.assertEqual(res["sarcasm"]["label"], "unknown")

    def test_11_analysis_service_integration(self):
        """Test 11: analyze_complaint integrates ML predictions into fused_analysis when enabled."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_complaint("Seniors in hostel wing B are threatening freshers urgently.")
        self.assertEqual(res["ml_analysis"]["model_status"], "available")
        self.assertEqual(res["fused_analysis"]["analysis_mode"], "ml_assisted")
        self.assertTrue(res["fused_analysis"]["ml_available"])


if __name__ == "__main__":
    unittest.main()
