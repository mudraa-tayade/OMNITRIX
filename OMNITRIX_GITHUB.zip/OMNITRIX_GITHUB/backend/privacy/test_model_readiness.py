"""
OMNITRIX Model Readiness & Offline Safety Unit Tests (Step 52).
Tests local MuRIL emotion model checkpoint evaluation, readiness status reporting,
missing base model handling, missing adapter/tokenizer handling, offline-only guarantees,
zero automatic downloads, and privacy boundaries.
"""

import os
import json
import unittest
import tempfile
import shutil
from unittest.mock import patch, MagicMock

from backend.config import (
    get_ml_enabled,
    get_ml_model_path,
    ML_ENABLED_ENV,
    ML_MODEL_PATH_ENV
)
from backend.privacy.ml.model_readiness import check_muril_readiness, is_base_model_cached_locally
from backend.privacy.ml.muril_adapter import MurilEmotionAdapter
from backend.privacy.ml_analyzer import analyze_ml
from backend.privacy.analysis_service import analyze_complaint


class TestModelReadiness(unittest.TestCase):

    def setUp(self):
        os.environ[ML_ENABLED_ENV] = "false"
        self.default_model_path = get_ml_model_path()

    def tearDown(self):
        os.environ.pop(ML_ENABLED_ENV, None)
        os.environ.pop(ML_MODEL_PATH_ENV, None)

    def test_01_adapter_checkpoint_files_exist(self):
        """Test 1: Local adapter checkpoint directory exists and contains expected files."""
        self.assertTrue(os.path.exists(self.default_model_path))
        adapter_config = os.path.join(self.default_model_path, "adapter_config.json")
        adapter_weights = os.path.join(self.default_model_path, "adapter_model.safetensors")
        self.assertTrue(os.path.exists(adapter_config))
        self.assertTrue(os.path.exists(adapter_weights))

        with open(adapter_config, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        self.assertEqual(cfg.get("base_model_name_or_path"), "google/muril-base-cased")
        self.assertEqual(cfg.get("peft_type"), "LORA")
        self.assertEqual(cfg.get("task_type"), "SEQ_CLS")

    def test_02_label_mapping_is_valid(self):
        """Test 2: Confirm label mapping contains all 10 expected emotion labels (0-9)."""
        label_map_file = os.path.join(self.default_model_path, "label_mapping.json")
        self.assertTrue(os.path.exists(label_map_file))

        with open(label_map_file, "r", encoding="utf-8") as f:
            mapping = json.load(f)

        expected_labels = {
            "0": "admiration",
            "1": "anger",
            "2": "disapproval",
            "3": "disgust",
            "4": "fear",
            "5": "joy",
            "6": "love",
            "7": "neutral",
            "8": "sadness",
            "9": "surprise"
        }
        self.assertEqual(mapping, expected_labels)
        self.assertEqual(len(mapping), 10)

    def test_03_readiness_check_does_not_download_anything(self):
        """Test 3: Readiness check completes purely offline without making network calls or downloading."""
        readiness = check_muril_readiness(self.default_model_path)
        self.assertIn("model_name", readiness)
        self.assertIn("ready_for_inference", readiness)
        self.assertIn("reason", readiness)
        self.assertIsInstance(readiness["ready_for_inference"], bool)

    def test_04_missing_base_model_handled_safely(self):
        """Test 4: When base model weights are not in local cache, readiness check returns False with reason."""
        readiness = check_muril_readiness(self.default_model_path)
        # Verify base model availability check returns False for missing local weights
        self.assertFalse(readiness["base_model_available_locally"])
        self.assertFalse(readiness["ready_for_inference"])
        self.assertIn("Base MuRIL weights", readiness["reason"])
        self.assertIn("not available locally", readiness["reason"])

    def test_05_missing_adapter_handled_safely(self):
        """Test 5: Non-existent or empty directory returns ready_for_inference False."""
        tmpdir = tempfile.mkdtemp()
        try:
            readiness = check_muril_readiness(tmpdir)
            self.assertFalse(readiness["adapter_present"])
            self.assertFalse(readiness["ready_for_inference"])
            self.assertIn("Adapter configuration or model weights missing", readiness["reason"])
        finally:
            shutil.rmtree(tmpdir)

    def test_06_missing_tokenizer_handled_safely(self):
        """Test 6: Missing tokenizer files returned as ready_for_inference False."""
        tmpdir = tempfile.mkdtemp()
        try:
            # Create dummy adapter_config.json & weights & label_mapping but no tokenizer
            with open(os.path.join(tmpdir, "adapter_config.json"), "w") as f:
                json.dump({"base_model_name_or_path": "google/muril-base-cased"}, f)
            with open(os.path.join(tmpdir, "adapter_model.safetensors"), "wb") as f:
                f.write(b"dummy")
            with open(os.path.join(tmpdir, "label_mapping.json"), "w") as f:
                json.dump({"0": "neutral"}, f)

            readiness = check_muril_readiness(tmpdir)
            self.assertTrue(readiness["adapter_present"])
            self.assertFalse(readiness["tokenizer_present"])
            self.assertFalse(readiness["ready_for_inference"])
            self.assertIn("Tokenizer files missing", readiness["reason"])
        finally:
            shutil.rmtree(tmpdir)

    def test_07_readiness_result_contains_no_raw_complaint(self):
        """Test 7: check_muril_readiness output dictionary contains no complaint text or PII."""
        readiness = check_muril_readiness(self.default_model_path)
        forbidden_keys = {"text", "raw_text", "complaint", "pii", "user", "email"}
        for key in forbidden_keys:
            self.assertNotIn(key, readiness)

    def test_08_ml_analyzer_remains_safe_when_model_unavailable(self):
        """Test 8: Enabling ML when models are unavailable yields model_status 'not_loaded' without crashing."""
        os.environ[ML_ENABLED_ENV] = "true"
        os.environ[ML_MODEL_PATH_ENV] = "/non/existent/path/to/model"
        res = analyze_ml("Seniors are causing disturbance in the hostel wing.")
        self.assertEqual(res["model_status"], "not_loaded")
        self.assertEqual(res["emotion"]["label"], "unknown")
        self.assertEqual(res["emotion"]["score"], 0.0)

    def test_09_no_automatic_model_loading_on_instantiation(self):
        """Test 9: Instantiating MurilEmotionAdapter does not load weights or set loaded=True."""
        adapter = MurilEmotionAdapter()
        self.assertFalse(adapter.loaded)
        self.assertIsNone(adapter.model)
        self.assertIsNone(adapter.tokenizer)

    def test_10_no_automatic_external_network_download(self):
        """Test 10: MurilEmotionAdapter.is_available() returns False when base model is missing without network requests."""
        os.environ[ML_ENABLED_ENV] = "true"
        adapter = MurilEmotionAdapter()
        # is_available should return False because base weights are missing
        self.assertFalse(adapter.is_available())

    def test_11_existing_analysis_service_remains_unchanged(self):
        """Test 11: analyze_complaint pipeline continues to work seamlessly with ML disabled or unavailable."""
        os.environ[ML_ENABLED_ENV] = "false"
        complaint = "Freshers are being threatened by senior students in room 302."
        res = analyze_complaint(complaint)
        self.assertIn("ml_analysis", res)
        self.assertEqual(res["ml_analysis"]["model_status"], "not_loaded")
        self.assertIn("preliminary_risk", res)

    def test_12_is_base_model_cached_locally_returns_false(self):
        """Test 12: is_base_model_cached_locally returns False for non-cached model."""
        self.assertFalse(is_base_model_cached_locally("google/muril-base-cased"))
        self.assertFalse(is_base_model_cached_locally("non_existent/fake-model-12345"))


if __name__ == "__main__":
    unittest.main()
