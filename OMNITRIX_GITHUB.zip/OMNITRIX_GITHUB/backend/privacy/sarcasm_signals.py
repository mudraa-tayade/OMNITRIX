"""
OMNITRIX Privacy Transformation Engine - Sarcasm & Coded Language Signal Extractor
Extracts observable linguistic patterns of irony, sarcasm, coded distress, and conversational
withdrawal from protected text exclusively using deterministic regex pattern matching.

ARCHITECTURAL & SAFETY NOTICE:
These are deterministic heuristic linguistic markers and NOT a machine-learning sarcasm classifier.
Sarcasm and coded language cannot be definitively determined via simple keyword matching alone.
These signals serve exclusively as preliminary observable features for downstream contextual NLP models.
"""

import re
from typing import Dict, Any, List

# Sarcastic and ironic markers
SARCASTIC_PATTERNS: List[str] = [
    # Multi-word sarcastic phrases
    r'\b(?:yeah\s+right|what\s+a\s+joke|so\s+helpful|thanks\s+a\s+lot|best\s+day\s+ever|just\s+perfect|love\s+this|of\s+course)\b',
    # Single-word ironic triggers (matched with word boundaries)
    r'\b(?:great|amazing|wow)\b',
    # Hinglish sarcastic markers
    r'\b(?:bohot\s+badhiya|kya\s+baat\s+hai|wah\s+bhai|mast\s+hai)\b'
]

# Coded & evasive distress markers
CODED_LANGUAGE_PATTERNS: List[str] = [
    # English
    r'\b(?:everything\s+is\s+fine|nothing\s+is\s+wrong|don\'?t\s+worry\s+about\s+me|forget\s+it|leave\s+it|it\'?s\s+okay|i\'?m\s+okay|all\s+good|no\s+issue|never\s*mind|doesn\'?t\s+matter|you\s+know\s+what\s+happened|can\'?t\s+say|not\s+allowed\s+to\s+say)\b',
    # Hinglish
    r'\b(?:haan\s+sab\s+theek\s+hai|sab\s+theek\s+hai|bas\s+rehne\s+do|kuch\s+nahi|chhod\s+do|theek\s+hai\s+yaar|mat\s+pucho|rehne\s+do|samajh\s+jao|bol\s+nahi\s+sakt[ai]|puchna\s+mat)\b'
]

# Indirect distress and withdrawal markers
INDIRECT_DISTRESS_PATTERNS: List[str] = [
    # English
    r'\b(?:i\s+don\'?t\s+know\s+what\s+to\s+do|i\s+can\'?t\s+talk\s+about\s+it|i\s+don\'?t\s+want\s+to\s+say|please\s+don\'?t\s+ask|leave\s+me\s+alone|no\s+one\s+will\s+understand|there\s+is\s+no\s+point|what\'?s\s+the\s+use)\b',
    # Hinglish
    r'\b(?:mujhe\s+nahi\s+pata\s+kya\s+karu|main\s+nahi\s+bata\s+sakt[ai]|kisi\s+ko\s+samajh\s+nahi\s+aayega|kaise\s+batau|ab\s+kya\s+karu|kuch\s+samajh\s+nahi\s+aa\s+raha)\b'
]

def _count_pattern_matches(text_lower: str, patterns: List[str]) -> int:
    """Counts non-overlapping matches across a list of regex patterns in lowercase text."""
    count = 0
    for pat in patterns:
        matches = re.findall(pat, text_lower)
        count += len(matches)
    return count

def extract_sarcasm_signals(protected_text: str) -> Dict[str, Any]:
    """
    Extracts deterministic linguistic sarcasm and coded-language indicators from protected text.
    
    Guarantees:
      - Operates exclusively on protected_text (never raw text).
      - Does not modify protected_text.
      - NEVER returns matched phrases or keywords.
      - Returns strictly numeric counts and boolean flags.
      
    Returns:
      {
          "sarcasm_marker_count": int,
          "coded_language_marker_count": int,
          "indirect_distress_marker_count": int,
          "has_sarcasm_markers": bool,
          "has_coded_language_markers": bool,
          "has_indirect_distress": bool
      }
    """
    if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
        return {
            "sarcasm_marker_count": 0,
            "coded_language_marker_count": 0,
            "indirect_distress_marker_count": 0,
            "has_sarcasm_markers": False,
            "has_coded_language_markers": False,
            "has_indirect_distress": False
        }

    # Evaluate exclusively on lowercase copy without altering protected_text
    text_lower = protected_text.lower()

    sarcasm_count = _count_pattern_matches(text_lower, SARCASTIC_PATTERNS)
    coded_count = _count_pattern_matches(text_lower, CODED_LANGUAGE_PATTERNS)
    indirect_distress_count = _count_pattern_matches(text_lower, INDIRECT_DISTRESS_PATTERNS)

    return {
        "sarcasm_marker_count": sarcasm_count,
        "coded_language_marker_count": coded_count,
        "indirect_distress_marker_count": indirect_distress_count,
        "has_sarcasm_markers": sarcasm_count > 0,
        "has_coded_language_markers": coded_count > 0,
        "has_indirect_distress": indirect_distress_count > 0
    }
