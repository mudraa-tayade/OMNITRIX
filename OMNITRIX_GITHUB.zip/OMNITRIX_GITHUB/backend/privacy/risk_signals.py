"""
OMNITRIX Privacy Transformation Engine - Heuristic Risk Signal Extractor
Extracts observable linguistic signals (distress, threat, urgency, help-seeking, negative emotion)
from protected text exclusively using deterministic regex pattern matching.

ARCHITECTURAL & SAFETY NOTICE:
These are deterministic heuristic linguistic signals and NOT a medical or psychological
diagnosis, nor a final safety/ragging decision. They serve only as preliminary observable
features for downstream analysis pipelines.
"""

import re
from typing import Dict, Any, List

# Keyword & phrase patterns with word boundaries
DISTRESS_PATTERNS: List[str] = [
    # English
    r'\b(?:scared|afraid|fear|terrified|crying|helpless|alone|unsafe|worried|anxious|traumatized|panic|suicide|suicidal)\b',
    # Hinglish
    r'\b(?:darr|dar|dara|pareshan|tang|rona|ro\s+raha|ro\s+rahi|bahut\s+dar|mujhe\s+dar)\b'
]

THREAT_PATTERNS: List[str] = [
    # English
    r'\b(?:threat|threats|threatened|threatening|beat|beaten|beating|hit|hitting|hurt|hurting|kill|killing|blackmail|blackmailing|force|forced|forcing|ragging|ragged|abuse|abused|abusing|assault|harass|harassed|harassing|harassment|bully|bullied|bullying)\b',
    # Hinglish
    r'\b(?:dhamki|dhamkiya|maar|marna|marne|peeta|peetna)\b'
]

URGENCY_PATTERNS: List[str] = [
    # English
    r'\b(?:urgent|urgently|immediately|now|emergency|can\'?t\s+take\s+this|asap|tonight)\b',
    # Hinglish
    r'\b(?:abhi|turant|aaj\s+raat)\b'
]

HELP_SEEKING_PATTERNS: List[str] = [
    # English
    r'\b(?:please\s+help|help\s+me|need\s+help|save\s+me|complaint|report|protect\s+me|take\s+action)\b',
    # Hinglish
    r'\b(?:bachao|madad|help\s+karo|action\s+lo)\b'
]

NEGATIVE_EMOTION_PATTERNS: List[str] = [
    # English
    r'\b(?:sad|angry|depressed|scared|fear|cry|crying|upset|hopeless|humiliated|ashamed)\b',
    # Hinglish
    r'\b(?:gussa|udas|dukhi|sharminda)\b'
]

def _count_pattern_matches(text_lower: str, patterns: List[str]) -> int:
    """Counts non-overlapping matches across a list of regex patterns in lowercase text."""
    count = 0
    for pat in patterns:
        matches = re.findall(pat, text_lower)
        count += len(matches)
    return count

def extract_risk_signals(protected_text: str) -> Dict[str, Any]:
    """
    Extracts deterministic linguistic risk/distress indicators from protected text.
    
    Guarantees:
      - Operates exclusively on protected_text (never raw text).
      - Does not modify protected_text.
      - NEVER returns matched keyword strings or sensitive terms.
      - Returns strictly numeric counts and boolean flags.
      
    Returns:
      {
          "distress_keyword_count": int,
          "threat_keyword_count": int,
          "urgency_keyword_count": int,
          "help_seeking_count": int,
          "negative_emotion_count": int,
          "has_threat_language": bool,
          "has_help_seeking": bool,
          "has_urgent_language": bool
      }
    """
    if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
        return {
            "distress_keyword_count": 0,
            "threat_keyword_count": 0,
            "urgency_keyword_count": 0,
            "help_seeking_count": 0,
            "negative_emotion_count": 0,
            "has_threat_language": False,
            "has_help_seeking": False,
            "has_urgent_language": False
        }

    text_lower = protected_text.lower()

    distress_count = _count_pattern_matches(text_lower, DISTRESS_PATTERNS)
    threat_count = _count_pattern_matches(text_lower, THREAT_PATTERNS)
    urgency_count = _count_pattern_matches(text_lower, URGENCY_PATTERNS)
    help_count = _count_pattern_matches(text_lower, HELP_SEEKING_PATTERNS)
    negative_emotion_count = _count_pattern_matches(text_lower, NEGATIVE_EMOTION_PATTERNS)

    return {
        "distress_keyword_count": distress_count,
        "threat_keyword_count": threat_count,
        "urgency_keyword_count": urgency_count,
        "help_seeking_count": help_count,
        "negative_emotion_count": negative_emotion_count,
        "has_threat_language": threat_count > 0,
        "has_help_seeking": help_count > 0,
        "has_urgent_language": urgency_count > 0
    }
