"""
Unit tests for OMNITRIX Public Privacy Engine API (protect_complaint).
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy import protect_complaint, protect_text
from backend.privacy.engine import protect_complaint as protect_complaint_direct

class TestPrivacyEngine(unittest.TestCase):

    def test_01_normal_complaint(self):
        """Verify normal well-formatted complaint passes through with proper structure."""
        text = "First year students are asked to gather in the study hall."
        result = protect_complaint(text)

        self.assertEqual(result["protected_text"], text)
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["safe_representation"]["language_hint"], "english")

    def test_02_complaint_with_phone_and_email(self):
        """Verify phone and email are masked via the engine."""
        text = "Contact 9876543210 or admin@college.edu"
        result = protect_complaint(text)

        self.assertTrue(result["pii_masked"])
        self.assertIn("[PHONE]", result["protected_text"])
        self.assertIn("[EMAIL]", result["protected_text"])
        self.assertNotIn("9876543210", result["protected_text"])
        self.assertNotIn("admin@college.edu", result["protected_text"])

    def test_03_complaint_with_person_name(self):
        """Verify student name is masked to [PERSON]."""
        text = "My name is Rahul and seniors threatened me."
        result = protect_complaint(text)

        self.assertTrue(result["pii_masked"])
        self.assertIn("[PERSON]", result["protected_text"])
        self.assertNotIn("Rahul", result["protected_text"])
        self.assertEqual(result["privacy_audit"]["person_name_count"], 1)

    def test_04_hinglish_complaint(self):
        """Verify Hinglish code-mixed complaint is correctly handled."""
        text = "Bhai bohot darr lag raha hai hostel me, seniors abuse kar rahe hai."
        result = protect_complaint(text)

        self.assertEqual(result["safe_representation"]["language_hint"], "hinglish")
        self.assertTrue(result["risk_signals"]["distress_keyword_count"] >= 1)

    def test_05_sarcasm_and_coded_complaint(self):
        """Verify sarcastic and evasive language is flagged."""
        text = "Yeah right, everything is fine, thanks a lot for the help."
        result = protect_complaint(text)

        self.assertTrue(result["sarcasm_signals"]["has_sarcasm_markers"])
        self.assertTrue(result["sarcasm_signals"]["has_coded_language_markers"])

    def test_06_threat_and_distress_complaint(self):
        """Verify threat and distress language is detected."""
        text = "Seniors threatened to beat me if I don't follow their rules. I am terrified."
        result = protect_complaint(text)

        self.assertTrue(result["risk_signals"]["has_threat_language"])
        self.assertTrue(result["risk_signals"]["distress_keyword_count"] >= 1)

    def test_07_multiple_privacy_transformations_together(self):
        """Verify simultaneous Name + Phone + Room + All-Caps + Punctuation."""
        text = "MY NAME IS RAHUL AND I LIVE IN ROOM 204. CALL ME ON 9876543210 PLEAAAASE HELP ME!!!!"
        result = protect_complaint(text)

        self.assertTrue(result["pii_masked"])
        self.assertIn("[PERSON]", result["protected_text"])
        self.assertIn("[ROOM]", result["protected_text"])
        self.assertIn("[PHONE]", result["protected_text"])
        self.assertIn("please help me!", result["protected_text"])
        self.assertTrue(result["privacy_audit"]["style_normalized"])
        self.assertTrue(result["risk_signals"]["has_help_seeking"])

    def test_08_empty_string_input(self):
        """Verify empty string returns clean default structure safely."""
        result = protect_complaint("")

        self.assertEqual(result["protected_text"], "")
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["safe_representation"]["token_count"], 0)
        self.assertEqual(result["privacy_audit"]["phone_count"], 0)

    def test_09_whitespace_only_input(self):
        """Verify whitespace-only string returns clean empty structure safely."""
        result = protect_complaint("   \t\n  ")

        self.assertEqual(result["protected_text"], "")
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["feature_summary"]["token_count"], 0)

    def test_10_none_input(self):
        """Verify None input does not crash and returns safe structure."""
        result = protect_complaint(None)

        self.assertEqual(result["protected_text"], "")
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["feature_summary"]["language_hint"], "unknown")

    def test_11_verify_raw_text_not_returned(self):
        """Verify raw text is never returned in any key of the output dictionary."""
        raw_secret = "Private secret message that must not leak anywhere."
        result = protect_complaint(raw_secret)

        self.assertNotIn("raw_text", result)
        self.assertNotIn("original_text", result)
        self.assertNotIn("raw_complaint", result)

    def test_12_verify_all_sections_present(self):
        """Verify all core top-level dictionary keys including preliminary_risk are present."""
        result = protect_complaint("Test complaint")
        expected_sections = {
            "protected_text",
            "pii_masked",
            "safe_representation",
            "privacy_audit",
            "risk_signals",
            "sarcasm_signals",
            "feature_summary",
            "preliminary_risk"
        }
        self.assertEqual(set(result.keys()), expected_sections)

    def test_13_verify_feature_summary_present_and_populated(self):
        """Verify feature_summary contains the expected aggregated keys."""
        result = protect_complaint("Seniors are forcing us to clean their rooms.")
        features = result["feature_summary"]

        self.assertIn("language_hint", features)
        self.assertIn("token_count", features)
        self.assertIn("threat_keyword_count", features)
        self.assertIn("has_threat_language", features)
        self.assertTrue(features["has_threat_language"])

    def test_14_verify_engine_delegates_to_pipeline(self):
        """Verify protect_complaint output identically matches protect_text output."""
        sample_complaint = "My friend Aman from CSE was threatened in room 102. Call 9876543210 immediately!"
        
        engine_result = protect_complaint(sample_complaint)
        pipeline_result = protect_text(sample_complaint)

        self.assertEqual(engine_result, pipeline_result)

    def test_15_verify_preliminary_risk_in_engine(self):
        """Verify protect_complaint includes preliminary_risk structure."""
        text = "Seniors threatened to beat me in room 101. Call 9876543210!"
        result = protect_complaint(text)

        self.assertIn("preliminary_risk", result)
        risk_dec = result["preliminary_risk"]

        self.assertIn("risk_level", risk_dec)
        self.assertIn("risk_score", risk_dec)
        self.assertIn("reasons", risk_dec)

        self.assertIsInstance(risk_dec["risk_score"], int)
        self.assertGreaterEqual(risk_dec["risk_score"], 0)
        self.assertLessEqual(risk_dec["risk_score"], 100)
        self.assertIn(risk_dec["risk_level"], {"low", "medium", "high", "critical"})


if __name__ == "__main__":
    unittest.main()
