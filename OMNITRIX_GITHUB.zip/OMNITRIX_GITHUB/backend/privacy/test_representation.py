"""
Unit tests for OMNITRIX Safe Analysis Representation.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.representation import build_safe_representation
from backend.privacy.pipeline import protect_text

class TestSafeRepresentation(unittest.TestCase):

    def test_01_english_complaint(self):
        """Verify English complaint is identified with english language hint."""
        text = "Seniors are threatening junior students in the hostel every night."
        rep = build_safe_representation(text)
        self.assertEqual(rep["language_hint"], "english")
        self.assertEqual(rep["token_count"], 10)
        self.assertFalse(rep["has_question"])
        self.assertFalse(rep["has_exclamation"])

    def test_02_hinglish_complaint(self):
        """Verify Hinglish complaint is identified with hinglish language hint."""
        text = "Bhai bohot darr lag raha hai mujhe hostel me."
        rep = build_safe_representation(text)
        self.assertEqual(rep["language_hint"], "hinglish")
        self.assertTrue(rep["token_count"] > 0)

    def test_03_mixed_complaint(self):
        """Verify mixed English + Hinglish text gets mixed hint."""
        text = "Seniors in the hostel are saying ki kal subah room pe aana padega."
        rep = build_safe_representation(text)
        self.assertEqual(rep["language_hint"], "mixed")

    def test_04_empty_input(self):
        """Verify empty and whitespace inputs return clean zeroed representation."""
        rep = build_safe_representation("")
        self.assertEqual(rep["language_hint"], "unknown")
        self.assertEqual(rep["token_count"], 0)
        self.assertEqual(rep["character_count"], 0)
        self.assertFalse(rep["has_question"])
        self.assertFalse(rep["has_exclamation"])
        self.assertFalse(rep["has_repeated_punctuation"])

    def test_05_question_detection(self):
        """Verify question mark detection."""
        text = "Why are they forcing us to stand outside?"
        rep = build_safe_representation(text)
        self.assertTrue(rep["has_question"])
        self.assertFalse(rep["has_exclamation"])

    def test_06_exclamation_detection(self):
        """Verify exclamation mark detection."""
        text = "Please stop them immediately!"
        rep = build_safe_representation(text)
        self.assertTrue(rep["has_exclamation"])
        self.assertFalse(rep["has_question"])

    def test_07_token_count(self):
        """Verify whitespace token count accuracy."""
        text = "They locked the room door."
        rep = build_safe_representation(text)
        self.assertEqual(rep["token_count"], 5)
        self.assertEqual(rep["character_count"], len(text))

    def test_08_representation_uses_protected_text(self):
        """Verify representation runs through the pipeline on protected text."""
        raw_input = "Pleaaaase help meee in room 204!!!!"
        result = protect_text(raw_input)
        
        self.assertIn("safe_representation", result)
        rep = result["safe_representation"]
        self.assertIn("[ROOM]", result["protected_text"])
        self.assertNotIn("204", result["protected_text"])
        # Token count reflects sanitized tokens ("Please help me in room [ROOM]!")
        self.assertEqual(rep["token_count"], len(result["protected_text"].split()))

    def test_09_no_raw_pii_in_representation(self):
        """Verify phone, email, and room numbers never leak into representation keys/values."""
        raw_input = "Call 9876543210 or email test@college.edu"
        result = protect_text(raw_input)
        
        # Verify result contains only designated fields and zero raw PII
        self.assertNotIn("9876543210", str(result))
        self.assertNotIn("test@college.edu", str(result))
        self.assertTrue(result["pii_masked"])

    def test_10_person_token_preserved(self):
        """Verify [PERSON] token remains in protected text and counts as standard token."""
        raw_input = "My name is Rahul and seniors threatened me."
        result = protect_text(raw_input)
        
        self.assertIn("[PERSON]", result["protected_text"])
        self.assertNotIn("Rahul", result["protected_text"])
        rep = result["safe_representation"]
        self.assertTrue(rep["token_count"] > 0)
        self.assertEqual(rep["language_hint"], "english")

if __name__ == "__main__":
    unittest.main()
