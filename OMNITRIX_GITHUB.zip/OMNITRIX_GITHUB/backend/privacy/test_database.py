import os
import shutil
import tempfile
import sqlite3
import unittest

from backend.privacy.engine import protect_complaint
from backend.privacy.record import create_complaint_record, FORBIDDEN_IDENTITY_FIELDS
from backend.privacy.database import (
    init_database,
    save_complaint_record,
    get_complaint_record,
    get_all_complaint_records,
    update_complaint_status,
    record_status_change,
    get_status_history,
    ALLOWED_STATUSES,
    DEFAULT_DB_PATH
)


class TestPrivacyDatabase(unittest.TestCase):
    def setUp(self):
        # Create an isolated temporary directory for test databases
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_complaints.db")

    def tearDown(self):
        # Clean up temporary test directory and all created database files
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_01_database_initializes_successfully(self):
        """Test 1: Database initializes successfully and creates database file."""
        self.assertFalse(os.path.exists(self.test_db_path))
        init_database(self.test_db_path)
        self.assertTrue(os.path.exists(self.test_db_path))

    def test_02_table_is_created(self):
        """Test 2: Complaints table and history table are created with expected schema."""
        init_database(self.test_db_path)
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('complaints', 'complaint_status_history');")
        tables = [r[0] for r in cursor.fetchall()]
        conn.close()
        self.assertIn("complaints", tables)
        self.assertIn("complaint_status_history", tables)

    def test_03_privacy_safe_complaint_can_be_saved(self):
        """Test 3: A privacy-safe complaint record generated from protect_complaint can be saved."""
        init_database(self.test_db_path)
        protected = protect_complaint("Help me seniors in Room 302 threatened me call 9876543210")
        record = create_complaint_record(protected)

        # Saving should succeed without error
        save_complaint_record(record, self.test_db_path)

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM complaints;")
        count = cursor.fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)

    def test_04_saved_complaint_can_be_retrieved_by_id(self):
        """Test 4: Saved complaint can be retrieved accurately by complaint_id."""
        init_database(self.test_db_path)
        protected = protect_complaint("Very bad hostel situation seniors torturing in room 101")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved["complaint_id"], record["complaint_id"])
        self.assertEqual(retrieved["status"], "new")
        self.assertEqual(retrieved["protected_text"], record["protected_text"])
        self.assertEqual(retrieved["pii_masked"], record["pii_masked"])

    def test_05_retrieved_record_preserves_feature_summary(self):
        """Test 5: Retrieved record preserves all elements of feature_summary."""
        init_database(self.test_db_path)
        protected = protect_complaint("Hostel life is great wonderful ragging culture everywhere")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIn("feature_summary", retrieved)
        self.assertEqual(retrieved["feature_summary"], record["feature_summary"])
        self.assertEqual(
            retrieved["feature_summary"].get("has_sarcasm_signals"),
            record["feature_summary"].get("has_sarcasm_signals")
        )

    def test_06_retrieved_record_preserves_risk_signals(self):
        """Test 6: Retrieved record preserves risk_signals dictionary structure."""
        init_database(self.test_db_path)
        protected = protect_complaint("Please help me urgently seniors are beating me")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIn("risk_signals", retrieved)
        self.assertEqual(retrieved["risk_signals"], record["risk_signals"])
        self.assertTrue(retrieved["risk_signals"].get("has_threat_language"))
        self.assertTrue(retrieved["risk_signals"].get("has_help_seeking"))

    def test_07_retrieved_record_preserves_sarcasm_signals(self):
        """Test 7: Retrieved record preserves sarcasm_signals dictionary structure."""
        init_database(self.test_db_path)
        protected = protect_complaint("Such a welcoming department truly wonderful hostel experience")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIn("sarcasm_signals", retrieved)
        self.assertEqual(retrieved["sarcasm_signals"], record["sarcasm_signals"])

    def test_08_retrieved_record_preserves_privacy_audit(self):
        """Test 8: Retrieved record preserves zero-knowledge privacy audit metrics."""
        init_database(self.test_db_path)
        protected = protect_complaint("Call Rahul at 9876543210 or email test@college.edu in Room 404")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIn("privacy_audit", retrieved)
        self.assertEqual(retrieved["privacy_audit"], record["privacy_audit"])
        self.assertTrue(retrieved["privacy_audit"].get("pii_detected"))
        self.assertGreater(retrieved["privacy_audit"].get("phone_count", 0), 0)

    def test_09_retrieved_record_preserves_safe_representation(self):
        """Test 9: Retrieved record preserves safe_representation metadata and tokens."""
        init_database(self.test_db_path)
        protected = protect_complaint("Bhai hostel me ragging chal rahi hai emergency help")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIn("safe_representation", retrieved)
        self.assertEqual(retrieved["safe_representation"], record["safe_representation"])
        self.assertIn(retrieved["safe_representation"].get("language_hint"), ["hinglish", "mixed"])

    def test_10_multiple_records_can_be_retrieved(self):
        """Test 10: Multiple complaint records can be saved and retrieved via get_all_complaint_records."""
        init_database(self.test_db_path)
        texts = [
            "Complaint 1: seniors threatening juniors in canteen",
            "Complaint 2: call 9876543210 hostel wing B issues",
            "Complaint 3: such polite seniors truly amazing culture"
        ]
        saved_ids = []
        for text in texts:
            rec = create_complaint_record(protect_complaint(text))
            save_complaint_record(rec, self.test_db_path)
            saved_ids.append(rec["complaint_id"])

        all_records = get_all_complaint_records(self.test_db_path)
        self.assertEqual(len(all_records), 3)
        retrieved_ids = [r["complaint_id"] for r in all_records]
        for cid in saved_ids:
            self.assertIn(cid, retrieved_ids)

    def test_11_duplicate_complaint_ids_are_rejected_safely(self):
        """Test 11: Attempting to insert duplicate complaint_id raises sqlite3.IntegrityError."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Some sample complaint text"))
        save_complaint_record(record, self.test_db_path)

        # Attempting to save the identical record again (same complaint_id PRIMARY KEY)
        with self.assertRaises(sqlite3.IntegrityError):
            save_complaint_record(record, self.test_db_path)

    def test_12_unknown_complaint_id_returns_none(self):
        """Test 12: Querying non-existent complaint_id returns None."""
        init_database(self.test_db_path)
        self.assertIsNone(get_complaint_record("non-existent-uuid-12345", self.test_db_path))
        self.assertIsNone(get_complaint_record("", self.test_db_path))
        self.assertIsNone(get_complaint_record(None, self.test_db_path))

    def test_13_raw_complaint_text_is_never_stored(self):
        """Test 13: Raw complaint text and original PII are never in the database."""
        init_database(self.test_db_path)
        raw_phone = "9876543210"
        raw_email = "victim.student@university.ac.in"
        raw_input = f"My name is Amit Sharma, phone {raw_phone}, email {raw_email}. Seniors harassed me."

        protected = protect_complaint(raw_input)
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        # Directly inspect the raw SQLite file contents and queries
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT protected_text, safe_representation, privacy_audit FROM complaints WHERE complaint_id=?", (record["complaint_id"],))
        row = cursor.fetchone()
        conn.close()

        stored_protected = row[0]
        stored_repr = row[1]
        stored_audit = row[2]

        # Ensure raw PII never appears anywhere in the stored columns
        self.assertNotIn(raw_phone, stored_protected)
        self.assertNotIn(raw_phone, stored_repr)
        self.assertNotIn(raw_phone, stored_audit)

        self.assertNotIn(raw_email, stored_protected)
        self.assertNotIn(raw_email, stored_repr)
        self.assertNotIn(raw_email, stored_audit)

        self.assertNotIn("Amit Sharma", stored_protected)
        self.assertNotIn("Amit Sharma", stored_repr)
        self.assertNotIn("Amit Sharma", stored_audit)

    def test_14_forbidden_identity_fields_are_not_database_columns(self):
        """Test 14: Forbidden identity keys are not schema columns and cannot be smuggled in records."""
        init_database(self.test_db_path)
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(complaints);")
        columns = [row[1] for row in cursor.fetchall()]
        conn.close()

        for forbidden in FORBIDDEN_IDENTITY_FIELDS:
            self.assertNotIn(forbidden, columns)

        # Attempting to save a dict with forbidden keys directly raises ValueError
        bad_record = {
            "complaint_id": "bad-id-1",
            "raw_text": "This is raw secret text",
            "student_name": "John Doe",
            "protected_text": "[PERSON] reported ragging",
            "pii_masked": True
        }
        with self.assertRaises(ValueError):
            save_complaint_record(bad_record, self.test_db_path)

    def test_15_calling_init_database_multiple_times_does_not_crash(self):
        """Test 15: init_database() is safe to invoke repeatedly (idempotent)."""
        # Call multiple times consecutively
        init_database(self.test_db_path)
        init_database(self.test_db_path)
        init_database(self.test_db_path)

        # Ensure database is still valid and operational
        record = create_complaint_record(protect_complaint("Test complaint after multiple inits"))
        save_complaint_record(record, self.test_db_path)
        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertIsNotNone(retrieved)

    def test_16_tests_do_not_touch_production_database(self):
        """Test 16: Verifies that tests ran against temporary DB and didn't touch default complaints.db."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)

    def test_17_update_complaint_status_success(self):
        """Test 17: Existing complaint status can be updated to 'in_review', 'resolved', and 'closed'."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Seniors harassing juniors in hostel"))
        save_complaint_record(record, self.test_db_path)

        # Update to in_review
        updated = update_complaint_status(record["complaint_id"], "in_review", self.test_db_path)
        self.assertIsNotNone(updated)
        self.assertEqual(updated["status"], "in_review")

        # Update to resolved
        updated2 = update_complaint_status(record["complaint_id"], "resolved", self.test_db_path)
        self.assertEqual(updated2["status"], "resolved")

        # Update to closed
        updated3 = update_complaint_status(record["complaint_id"], "closed", self.test_db_path)
        self.assertEqual(updated3["status"], "closed")

    def test_18_update_complaint_status_persisted(self):
        """Test 18: Updated status persists across independent database queries."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Threat report in room 202"))
        save_complaint_record(record, self.test_db_path)

        update_complaint_status(record["complaint_id"], "in_review", self.test_db_path)

        # Retrieve independently
        fetched = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertEqual(fetched["status"], "in_review")

    def test_19_update_unknown_complaint_id_returns_none(self):
        """Test 19: update_complaint_status on non-existent ID returns None without error."""
        init_database(self.test_db_path)
        res = update_complaint_status("non-existent-uuid-9999", "in_review", self.test_db_path)
        self.assertIsNone(res)
        self.assertIsNone(update_complaint_status("", "in_review", self.test_db_path))
        self.assertIsNone(update_complaint_status(None, "in_review", self.test_db_path))  # type: ignore

    def test_20_update_preserves_all_other_fields(self):
        """Test 20: Updating status leaves protected_text, signals, audit, and features completely unchanged."""
        init_database(self.test_db_path)
        protected = protect_complaint("Please help me urgently seniors in room 101 are threatening freshers")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        # Update status
        updated = update_complaint_status(record["complaint_id"], "resolved", self.test_db_path)

        # Verify ONLY status changed
        self.assertEqual(updated["status"], "resolved")
        self.assertEqual(updated["complaint_id"], record["complaint_id"])
        self.assertEqual(updated["protected_text"], record["protected_text"])
        self.assertEqual(updated["pii_masked"], record["pii_masked"])
        self.assertEqual(updated["safe_representation"], record["safe_representation"])
        self.assertEqual(updated["privacy_audit"], record["privacy_audit"])
        self.assertEqual(updated["risk_signals"], record["risk_signals"])
        self.assertEqual(updated["sarcasm_signals"], record["sarcasm_signals"])
        self.assertEqual(updated["feature_summary"], record["feature_summary"])

    def test_21_invalid_status_raises_value_error(self):
        """Test 21: update_complaint_status rejects arbitrary/invalid status values with ValueError."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Sample text"))
        save_complaint_record(record, self.test_db_path)

        invalid_statuses = ["pending", "deleted", "active", "IN_REVIEW", "arbitrary_status", "", None]
        for inv in invalid_statuses:
            with self.assertRaises(ValueError):
                update_complaint_status(record["complaint_id"], inv, self.test_db_path)  # type: ignore

    def test_22_status_change_creates_one_history_row(self):
        """Test 22: Changing status from 'new' to 'in_review' creates exactly one history record."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Incident in canteen."))
        save_complaint_record(record, self.test_db_path)

        # Update status
        update_complaint_status(record["complaint_id"], "in_review", self.test_db_path)

        history = get_status_history(record["complaint_id"], self.test_db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["complaint_id"], record["complaint_id"])
        self.assertEqual(history[0]["previous_status"], "new")
        self.assertEqual(history[0]["new_status"], "in_review")
        self.assertIsNotNone(history[0]["changed_at"])
        self.assertGreater(len(str(history[0]["changed_at"])), 5)

    def test_23_same_status_update_creates_no_history(self):
        """Test 23: Updating status to the same current value (e.g. 'new' -> 'new') creates NO history row."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Incident in hostel."))
        save_complaint_record(record, self.test_db_path)

        # Re-apply 'new'
        updated = update_complaint_status(record["complaint_id"], "new", self.test_db_path)
        self.assertIsNotNone(updated)
        self.assertEqual(updated["status"], "new")

        # History must be empty
        history = get_status_history(record["complaint_id"], self.test_db_path)
        self.assertEqual(len(history), 0)

    def test_24_multiple_status_changes_create_ordered_history(self):
        """Test 24: Multiple status transitions create history rows in strict chronological order."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Multiple status transitions test."))
        cid = record["complaint_id"]
        save_complaint_record(record, self.test_db_path)

        # Transitions: new -> in_review -> resolved -> closed
        update_complaint_status(cid, "in_review", self.test_db_path)
        update_complaint_status(cid, "resolved", self.test_db_path)
        update_complaint_status(cid, "closed", self.test_db_path)

        history = get_status_history(cid, self.test_db_path)
        self.assertEqual(len(history), 3)

        self.assertEqual(history[0]["previous_status"], "new")
        self.assertEqual(history[0]["new_status"], "in_review")

        self.assertEqual(history[1]["previous_status"], "in_review")
        self.assertEqual(history[1]["new_status"], "resolved")

        self.assertEqual(history[2]["previous_status"], "resolved")
        self.assertEqual(history[2]["new_status"], "closed")

    def test_25_history_table_contains_no_complaint_text_or_pii(self):
        """Test 25: complaint_status_history contains strictly status transition fields and zero text/PII."""
        init_database(self.test_db_path)
        raw_secret = "MY_VERY_SECRET_PHONE_9988776655"
        record = create_complaint_record(protect_complaint(f"Secret harassment {raw_secret}"))
        save_complaint_record(record, self.test_db_path)

        update_complaint_status(record["complaint_id"], "in_review", self.test_db_path)

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(complaint_status_history);")
        columns = [row[1] for row in cursor.fetchall()]

        # Verify schema
        expected_columns = ["history_id", "complaint_id", "previous_status", "new_status", "changed_at"]
        self.assertEqual(columns, expected_columns)

        cursor.execute("SELECT * FROM complaint_status_history;")
        all_rows = cursor.fetchall()
        conn.close()

        row_str = str(all_rows)
        self.assertNotIn(raw_secret, row_str)
        self.assertNotIn("harassment", row_str)
        self.assertNotIn("protected_text", row_str)

    def test_26_history_contains_no_analytical_signals(self):
        """Test 26: History table contains zero risk signals, sarcasm signals, or feature vectors."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Urgent beating report in room 202"))
        save_complaint_record(record, self.test_db_path)

        update_complaint_status(record["complaint_id"], "in_review", self.test_db_path)
        history = get_status_history(record["complaint_id"], self.test_db_path)

        for item in history:
            self.assertNotIn("risk_signals", item)
            self.assertNotIn("sarcasm_signals", item)
            self.assertNotIn("safe_representation", item)
            self.assertNotIn("feature_summary", item)
            self.assertNotIn("privacy_audit", item)

    def test_27_record_status_change_direct_function(self):
        """Test 27: Direct record_status_change function records audit transition and validates statuses."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Direct history record test"))
        save_complaint_record(record, self.test_db_path)

        record_status_change(record["complaint_id"], "new", "in_review", self.test_db_path)
        history = get_status_history(record["complaint_id"], self.test_db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["previous_status"], "new")
        self.assertEqual(history[0]["new_status"], "in_review")

        # Invalid previous_status / new_status
        with self.assertRaises(ValueError):
            record_status_change(record["complaint_id"], "invalid", "in_review", self.test_db_path)
        with self.assertRaises(ValueError):
            record_status_change(record["complaint_id"], "new", "invalid", self.test_db_path)

    def test_28_unknown_complaint_id_does_not_create_history(self):
        """Test 28: Attempting to update a non-existent complaint creates no history."""
        init_database(self.test_db_path)
        res = update_complaint_status("non-existent-uuid-0000", "in_review", self.test_db_path)
        self.assertIsNone(res)

        history = get_status_history("non-existent-uuid-0000", self.test_db_path)
        self.assertEqual(len(history), 0)

    def test_29_transactional_rollback_on_history_failure(self):
        """Test 29: Status update and history insertion are atomic; failure rolls back both."""
        init_database(self.test_db_path)
        record = create_complaint_record(protect_complaint("Transaction test"))
        cid = record["complaint_id"]
        save_complaint_record(record, self.test_db_path)

        # Create a trigger that causes an abort on INSERT INTO complaint_status_history
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TRIGGER force_history_abort
            BEFORE INSERT ON complaint_status_history
            BEGIN
                SELECT RAISE(ABORT, 'forced history insert error');
            END;
            """
        )
        conn.commit()
        conn.close()

        # Attempt update_complaint_status - this should fail during history insertion
        with self.assertRaises((sqlite3.IntegrityError, sqlite3.OperationalError)):
            update_complaint_status(cid, "in_review", self.test_db_path)

        # Verify rollback: complaint status must still be 'new', and history count must be 0
        rec = get_complaint_record(cid, self.test_db_path)
        self.assertEqual(rec["status"], "new")
        hist = get_status_history(cid, self.test_db_path)
        self.assertEqual(len(hist), 0)

    def test_30_preliminary_risk_persisted_and_retrieved(self):
        """Test 30: preliminary_risk dictionary is correctly saved and retrieved from SQLite."""
        init_database(self.test_db_path)
        raw_text = "Seniors threatened to beat me in room 101. Call 9876543210!"
        protected = protect_complaint(raw_text)
        record = create_complaint_record(protected)
        cid = record["complaint_id"]

        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(cid, self.test_db_path)
        self.assertIsNotNone(retrieved)
        self.assertIn("preliminary_risk", retrieved)
        self.assertEqual(retrieved["preliminary_risk"], record["preliminary_risk"])

        risk_dec = retrieved["preliminary_risk"]
        self.assertIn("risk_level", risk_dec)
        self.assertIn("risk_score", risk_dec)
        self.assertIn("reasons", risk_dec)
        self.assertIsInstance(risk_dec["risk_score"], int)
        self.assertIn(risk_dec["risk_level"], {"low", "medium", "high", "critical"})

    def test_31_get_all_complaint_records_includes_preliminary_risk(self):
        """Test 31: get_all_complaint_records includes preliminary_risk in each returned record."""
        init_database(self.test_db_path)
        record1 = create_complaint_record(protect_complaint("First issue"))
        record2 = create_complaint_record(protect_complaint("Second issue"))
        save_complaint_record(record1, self.test_db_path)
        save_complaint_record(record2, self.test_db_path)

        all_records = get_all_complaint_records(self.test_db_path)
        self.assertEqual(len(all_records), 2)
        for rec in all_records:
            self.assertIn("preliminary_risk", rec)
            self.assertIsInstance(rec["preliminary_risk"]["risk_score"], int)

    def test_32_old_database_schema_migration_safe(self):
        """Test 32: Seamless ALTER TABLE migration for pre-existing databases without preliminary_risk column."""
        # 1. Manually create an old database schema without preliminary_risk column
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE complaints (
                complaint_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                protected_text TEXT NOT NULL,
                pii_masked INTEGER NOT NULL,
                safe_representation TEXT NOT NULL,
                privacy_audit TEXT NOT NULL,
                risk_signals TEXT NOT NULL,
                sarcasm_signals TEXT NOT NULL,
                feature_summary TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        old_cid = "old-legacy-uuid-1111"
        cursor.execute(
            """
            INSERT INTO complaints (
                complaint_id, status, protected_text, pii_masked,
                safe_representation, privacy_audit, risk_signals, sarcasm_signals, feature_summary
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (old_cid, "new", "Old protected text", 0, "{}", "{}", "{}", "{}", "{}")
        )
        conn.commit()
        conn.close()

        # 2. Run init_database migration
        init_database(self.test_db_path)

        # 3. Verify preliminary_risk column was added via PRAGMA
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(complaints);")
        columns = [col[1] for col in cursor.fetchall()]
        conn.close()
        self.assertIn("preliminary_risk", columns)

        # 4. Verify old row is readable and returns safe default preliminary_risk
        old_record = get_complaint_record(old_cid, self.test_db_path)
        self.assertIsNotNone(old_record)
        self.assertIn("preliminary_risk", old_record)
        self.assertEqual(old_record["preliminary_risk"]["risk_score"], 0)
        self.assertEqual(old_record["preliminary_risk"]["risk_level"], "low")
        self.assertEqual(old_record["preliminary_risk"]["reasons"], [])

        # 5. Verify new complaint records can be saved into migrated database
        new_record = create_complaint_record(protect_complaint("Threat in hostel!"))
        save_complaint_record(new_record, self.test_db_path)
        new_retrieved = get_complaint_record(new_record["complaint_id"], self.test_db_path)
        self.assertIsNotNone(new_retrieved)
        self.assertIn("preliminary_risk", new_retrieved)

    def test_33_database_indexes_created(self):
        """Test 33: Verifies idx_complaints_status, idx_complaints_created_at, idx_history_complaint_id exist."""
        init_database(self.test_db_path)
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index';")
        index_names = [row[0] for row in cursor.fetchall()]
        conn.close()

        self.assertIn("idx_complaints_status", index_names)
        self.assertIn("idx_complaints_created_at", index_names)
        self.assertIn("idx_history_complaint_id", index_names)

    def test_34_foreign_key_pragmas_enabled(self):
        """Test 34: Verifies PRAGMA foreign_keys = ON is enforced on database connections."""
        init_database(self.test_db_path)
        from backend.privacy.database import _get_connection
        conn = _get_connection(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA foreign_keys;")
        fk_enabled = cursor.fetchone()[0]
        conn.close()
        self.assertEqual(fk_enabled, 1)

    def test_35_check_constraint_rejects_invalid_status(self):
        """Test 35: Direct SQL insert of an invalid status fails CHECK constraint."""
        init_database(self.test_db_path)
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        with self.assertRaises(sqlite3.IntegrityError):
            cursor.execute(
                """
                INSERT INTO complaints (
                    complaint_id, status, protected_text, pii_masked,
                    safe_representation, privacy_audit, risk_signals, sarcasm_signals, feature_summary
                ) VALUES ('invalid-status-uuid', 'invalid_status_value', 'text', 0, '{}', '{}', '{}', '{}', '{}')
                """
            )
            conn.commit()
        conn.close()

    def test_36_wal_journal_mode_enabled_for_file_databases(self):
        """Test 36: Verifies WAL journal mode is configured on file-backed database connections."""
        init_database(self.test_db_path)
        from backend.privacy.database import _get_connection
        conn = _get_connection(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode;")
        mode = cursor.fetchone()[0].lower()
        conn.close()
        self.assertEqual(mode, "wal")

    def test_37_created_at_timestamp_is_present_in_record(self):
        """Test 37: Verifies created_at timestamp is present and non-empty in retrieved complaint records."""
        init_database(self.test_db_path)
        rec = create_complaint_record(protect_complaint("Timestamp persistence test."))
        save_complaint_record(rec, self.test_db_path)

        retrieved = get_complaint_record(rec["complaint_id"], self.test_db_path)
        self.assertIsNotNone(retrieved)
        self.assertIn("created_at", retrieved)
        self.assertIsInstance(retrieved["created_at"], str)
        self.assertGreater(len(retrieved["created_at"]), 5)

    def test_38_cascade_delete_removes_history_records(self):
        """Test 38: Deleting a complaint record automatically cascades deletion of status history."""
        init_database(self.test_db_path)
        rec = create_complaint_record(protect_complaint("Cascade deletion test."))
        cid = rec["complaint_id"]
        save_complaint_record(rec, self.test_db_path)

        update_complaint_status(cid, "in_review", self.test_db_path)
        history = get_status_history(cid, self.test_db_path)
        self.assertEqual(len(history), 1)

        # Delete complaint
        from backend.privacy.database import _get_connection
        with _get_connection(self.test_db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM complaints WHERE complaint_id = ?", (cid,))
            conn.commit()

        history_after = get_status_history(cid, self.test_db_path)
        self.assertEqual(len(history_after), 0)

    def test_39_complete_structured_json_round_trip(self):
        """Test 39: All structured JSON fields survive database save -> read without corruption or data loss."""
        init_database(self.test_db_path)
        protected = protect_complaint("Threatening senior Rahul at 9876543210 in room 202 urgently!")
        record = create_complaint_record(protected)
        save_complaint_record(record, self.test_db_path)

        retrieved = get_complaint_record(record["complaint_id"], self.test_db_path)
        self.assertEqual(retrieved["safe_representation"], record["safe_representation"])
        self.assertEqual(retrieved["privacy_audit"], record["privacy_audit"])
        self.assertEqual(retrieved["risk_signals"], record["risk_signals"])
        self.assertEqual(retrieved["sarcasm_signals"], record["sarcasm_signals"])
        self.assertEqual(retrieved["feature_summary"], record["feature_summary"])
        self.assertEqual(retrieved["preliminary_risk"], record["preliminary_risk"])


if __name__ == "__main__":
    unittest.main()
