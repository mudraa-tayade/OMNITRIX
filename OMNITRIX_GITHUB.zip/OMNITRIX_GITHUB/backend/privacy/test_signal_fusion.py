"""
OMNITRIX Multi-Signal Analysis Engine Unit Tests (Step 53).
Tests signal fusion, explainability, preliminary risk preservation, ML fallback modes,
zero fake confidence, and privacy boundary enforcement.
"""

import unittest
from backend.privacy.signal_fusion import fuse_analysis
from backend.privacy.analysis_service import analyze_complaint


class TestSignalFusion(unittest.TestCase):

    def test_01_no_signals_yields_zero_detected(self):
        """Test 1: Empty or zero signals result in signals_detected = 0 and default explanation."""
        res = fuse_analysis(
            risk_signals={},
            sarcasm_signals={},
            feature_summary={},
            preliminary_risk={"risk_level": "low", "risk_score": 0}
        )
        self.assertEqual(res["signals_detected"], 0)
        self.assertFalse(any(res["signal_summary"].values()))
        self.assertIn("No elevated risk indicators detected", res["explanation"])

    def test_02_distress_only(self):
        """Test 2: Distress signal only sets distress=True and correct explanation."""
        risk_sig = {"distress_keyword_count": 2}
        prelim = {"risk_level": "low", "risk_score": 16}

        res = fuse_analysis(risk_signals=risk_sig, preliminary_risk=prelim)
        self.assertTrue(res["signal_summary"]["distress"])
        self.assertFalse(res["signal_summary"]["threat"])
        self.assertEqual(res["signals_detected"], 1)
        self.assertIn("Distress indicators detected", res["explanation"])

    def test_03_threat_only(self):
        """Test 3: Threat signal only sets threat=True and correct explanation."""
        risk_sig = {"has_threat_language": True, "threat_keyword_count": 1}
        prelim = {"risk_level": "medium", "risk_score": 35}

        res = fuse_analysis(risk_signals=risk_sig, preliminary_risk=prelim)
        self.assertTrue(res["signal_summary"]["threat"])
        self.assertFalse(res["signal_summary"]["urgency"])
        self.assertEqual(res["signals_detected"], 1)
        self.assertIn("Threat-related indicators detected", res["explanation"])

    def test_04_multiple_signals_represented(self):
        """Test 4: Multiple signals active concurrently are all represented."""
        risk_sig = {
            "distress_keyword_count": 1,
            "has_threat_language": True,
            "has_urgent_language": True,
            "has_help_seeking": True
        }
        prelim = {"risk_level": "high", "risk_score": 65}

        res = fuse_analysis(risk_signals=risk_sig, preliminary_risk=prelim)
        self.assertTrue(res["signal_summary"]["distress"])
        self.assertTrue(res["signal_summary"]["threat"])
        self.assertTrue(res["signal_summary"]["urgency"])
        self.assertTrue(res["signal_summary"]["help_seeking"])
        self.assertEqual(res["signals_detected"], 4)
        self.assertIn("Threat-related indicators detected", res["explanation"])
        self.assertIn("Distress indicators detected", res["explanation"])
        self.assertIn("Urgency indicators detected", res["explanation"])
        self.assertIn("Help-seeking indicators detected", res["explanation"])

    def test_05_sarcasm_and_coded_distress(self):
        """Test 5: Sarcasm and coded distress signals are correctly fused."""
        sarcasm_sig = {
            "has_sarcasm_markers": True,
            "has_coded_language_markers": True,
            "has_indirect_distress": True
        }
        prelim = {"risk_level": "medium", "risk_score": 30}

        res = fuse_analysis(sarcasm_signals=sarcasm_sig, preliminary_risk=prelim)
        self.assertTrue(res["signal_summary"]["sarcasm"])
        self.assertTrue(res["signal_summary"]["coded_distress"])
        self.assertTrue(res["signal_summary"]["indirect_distress"])
        self.assertEqual(res["signals_detected"], 3)
        self.assertIn("Possible sarcasm or irony detected", res["explanation"])
        self.assertIn("Possible coded or indirect distress detected", res["explanation"])

    def test_06_preliminary_risk_preserved_exactly(self):
        """Test 6: risk_level and risk_score are preserved directly from preliminary_risk."""
        prelim = {"risk_level": "critical", "risk_score": 88}
        res = fuse_analysis(preliminary_risk=prelim)
        self.assertEqual(res["risk_level"], "critical")
        self.assertEqual(res["risk_score"], 88)

    def test_07_no_second_risk_calculation(self):
        """Test 7: Preliminary risk score is NOT recalculated or altered by fuse_analysis."""
        prelim = {"risk_level": "high", "risk_score": 55, "reasons": ["Threat language"]}
        risk_sig = {"distress_keyword_count": 5}  # Would normally add score if recalculated
        res = fuse_analysis(risk_signals=risk_sig, preliminary_risk=prelim)
        # Score MUST equal prelim score exactly
        self.assertEqual(res["risk_score"], 55)
        self.assertEqual(res["risk_level"], "high")

    def test_08_ml_unavailable_yields_rule_based_mode(self):
        """Test 8: When ML is unavailable, analysis_mode is rule_based and ml_available is False."""
        ml_unavail = {"model_status": "not_loaded"}
        res = fuse_analysis(ml_analysis=ml_unavail)
        self.assertEqual(res["analysis_mode"], "rule_based")
        self.assertFalse(res["ml_available"])
        self.assertEqual(res["model_status"], "not_loaded")

    def test_09_ml_available_yields_ml_assisted_mode(self):
        """Test 9: When ML is available, analysis_mode is ml_assisted and ml_available is True."""
        ml_avail = {
            "model_status": "available",
            "emotion": {"label": "fear", "score": 0.895}
        }
        res = fuse_analysis(ml_analysis=ml_avail)
        self.assertEqual(res["analysis_mode"], "ml_assisted")
        self.assertTrue(res["ml_available"])
        self.assertEqual(res["model_status"], "available")
        self.assertEqual(res["confidence"], 0.895)

    def test_10_no_fake_confidence_in_rule_based_mode(self):
        """Test 10: Rule-based analysis mode explicitly sets confidence to None."""
        res = fuse_analysis(
            risk_signals={"distress_keyword_count": 3},
            preliminary_risk={"risk_level": "medium", "risk_score": 40}
        )
        self.assertIsNone(res["confidence"])

    def test_11_no_raw_text_accepted_or_stored(self):
        """Test 11: Output contains zero raw text, PII, names, or forbidden text keys."""
        forbidden_keys = {"raw_text", "protected_text", "student_name", "email", "phone"}
        res = fuse_analysis(
            risk_signals={"distress_keyword_count": 1},
            preliminary_risk={"risk_level": "low", "risk_score": 8}
        )
        for key in forbidden_keys:
            self.assertNotIn(key, res)

    def test_12_no_matched_keywords_returned(self):
        """Test 12: Output payload contains no matched keywords, phrases, or string tokens."""
        res = fuse_analysis(
            risk_signals={"has_threat_language": True},
            preliminary_risk={"risk_level": "medium", "risk_score": 30}
        )
        self.assertNotIn("matched_keywords", res)
        self.assertNotIn("matched_phrases", res)
        res_str = str(res)
        self.assertNotIn("keyword", res_str)

    def test_13_malformed_preliminary_risk_handled_safely(self):
        """Test 13: None or malformed preliminary_risk fails safely to low/0."""
        res_none = fuse_analysis(preliminary_risk=None)
        self.assertEqual(res_none["risk_level"], "low")
        self.assertEqual(res_none["risk_score"], 0)

        res_invalid = fuse_analysis(preliminary_risk={"risk_level": "super_high", "risk_score": "invalid"})
        self.assertEqual(res_invalid["risk_level"], "low")
        self.assertEqual(res_invalid["risk_score"], 0)

    def test_14_missing_signal_dictionaries_handled_safely(self):
        """Test 14: None or empty signal dictionaries do not cause exceptions."""
        res = fuse_analysis(
            risk_signals=None,
            sarcasm_signals=None,
            feature_summary=None,
            preliminary_risk=None,
            ml_analysis=None
        )
        self.assertEqual(res["risk_level"], "low")
        self.assertEqual(res["risk_score"], 0)
        self.assertEqual(res["signals_detected"], 0)
        self.assertEqual(res["analysis_mode"], "rule_based")

    def test_15_analysis_service_includes_fused_analysis(self):
        """Test 15: analyze_complaint payload includes fused_analysis and preserves existing keys."""
        complaint = "Seniors are threatening freshers in the hostel wing urgently."
        res = analyze_complaint(complaint)

        self.assertIn("fused_analysis", res)
        fused = res["fused_analysis"]
        self.assertEqual(fused["risk_level"], res["preliminary_risk"]["risk_level"])
        self.assertEqual(fused["risk_score"], res["preliminary_risk"]["risk_score"])
        self.assertTrue(fused["signal_summary"]["threat"])
        self.assertTrue(fused["signal_summary"]["urgency"])

        # Verify existing keys remain present
        expected_keys = {
            "protected_text", "pii_masked", "safe_representation",
            "privacy_audit", "risk_signals", "sarcasm_signals",
            "feature_summary", "preliminary_risk", "ml_analysis", "fused_analysis"
        }
        self.assertEqual(set(res.keys()), expected_keys)


if __name__ == "__main__":
    unittest.main()
