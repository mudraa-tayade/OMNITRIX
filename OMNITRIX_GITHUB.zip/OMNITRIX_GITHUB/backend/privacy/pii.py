"""
OMNITRIX Privacy Transformation Engine - PII Masker
Deterministic, regex-based masking of direct and indirect personal identifiers.
"""

import re

# 1. Email pattern
EMAIL_PATTERN = re.compile(
    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'
)

# 2. URL pattern (http/https/www) - avoids swallowing trailing sentence punctuation
URL_PATTERN = re.compile(
    r'\b(?:https?://|www\.)[^\s<>"\'()]+?(?=[.,?!;:]?(?:\s|$))',
    re.IGNORECASE
)

# 3. Social media handles (@username) - not part of an email address
SOCIAL_HANDLE_PATTERN = re.compile(
    r'(?<![\w.+-])@[A-Za-z0-9_]{3,30}\b'
)

# 4. Phone numbers (Indian 10-digit formats with optional +91, spaces, hyphens)
PHONE_PATTERN = re.compile(
    r'(?:\+91[\s.-]?)?(?:\b[6-9]\d{4}[\s.-]?\d{5}\b|\b[6-9]\d{9}\b|\b\d{3}[\s.-]\d{3}[\s.-]\d{4}\b)'
)

# 5. Student / Roll IDs (context-aware to avoid replacing random numbers, supports "is", ":", "-", "#")
STUDENT_ID_PATTERN = re.compile(
    r'(\b(?:roll\s*(?:no\.?|number|num\.?)|student\s*(?:id|number)|reg(?:istration)?\s*(?:no\.?|number)|enrollment\s*(?:no\.?|number)|uid)(?:\s+is)?\s*[:#-]?\s*)([A-Za-z0-9\/-]+)\b',
    re.IGNORECASE
)

# 6. Hostel Room identifiers (context-aware, supports "is", ":", "-", "#")
ROOM_PATTERN = re.compile(
    r'(\b(?:room\s*(?:no\.?|number|#)?|hostel\s*room\s*(?:no\.?|number)?)(?:\s+is)?\s*[:#-]?\s*)([A-Za-z0-9-]+)\b',
    re.IGNORECASE
)

# 7. Dates (Conservative - structured numeric dates and textual calendar dates)
NUMERIC_DATE_PATTERN = re.compile(
    r'\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b'
)

MONTHS = r'(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)'

TEXTUAL_DATE_PATTERN_1 = re.compile(
    rf'\b\d{{1,2}}(?:st|nd|rd|th)?\s+(?:of\s+)?{MONTHS}(?:\s*,?\s*\d{{2,4}})?\b',
    re.IGNORECASE
)

TEXTUAL_DATE_PATTERN_2 = re.compile(
    rf'\b{MONTHS}\s+\d{{1,2}}(?:st|nd|rd|th)?(?:\s*,?\s*\d{{2,4}})?\b',
    re.IGNORECASE
)

def _mask_urls(text: str) -> str:
    return URL_PATTERN.sub('[URL]', text)

def _mask_emails(text: str) -> str:
    return EMAIL_PATTERN.sub('[EMAIL]', text)

def _mask_social_handles(text: str) -> str:
    return SOCIAL_HANDLE_PATTERN.sub('[SOCIAL_HANDLE]', text)

def _mask_phone_numbers(text: str) -> str:
    return PHONE_PATTERN.sub('[PHONE]', text)

def _mask_student_ids(text: str) -> str:
    return STUDENT_ID_PATTERN.sub(r'\1[STUDENT_ID]', text)

def _mask_room_numbers(text: str) -> str:
    return ROOM_PATTERN.sub(r'\1[ROOM]', text)

def _mask_dates(text: str) -> str:
    text = NUMERIC_DATE_PATTERN.sub('[DATE]', text)
    text = TEXTUAL_DATE_PATTERN_1.sub('[DATE]', text)
    text = TEXTUAL_DATE_PATTERN_2.sub('[DATE]', text)
    return text

def mask_pii(text: str) -> str:
    """
    Mask explicit personal identifiable information (PII) with neutral tokens.
    
    Replaces:
      - URLs -> [URL]
      - Emails -> [EMAIL]
      - Social handles -> [SOCIAL_HANDLE]
      - Phone numbers -> [PHONE]
      - Student/Roll IDs -> [STUDENT_ID]
      - Room/Hostel numbers -> [ROOM]
      - Dates -> [DATE]
      
    Leaves general descriptive numbers (e.g. '3 seniors', '2 hours ago') untouched.
    """
    if not text or not isinstance(text, str):
        return ""

    masked = text

    # Order of masking is strictly maintained:
    masked = _mask_urls(masked)
    masked = _mask_emails(masked)
    masked = _mask_social_handles(masked)
    masked = _mask_phone_numbers(masked)
    masked = _mask_student_ids(masked)
    masked = _mask_room_numbers(masked)
    masked = _mask_dates(masked)

    return masked
