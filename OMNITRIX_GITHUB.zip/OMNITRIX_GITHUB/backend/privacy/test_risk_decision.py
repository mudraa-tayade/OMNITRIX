"""
Unit tests for OMNITRIX Privacy-Safe Preliminary Risk Decision Layer (backend/privacy/risk_decision.py).
Verifies deterministic score computation, bounded range (0-100), discrete risk levels,
generic privacy-safe reasons, non-leakage of raw text/PII, and zero ML or network dependencies.
"""

import unittest
from backend.privacy.risk_decision import classify_preliminary_risk


class TestRiskDecision(unittest.TestCase):
    def test_01_empty_signals_produce_low_risk(self):
        """Test 1: Empty input dictionaries produce 0 risk score and 'low' risk level."""
        res = classify_preliminary_risk({}, {}, {})
        self.assertEqual(res["risk_score"], 0)
        self.assertEqual(res["risk_level"], "low")
        self.assertEqual(res["reasons"], [])

    def test_02_score_is_always_an_integer(self):
        """Test 2: Returned risk_score is strictly an int instance."""
        res = classify_preliminary_risk({"threat_keyword_count": 1}, {}, {})
        self.assertIsInstance(res["risk_score"], int)

    def test_03_score_is_always_between_0_and_100(self):
        """Test 3: Risk score is bounded between 0 and 100 across varied inputs."""
        for c in [0, 1, 5, 50, 1000]:
            res = classify_preliminary_risk(
                {"threat_keyword_count": c, "distress_keyword_count": c},
                {"sarcasm_marker_count": c},
                {}
            )
            self.assertGreaterEqual(res["risk_score"], 0)
            self.assertLessEqual(res["risk_score"], 100)

    def test_04_risk_level_is_one_of_four_allowed_values(self):
        """Test 4: Risk level string is always in {'low', 'medium', 'high', 'critical'}."""
        allowed_levels = {"low", "medium", "high", "critical"}
        for score_in in [0, 2, 5, 10, 50, 100]:
            res = classify_preliminary_risk({"threat_keyword_count": score_in}, {}, {})
            self.assertIn(res["risk_level"], allowed_levels)

    def test_05_threat_signals_increase_score(self):
        """Test 5: Threat language signals increase the risk score."""
        base = classify_preliminary_risk({}, {}, {})
        with_threat = classify_preliminary_risk({"has_threat_language": True, "threat_keyword_count": 1}, {}, {})
        self.assertGreater(with_threat["risk_score"], base["risk_score"])
        self.assertIn("Threat-related language detected", with_threat["reasons"])

    def test_06_distress_signals_increase_score(self):
        """Test 6: Distress signals increase the risk score."""
        base = classify_preliminary_risk({}, {}, {})
        with_distress = classify_preliminary_risk({"distress_keyword_count": 2}, {}, {})
        self.assertGreater(with_distress["risk_score"], base["risk_score"])
        self.assertIn("Distress-related language detected", with_distress["reasons"])

    def test_07_urgency_signals_increase_score(self):
        """Test 7: Urgency signals increase the risk score."""
        base = classify_preliminary_risk({}, {}, {})
        with_urgency = classify_preliminary_risk({"has_urgent_language": True, "urgency_keyword_count": 1}, {}, {})
        self.assertGreater(with_urgency["risk_score"], base["risk_score"])
        self.assertIn("Urgent language detected", with_urgency["reasons"])

    def test_08_help_seeking_signals_increase_score(self):
        """Test 8: Help-seeking signals increase the risk score."""
        base = classify_preliminary_risk({}, {}, {})
        with_help = classify_preliminary_risk({"has_help_seeking": True, "help_seeking_count": 1}, {}, {})
        self.assertGreater(with_help["risk_score"], base["risk_score"])
        self.assertIn("Help-seeking language detected", with_help["reasons"])

    def test_09_negative_emotion_signals_increase_score(self):
        """Test 9: Negative emotion signals increase the risk score."""
        base = classify_preliminary_risk({}, {}, {})
        with_emotion = classify_preliminary_risk({"negative_emotion_count": 2}, {}, {})
        self.assertGreater(with_emotion["risk_score"], base["risk_score"])
        self.assertIn("Negative-emotion language detected", with_emotion["reasons"])

    def test_10_indirect_distress_signals_increase_score(self):
        """Test 10: Indirect distress / withdrawal signals increase the risk score."""
        base = classify_preliminary_risk({}, {"has_indirect_distress": True, "indirect_distress_marker_count": 1}, {})
        self.assertGreater(base["risk_score"], 0)
        self.assertIn("Indirect distress or withdrawal language detected", base["reasons"])

    def test_11_coded_language_signals_increase_score(self):
        """Test 11: Coded language markers increase the risk score."""
        base = classify_preliminary_risk({}, {"has_coded_language_markers": True, "coded_language_marker_count": 1}, {})
        self.assertGreater(base["risk_score"], 0)
        self.assertIn("Coded or indirect language markers detected", base["reasons"])

    def test_12_sarcasm_signals_increase_score(self):
        """Test 12: Sarcasm markers increase the risk score."""
        base = classify_preliminary_risk({}, {"has_sarcasm_markers": True, "sarcasm_marker_count": 1}, {})
        self.assertGreater(base["risk_score"], 0)
        self.assertIn("Sarcasm/irony markers detected", base["reasons"])

    def test_13_repeated_counts_cannot_push_score_above_100(self):
        """Test 13: Extremely high pattern counts are bounded at 100 max score."""
        res = classify_preliminary_risk(
            {
                "threat_keyword_count": 9999,
                "distress_keyword_count": 9999,
                "urgency_keyword_count": 9999,
                "help_seeking_count": 9999,
                "negative_emotion_count": 9999
            },
            {
                "sarcasm_marker_count": 9999,
                "coded_language_marker_count": 9999,
                "indirect_distress_marker_count": 9999
            },
            {}
        )
        self.assertEqual(res["risk_score"], 100)
        self.assertEqual(res["risk_level"], "critical")

    def test_14_reasons_never_contain_raw_complaint_text(self):
        """Test 14: Reasons contain only generic descriptions, no raw complaint snippets."""
        raw_text_snippet = "They beat me up in room 302 after lights out"
        res = classify_preliminary_risk(
            {"has_threat_language": True, "threat_keyword_count": 2},
            {},
            {}
        )
        for reason in res["reasons"]:
            self.assertNotIn(raw_text_snippet, reason)

    def test_15_reasons_never_contain_pii(self):
        """Test 15: Reasons do not contain phone numbers, emails, or student names."""
        pii_samples = ["9876543210", "student@college.edu.in", "Rohan Sharma"]
        res = classify_preliminary_risk(
            {"has_threat_language": True, "threat_keyword_count": 1, "distress_keyword_count": 1},
            {},
            {}
        )
        for reason in res["reasons"]:
            for sample in pii_samples:
                self.assertNotIn(sample, reason)

    def test_16_reasons_are_generic_category_descriptions(self):
        """Test 16: All reason items are predefined generic category strings."""
        allowed_reasons = {
            "Threat-related language detected",
            "Distress-related language detected",
            "Urgent language detected",
            "Help-seeking language detected",
            "Negative-emotion language detected",
            "Indirect distress or withdrawal language detected",
            "Coded or indirect language markers detected",
            "Sarcasm/irony markers detected"
        }
        res = classify_preliminary_risk(
            {"has_threat_language": True, "threat_keyword_count": 1, "distress_keyword_count": 1},
            {"has_sarcasm_markers": True, "sarcasm_marker_count": 1},
            {}
        )
        for reason in res["reasons"]:
            self.assertIn(reason, allowed_reasons)

    def test_17_critical_risk_requires_sufficiently_strong_combined_signals(self):
        """Test 17: Reaching 'critical' risk level requires combined strong signals reaching score >= 75."""
        # Single distress count alone should NOT produce critical
        res_distress = classify_preliminary_risk({"distress_keyword_count": 1}, {}, {})
        self.assertNotEqual(res_distress["risk_level"], "critical")

        # Combined threat + distress + urgency + help-seeking produces critical
        res_critical = classify_preliminary_risk(
            {
                "has_threat_language": True,
                "threat_keyword_count": 2,
                "distress_keyword_count": 3,
                "has_urgent_language": True,
                "urgency_keyword_count": 1,
                "has_help_seeking": True,
                "help_seeking_count": 1
            },
            {},
            {}
        )
        self.assertGreaterEqual(res_critical["risk_score"], 75)
        self.assertEqual(res_critical["risk_level"], "critical")

    def test_18_sarcasm_alone_does_not_automatically_produce_critical_risk(self):
        """Test 18: High sarcasm count alone is capped and yields low risk level (score <= 15)."""
        res = classify_preliminary_risk({}, {"has_sarcasm_markers": True, "sarcasm_marker_count": 100}, {})
        self.assertLessEqual(res["risk_score"], 15)
        self.assertEqual(res["risk_level"], "low")

    def test_19_no_probability_or_confidence_field_returned(self):
        """Test 19: Returned dictionary contains no 'probability' or 'confidence' key."""
        res = classify_preliminary_risk({"threat_keyword_count": 2}, {}, {})
        self.assertNotIn("probability", res)
        self.assertNotIn("confidence", res)

    def test_20_function_does_not_require_ml_model(self):
        """Test 20: Function executes pure deterministic Python logic without importing ML models."""
        res = classify_preliminary_risk({"distress_keyword_count": 1}, {}, {})
        self.assertIn("risk_score", res)

    def test_21_function_does_not_require_network_access(self):
        """Test 21: Function executes completely offline without external network calls."""
        res = classify_preliminary_risk({"urgency_keyword_count": 1}, {}, {})
        self.assertIsInstance(res, dict)

    def test_22_function_does_not_write_to_sqlite(self):
        """Test 22: Function is a pure computation function with no database side effects."""
        res = classify_preliminary_risk({"threat_keyword_count": 1}, {}, {})
        self.assertIn("risk_level", res)


if __name__ == "__main__":
    unittest.main()
