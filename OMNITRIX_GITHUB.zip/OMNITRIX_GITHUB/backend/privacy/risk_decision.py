"""
OMNITRIX Privacy-Safe Preliminary Risk Decision Layer
Converts observable privacy-safe linguistic indicators into an explainable preliminary risk classification.

ARCHITECTURAL & SAFETY NOTICE:
1. This module provides a DETERMINISTIC PRELIMINARY RISK HEURISTIC for anti-ragging triage.
2. It is NOT a medical or psychological diagnosis.
3. It is NOT a final determination that a student is actually being bullied or ragged.
4. It is a hackathon heuristic score requiring future validation with labeled complaint datasets.
5. Operates exclusively on aggregated numeric signals and boolean flags. NEVER inspects raw complaint text.
"""

from typing import Dict, Any, List, Optional


def classify_preliminary_risk(
    risk_signals: Optional[Dict[str, Any]] = None,
    sarcasm_signals: Optional[Dict[str, Any]] = None,
    feature_summary: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Computes an explainable, deterministic preliminary risk score (0-100) and risk level
    from privacy-safe signal counts and flags.

    Input Signals Used:
      - risk_signals (distress, threat, urgency, help-seeking, negative emotion)
      - sarcasm_signals (sarcasm, coded language, indirect distress)
      - feature_summary (fallback aggregator if individual dictionaries are omitted)

    Rules:
      - Returns strictly integer risk_score (bounded 0 to 100).
      - Returns risk_level in {"low", "medium", "high", "critical"}.
      - Thresholds: 0-24 -> low, 25-49 -> medium, 50-74 -> high, 75-100 -> critical.
      - Returns privacy-safe generic reasons list.
      - NEVER returns probability, confidence metrics, or raw text fragments.
    """
    rs = risk_signals if isinstance(risk_signals, dict) else {}
    ss = sarcasm_signals if isinstance(sarcasm_signals, dict) else {}
    fs = feature_summary if isinstance(feature_summary, dict) else {}

    # Helper to resolve count or flag from specific dict or fallback feature_summary
    def get_val(key: str, default: Any = 0) -> Any:
        if key in rs:
            return rs[key]
        if key in ss:
            return ss[key]
        if key in fs:
            return fs[key]
        return default

    threat_count = int(get_val("threat_keyword_count", 0))
    has_threat = bool(get_val("has_threat_language", threat_count > 0))

    distress_count = int(get_val("distress_keyword_count", 0))

    urgency_count = int(get_val("urgency_keyword_count", 0))
    has_urgent = bool(get_val("has_urgent_language", urgency_count > 0))

    help_count = int(get_val("help_seeking_count", 0))
    has_help = bool(get_val("has_help_seeking", help_count > 0))

    neg_emotion_count = int(get_val("negative_emotion_count", 0))

    indirect_distress_count = int(get_val("indirect_distress_marker_count", 0))
    has_indirect_distress = bool(get_val("has_indirect_distress", indirect_distress_count > 0))

    coded_count = int(get_val("coded_language_marker_count", 0))
    has_coded = bool(get_val("has_coded_language_markers", coded_count > 0))

    sarcasm_count = int(get_val("sarcasm_marker_count", 0))
    has_sarcasm = bool(get_val("has_sarcasm_markers", sarcasm_count > 0))

    score = 0
    reasons: List[str] = []

    # 1. Threat Language (Max contribution: 45)
    if has_threat or threat_count > 0:
        threat_score = 25 + min(threat_count * 10, 20)
        score += threat_score
        reasons.append("Threat-related language detected")

    # 2. Distress Language (Max contribution: 25)
    if distress_count > 0:
        distress_score = min(distress_count * 8, 25)
        score += distress_score
        reasons.append("Distress-related language detected")

    # 3. Urgency Language (Max contribution: 20)
    if has_urgent or urgency_count > 0:
        urgency_score = 10 + min(urgency_count * 5, 10)
        score += urgency_score
        reasons.append("Urgent language detected")

    # 4. Help-Seeking Language (Max contribution: 20)
    if has_help or help_count > 0:
        help_score = 10 + min(help_count * 5, 10)
        score += help_score
        reasons.append("Help-seeking language detected")

    # 5. Negative Emotion (Max contribution: 15)
    if neg_emotion_count > 0:
        neg_score = min(neg_emotion_count * 4, 15)
        score += neg_score
        reasons.append("Negative-emotion language detected")

    # 6. Indirect Distress / Withdrawal (Max contribution: 15)
    if has_indirect_distress or indirect_distress_count > 0:
        indirect_score = min(max(indirect_distress_count, 1) * 5, 15)
        score += indirect_score
        reasons.append("Indirect distress or withdrawal language detected")

    # 7. Coded / Indirect Language Markers (Max contribution: 15)
    if has_coded or coded_count > 0:
        coded_score = min(max(coded_count, 1) * 5, 15)
        score += coded_score
        reasons.append("Coded or indirect language markers detected")

    # 8. Sarcasm / Irony Markers (Max contribution: 15)
    if has_sarcasm or sarcasm_count > 0:
        sarcasm_score = min(max(sarcasm_count, 1) * 5, 15)
        score += sarcasm_score
        reasons.append("Sarcasm/irony markers detected")

    # Ensure score is an integer strictly bounded between 0 and 100
    risk_score = min(max(int(score), 0), 100)

    # Classify into discrete risk levels based on bounded score
    if risk_score >= 75:
        risk_level = "critical"
    elif risk_score >= 50:
        risk_level = "high"
    elif risk_score >= 25:
        risk_level = "medium"
    else:
        risk_level = "low"

    return {
        "risk_level": risk_level,
        "risk_score": risk_score,
        "reasons": reasons
    }
