"""
Unit tests for OMNITRIX Privacy Transformation Engine (Sanitizer).
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.sanitizer import sanitize_text

class TestPrivacySanitizer(unittest.TestCase):

    def test_01_normal_text(self):
        """Verify normal well-formatted complaints remain unaltered."""
        input_text = "Seniors are asking first year students to clean their rooms after midnight."
        expected = "Seniors are asking first year students to clean their rooms after midnight."
        self.assertEqual(sanitize_text(input_text), expected)

    def test_02_repeated_letters(self):
        """Verify letter-stretching is normalized to root form while keeping standard double letters."""
        input_text = "Pleaaaase help meee, they are sooooo mean."
        sanitized = sanitize_text(input_text)
        self.assertEqual(sanitized, "Please help me, they are so mean.")

    def test_03_excessive_punctuation(self):
        """Verify chaotic and repeated punctuation is condensed."""
        input_text = "WHY ARE THEY DOING THIS????!!!! This is not okay......"
        sanitized = sanitize_text(input_text)
        # Should condense ????!!!! to ?! and ...... to ...
        self.assertIn("?!", sanitized)
        self.assertIn("...", sanitized)
        self.assertNotIn("????", sanitized)
        self.assertNotIn("!!!!", sanitized)

    def test_04_excessive_emojis(self):
        """Verify repeated identical emojis are collapsed to single occurrences."""
        input_text = "I am feeling terrified in the hostel 😭😭😭😭😭 please stop them 😡😡😡"
        sanitized = sanitize_text(input_text)
        self.assertEqual(sanitized, "I am feeling terrified in the hostel 😭 please stop them 😡")

    def test_05_all_caps_shouting(self):
        """Verify aggressive all-caps writing is normalized to sentence case."""
        input_text = "SENIORS ARE BLOCKING THE HOSTEL CORRIDOR AND THREATENING JUNIORS."
        sanitized = sanitize_text(input_text)
        # Check that it is no longer all-uppercase
        self.assertFalse(sanitized.isupper())
        self.assertTrue(sanitized.startswith("Seniors are blocking"))

    def test_06_excessive_spaces_and_newlines(self):
        """Verify irregular tab and whitespace patterns are cleanly flattened."""
        input_text = "They    locked    the   door.\n\n\n\nNobody   can   leave."
        sanitized = sanitize_text(input_text)
        self.assertEqual(sanitized, "They locked the door.\n\nNobody can leave.")

    def test_07_hinglish_code_mixed(self):
        """Verify Hinglish code-mixed distress expressions have stylistic quirks removed."""
        input_text = "Bhaaaaiii hostel me bohot jaaada ragging ho rahi haiii!!!!!"
        sanitized = sanitize_text(input_text)
        self.assertEqual(sanitized, "Bhai hostel me bohot jada ragging ho rahi hai!")

    def test_08_genz_slang_with_style_quirks(self):
        """Verify modern slang complaining maintains wording without idiosyncratic stretching."""
        input_text = "This senior is tripping frrrr frrrr periodttt, lowkey scary af......"
        sanitized = sanitize_text(input_text)
        self.assertIn("fr", sanitized)
        self.assertIn("periodt", sanitized)
        self.assertNotIn("frrrr", sanitized)
        self.assertNotIn("periodttt", sanitized)

    def test_09_preserves_legitimate_acronyms_and_double_letters(self):
        """Verify legitimate double letters (good, feel) and institutional acronyms (UGC, FIR) are preserved."""
        input_text = "We feel good reporting this to the UGC and filing an FIR."
        sanitized = sanitize_text(input_text)
        self.assertEqual(sanitized, "We feel good reporting this to the UGC and filing an FIR.")

    def test_10_combined_adversarial_stylistic_profile(self):
        """Verify combined stress test with all stylistic cues simultaneously."""
        input_text = "   HELLLLP MEEEEE   PLEASEEE!!!!????    😭😭😭   hostel 3 wardennnn is not listeninggg...   "
        sanitized = sanitize_text(input_text)
        # Should be trimmed, no triple letters, normalized punctuation and emojis, de-shouted
        self.assertFalse(sanitized.isupper())
        self.assertNotIn("   ", sanitized)
        self.assertNotIn("😭😭😭", sanitized)
        self.assertNotIn("!!!!????", sanitized)
        self.assertIn("😭", sanitized)
        self.assertIn("?!", sanitized)

if __name__ == "__main__":
    unittest.main()
