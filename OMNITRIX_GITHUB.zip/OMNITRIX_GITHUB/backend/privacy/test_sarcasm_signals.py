"""
Unit tests for OMNITRIX Sarcasm & Coded Language Signal Extractor.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.sarcasm_signals import extract_sarcasm_signals
from backend.privacy.pipeline import protect_text

class TestSarcasmSignals(unittest.TestCase):

    def test_01_neutral_complaint(self):
        """Verify standard non-sarcastic complaint has zero sarcasm/coded signals."""
        text = "The electrical maintenance staff came to fix the fan today."
        signals = extract_sarcasm_signals(text)

        self.assertEqual(signals["sarcasm_marker_count"], 0)
        self.assertEqual(signals["coded_language_marker_count"], 0)
        self.assertEqual(signals["indirect_distress_marker_count"], 0)
        self.assertFalse(signals["has_sarcasm_markers"])
        self.assertFalse(signals["has_coded_language_markers"])
        self.assertFalse(signals["has_indirect_distress"])

    def test_02_obvious_sarcastic_marker(self):
        """Verify obvious sarcastic phrase is detected."""
        text = "Seniors making us stand all night is just perfect, thanks a lot."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["sarcasm_marker_count"] >= 2)
        self.assertTrue(signals["has_sarcasm_markers"])

    def test_03_multiple_sarcastic_markers(self):
        """Verify multiple sarcastic / ironic markers are tallied."""
        text = "Yeah right, seniors are so helpful, what a joke."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["sarcasm_marker_count"] >= 3)
        self.assertTrue(signals["has_sarcasm_markers"])

    def test_04_english_coded_indirect_distress(self):
        """Verify coded/evasive language (e.g. 'everything is fine', 'can't say')."""
        text = "Don't worry about me, everything is fine, not allowed to say anything."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["coded_language_marker_count"] >= 2)
        self.assertTrue(signals["has_coded_language_markers"])

    def test_05_hinglish_coded_wording(self):
        """Verify Hinglish evasive / coded language markers."""
        text = "Haan sab theek hai, bas rehne do, kuch nahi bolna mujhe."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["has_coded_language_markers"])
        self.assertTrue(signals["coded_language_marker_count"] >= 2)

    def test_06_indirect_distress_and_withdrawal(self):
        """Verify expressions of helplessness/withdrawal."""
        text = "I don't know what to do, no one will understand what is happening here."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["indirect_distress_marker_count"] >= 2)
        self.assertTrue(signals["has_indirect_distress"])

    def test_07_mixed_english_hinglish_coded(self):
        """Verify mixed code-switched coded expressions."""
        text = "Seniors are fine, main nahi bata sakta what happened in the hostel."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["has_indirect_distress"] or signals["has_coded_language_markers"])

    def test_08_empty_input(self):
        """Verify empty and whitespace inputs return clean zero counts."""
        signals = extract_sarcasm_signals("")
        self.assertEqual(signals["sarcasm_marker_count"], 0)
        self.assertFalse(signals["has_sarcasm_markers"])

    def test_09_person_token_does_not_affect_extraction(self):
        """Verify sanitized [PERSON] placeholder does not interfere with sarcasm extraction."""
        text = "Seniors told [PERSON] that everything is fine, yeah right."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["has_sarcasm_markers"])
        self.assertTrue(signals["has_coded_language_markers"])

    def test_10_pii_tokens_do_not_create_signals(self):
        """Verify [PHONE], [EMAIL], [ROOM], [DATE] tokens do not produce false signals."""
        text = "My contact is [PHONE], room is [ROOM], date is [DATE]."
        signals = extract_sarcasm_signals(text)

        self.assertEqual(signals["sarcasm_marker_count"], 0)
        self.assertEqual(signals["coded_language_marker_count"], 0)
        self.assertEqual(signals["indirect_distress_marker_count"], 0)

    def test_11_matched_phrases_not_returned(self):
        """Verify dictionary contains only ints and bools, zero phrase strings."""
        text = "Yeah right, everything is fine, what a joke."
        signals = extract_sarcasm_signals(text)

        for k, v in signals.items():
            self.assertTrue(isinstance(v, (int, bool)), f"Unexpected type for key {k}: {type(v)}")

        sig_str = str(signals)
        self.assertNotIn("yeah right", sig_str)
        self.assertNotIn("everything is fine", sig_str)

    def test_12_protected_text_unmodified(self):
        """Verify input protected_text string reference remains strictly unchanged."""
        original_protected = "Everything is fine in room [ROOM], thanks a lot."
        text_copy = str(original_protected)
        _ = extract_sarcasm_signals(text_copy)

        self.assertEqual(text_copy, original_protected)

    def test_13_multiple_signal_categories_together(self):
        """Verify sarcasm + coded language + indirect distress triggered simultaneously."""
        text = "Yeah right, everything is fine! I don't know what to do anymore."
        signals = extract_sarcasm_signals(text)

        self.assertTrue(signals["has_sarcasm_markers"])
        self.assertTrue(signals["has_coded_language_markers"])
        self.assertTrue(signals["has_indirect_distress"])

if __name__ == "__main__":
    unittest.main()
