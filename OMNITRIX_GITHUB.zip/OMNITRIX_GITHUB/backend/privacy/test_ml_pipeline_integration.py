"""
OMNITRIX End-to-End Privacy + ML Pipeline Integration Unit Tests (Step 56).
Tests ML-enabled and ML-disabled pipeline execution, privacy boundary enforcement,
prediction structure validity, non-probabilistic decision scoring, rule-based fallback preservation,
risk score integrity, and default configuration safety.
"""

import os
import unittest

from backend.config import (
    get_ml_enabled,
    ML_ENABLED_ENV,
    ML_MODEL_PATH_ENV
)
from backend.privacy.analysis_service import analyze_complaint
from backend.privacy.ml_analyzer import analyze_ml
from backend.privacy.signal_fusion import fuse_analysis


class TestMLPipelineIntegration(unittest.TestCase):

    def setUp(self):
        # Guarantee ML is disabled by default for tests
        os.environ[ML_ENABLED_ENV] = "false"

    def tearDown(self):
        os.environ.pop(ML_ENABLED_ENV, None)
        os.environ.pop(ML_MODEL_PATH_ENV, None)

    def test_01_ml_enabled_pipeline_works_with_trained_models(self):
        """Test 1: Enabling ML executes trained TF-IDF models and returns available status."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_complaint("Seniors are threatening freshers in the hostel wing B urgently.")

        self.assertEqual(res["ml_analysis"]["model_status"], "available")
        self.assertNotEqual(res["ml_analysis"]["emotion"]["label"], "unknown")
        self.assertNotEqual(res["ml_analysis"]["sarcasm"]["label"], "unknown")
        self.assertEqual(res["fused_analysis"]["analysis_mode"], "ml_assisted")
        self.assertTrue(res["fused_analysis"]["ml_available"])

    def test_02_ml_disabled_pipeline_still_works(self):
        """Test 2: Disabling ML returns model_status not_loaded and rule_based analysis mode."""
        os.environ[ML_ENABLED_ENV] = "false"
        res = analyze_complaint("Seniors are threatening freshers in the hostel wing B urgently.")

        self.assertEqual(res["ml_analysis"]["model_status"], "not_loaded")
        self.assertEqual(res["ml_analysis"]["emotion"]["label"], "unknown")
        self.assertEqual(res["fused_analysis"]["analysis_mode"], "rule_based")
        self.assertFalse(res["fused_analysis"]["ml_available"])

    def test_03_protected_text_reaches_ml(self):
        """Test 3: ML analyzer receives privacy-protected text with masked tokens."""
        os.environ[ML_ENABLED_ENV] = "true"
        raw_input = "John Doe at 9876543210 in room 404 is scared and terrified."
        res = analyze_complaint(raw_input)

        protected_text = res.get("protected_text", "")
        self.assertIn("[PHONE]", protected_text)
        self.assertIn("[ROOM]", protected_text)

    def test_04_raw_text_does_not_reach_ml(self):
        """Test 4: Raw text and unmasked PII are absent from ML predictions and fused outputs."""
        os.environ[ML_ENABLED_ENV] = "true"
        marker = "PRIVATE_TEST_MARKER_OMNITRIX"
        raw_input = f"{marker} Rohit Sharma test@univ.edu is threatening freshers."
        res = analyze_complaint(raw_input)

        ml_str = str(res["ml_analysis"])
        fused_str = str(res["fused_analysis"])

        self.assertNotIn(marker, ml_str)
        self.assertNotIn(marker, fused_str)
        self.assertNotIn("Rohit Sharma", ml_str)
        self.assertNotIn("test@univ.edu", ml_str)

    def test_05_emotion_prediction_structure_valid(self):
        """Test 5: Emotion ML output contains valid label and numeric score."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("I feel very scared and terrified in the hostel.")
        emo = res["emotion"]

        self.assertIn("label", emo)
        self.assertIn("score", emo)
        self.assertIsInstance(emo["label"], str)
        self.assertIsInstance(emo["score"], float)

    def test_06_sarcasm_prediction_structure_valid(self):
        """Test 6: Sarcasm ML output contains valid label and numeric score."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("Yeah right best day ever so helpful.")
        sarc = res["sarcasm"]

        self.assertIn("label", sarc)
        self.assertIn("score", sarc)
        self.assertIn(sarc["label"], ["sarcastic", "non_sarcastic"])

    def test_07_scores_are_not_labeled_as_probabilities(self):
        """Test 7: Output fields use 'score' key and no field is named 'probability'."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_complaint("Test complaint text")
        res_str = str(res)

        self.assertNotIn("probability", res_str)
        self.assertNotIn("probabilities", res_str)
        self.assertIn("score", res["ml_analysis"]["emotion"])
        self.assertIn("score", res["ml_analysis"]["sarcasm"])

    def test_08_coded_distress_remains_rule_based(self):
        """Test 8: coded_distress in ML analysis returns unknown 0.0 fallback."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("Everything is fine don't worry about me.")
        self.assertEqual(res["coded_distress"]["label"], "unknown")
        self.assertEqual(res["coded_distress"]["score"], 0.0)

    def test_09_language_remains_heuristic(self):
        """Test 9: Language field comes from representation language hint with score 0.0."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("bhai bohot darr lag raha hai room me")
        self.assertEqual(res["language"]["label"], "hinglish")
        self.assertEqual(res["language"]["score"], 0.0)

    def test_10_preliminary_risk_remains_unchanged(self):
        """Test 10: Preliminary risk decision is identical whether ML is enabled or disabled."""
        raw_text = "Seniors in hostel wing B are threatening freshers urgently."

        os.environ[ML_ENABLED_ENV] = "false"
        res_disabled = analyze_complaint(raw_text)

        os.environ[ML_ENABLED_ENV] = "true"
        res_enabled = analyze_complaint(raw_text)

        self.assertEqual(res_disabled["preliminary_risk"], res_enabled["preliminary_risk"])

    def test_11_signal_fusion_is_single_fusion_layer(self):
        """Test 11: fused_analysis contains single unified fusion payload."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_complaint("Seniors are threatening freshers in room 101 urgently.")
        fused = res["fused_analysis"]

        self.assertIn("risk_level", fused)
        self.assertIn("risk_score", fused)
        self.assertIn("signal_summary", fused)
        self.assertIn("explanation", fused)
        self.assertEqual(fused["risk_score"], res["preliminary_risk"]["risk_score"])

    def test_12_missing_model_degrades_safely(self):
        """Test 12: Invalid model path degrades gracefully to not_loaded and rule_based mode."""
        os.environ[ML_ENABLED_ENV] = "true"
        os.environ[ML_MODEL_PATH_ENV] = "/invalid/non_existent/model/path"
        res = analyze_complaint("Seniors are harassing freshers.")

        self.assertEqual(res["ml_analysis"]["model_status"], "not_loaded")
        self.assertEqual(res["fused_analysis"]["analysis_mode"], "rule_based")
        self.assertFalse(res["fused_analysis"]["ml_available"])

    def test_13_no_raw_text_in_ml_output(self):
        """Test 13: ml_analysis payload contains zero text fields."""
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_ml("Seniors are threatening freshers.")
        for key in ["text", "raw_text", "protected_text"]:
            self.assertNotIn(key, res)

    def test_14_no_pii_in_ml_output(self):
        """Test 14: Output keys contain zero forbidden identity fields."""
        forbidden = {"student_name", "email", "phone", "room_number", "ip_address"}
        os.environ[ML_ENABLED_ENV] = "true"
        res = analyze_complaint("Rohit at 9876543210 email r@test.com room 404 is scared")
        for key in forbidden:
            self.assertNotIn(key, res)

    def test_15_production_default_remains_ml_disabled(self):
        """Test 15: get_ml_enabled() returns False when environment variable is unset."""
        os.environ.pop(ML_ENABLED_ENV, None)
        self.assertFalse(get_ml_enabled())


if __name__ == "__main__":
    unittest.main()
