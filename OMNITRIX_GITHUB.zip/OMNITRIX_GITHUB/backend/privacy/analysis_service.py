"""
OMNITRIX Unified Complaint Analysis Service
Single clean entry point for analyzing student complaints across privacy protection,
structural representation, signal extraction, ML feature aggregation, and preliminary risk decision.

Flow:
  Raw complaint -> protect_complaint() -> Privacy-safe text + representation
               -> Risk signals -> Sarcasm/coded-language signals -> Feature summary
               -> Preliminary risk (classify_preliminary_risk) -> Analysis result

Guarantees:
  - Raw complaint text is NEVER returned by analyze_complaint().
  - Raw complaint text is NEVER stored, retained, or logged.
  - Zero matched keywords, raw phrases, or personal identity fields exposed.
  - Relies on existing classify_preliminary_risk() engine for deterministic risk assessment.
"""

from typing import Dict, Any, Optional
from .engine import protect_complaint
from .risk_decision import classify_preliminary_risk
from .ml_analyzer import analyze_ml
from .signal_fusion import fuse_analysis


FORBIDDEN_FIELDS = {
    "raw_text", "original_text", "student_name", "phone", "email",
    "room_number", "roll_number", "ip_address", "device_id", "username",
    "location", "writing_style_fingerprint", "matched_keywords", "matched_phrases"
}


def analyze_complaint(text: Optional[str]) -> Dict[str, Any]:
    """
    Unified complaint analysis service function.
    
    Transforms raw complaint text through the multi-stage privacy and signal extraction pipeline:
      1. Executes protect_complaint(text) for PII/name masking, style normalization, safe representation,
         risk signal extraction, sarcasm signal extraction, and feature summary aggregation.
      2. Executes lightweight ML analysis on protected_text via analyze_ml(protected_text).
      3. Derived preliminary risk strictly from classify_preliminary_risk(risk_signals, sarcasm_signals).
      4. Executes multi-signal fusion via fuse_analysis().
      5. Constructs a clean structured analysis payload containing ONLY privacy-safe fields.
      6. Verifies zero raw text, PII, matched phrases, or forbidden identity attributes are retained.
    """
    protected_result = protect_complaint(text)
    protected_text = protected_result.get("protected_text", "")

    # Execute ML analysis strictly on protected_text (never raw text)
    ml_result = analyze_ml(protected_text)

    # Extract component signals
    risk_signals = protected_result.get("risk_signals", {})
    sarcasm_signals = protected_result.get("sarcasm_signals", {})
    feature_summary = protected_result.get("feature_summary", {})

    # Evaluate preliminary risk using existing classify_preliminary_risk decision engine
    preliminary_risk = protected_result.get("preliminary_risk")
    if not preliminary_risk:
        preliminary_risk = classify_preliminary_risk(risk_signals, sarcasm_signals)

    # Execute multi-signal fusion layer
    fused_analysis = fuse_analysis(
        risk_signals=risk_signals,
        sarcasm_signals=sarcasm_signals,
        feature_summary=feature_summary,
        preliminary_risk=preliminary_risk,
        ml_analysis=ml_result
    )

    analysis_result = {
        "protected_text": protected_text,
        "pii_masked": protected_result.get("pii_masked", False),
        "safe_representation": protected_result.get("safe_representation", {}),
        "privacy_audit": protected_result.get("privacy_audit", {}),
        "risk_signals": risk_signals,
        "sarcasm_signals": sarcasm_signals,
        "feature_summary": feature_summary,
        "preliminary_risk": preliminary_risk,
        "ml_analysis": ml_result,
        "fused_analysis": fused_analysis
    }

    # Defensive check: ensure no forbidden raw/PII/identity key is present in output payload
    for forbidden_field in FORBIDDEN_FIELDS:
        if forbidden_field in analysis_result:
            del analysis_result[forbidden_field]

    return analysis_result
