"""
Unit tests for OMNITRIX Unified Privacy Pipeline (protect_text).
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.pipeline import protect_text

class TestPrivacyPipeline(unittest.TestCase):

    def test_01_normal_complaint(self):
        """Verify normal complaint without PII or extreme styling is preserved."""
        input_text = "Seniors are forcing us to do physical chores in the hostel lobby."
        result = protect_text(input_text)
        
        self.assertIn("protected_text", result)
        self.assertIn("pii_masked", result)
        self.assertIn("safe_representation", result)
        self.assertIn("privacy_audit", result)
        self.assertIn("risk_signals", result)
        self.assertIn("sarcasm_signals", result)
        self.assertIn("feature_summary", result)
        self.assertIn("preliminary_risk", result)
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["protected_text"], "Seniors are forcing us to do physical chores in the hostel lobby.")
        self.assertEqual(result["safe_representation"]["language_hint"], "english")
        self.assertTrue(result["risk_signals"]["has_threat_language"])  # "forcing"

    def test_02_phone_number_and_repeated_punctuation(self):
        """Verify phone number is masked and chaotic punctuation is condensed."""
        input_text = "Senior called me from 9876543210 and threatened me????!!!!"
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertIn("[PHONE]", result["protected_text"])
        self.assertNotIn("9876543210", result["protected_text"])
        self.assertIn("?!", result["protected_text"])
        self.assertNotIn("????!!!!", result["protected_text"])
        self.assertTrue(result["safe_representation"]["has_question"])
        self.assertTrue(result["safe_representation"]["has_exclamation"])
        self.assertTrue(result["risk_signals"]["has_threat_language"])

    def test_03_email_and_all_caps(self):
        """Verify email is masked and shouting all-caps text is de-shouted."""
        input_text = "SEND ALL EVIDENCE TO ADMIN@COLLEGE.EDU.IN IMMEDIATELY OR SUFFER THE CONSEQUENCES."
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertIn("[EMAIL]", result["protected_text"])
        self.assertNotIn("ADMIN@COLLEGE.EDU.IN", result["protected_text"])
        self.assertFalse(result["protected_text"].isupper())
        self.assertTrue(result["protected_text"].startswith("Send all evidence"))
        self.assertTrue(result["risk_signals"]["has_urgent_language"])

    def test_04_room_number_and_repeated_letters(self):
        """Verify hostel room is masked and character-stretching is normalized."""
        input_text = "Pleeeease help, they are in room 405 right nowwww."
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertIn("[ROOM]", result["protected_text"])
        self.assertNotIn("405", result["protected_text"])
        self.assertIn("Please help", result["protected_text"])
        self.assertIn("now.", result["protected_text"])
        self.assertNotIn("Pleeeease", result["protected_text"])
        self.assertNotIn("nowwww", result["protected_text"])
        self.assertTrue(result["risk_signals"]["has_help_seeking"])
        self.assertTrue(result["risk_signals"]["has_urgent_language"])

    def test_05_hinglish_complaint_and_emojis(self):
        """Verify code-mixed Hinglish distress complaint with repeated emojis is sanitized."""
        input_text = "Bhai bohot darr lag raha hai hostel me 😭😭😭😭 seniors abuse kar rahe hai"
        result = protect_text(input_text)
        
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["protected_text"], "Bhai bohot darr lag raha hai hostel me 😭 seniors abuse kar rahe hai")
        self.assertEqual(result["safe_representation"]["language_hint"], "hinglish")
        self.assertTrue(result["risk_signals"]["distress_keyword_count"] >= 1)
        self.assertTrue(result["risk_signals"]["has_threat_language"])

    def test_06_multiple_pii_and_stylistic_quirks(self):
        """Verify multiple PII types + chaotic styling are all sanitized simultaneously."""
        input_text = "   CALL ME ON 9123456789 OR VISIT ROOM 102 ASAPPP!!!! MY ROLL NO IS 56   "
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertIn("[PHONE]", result["protected_text"])
        self.assertIn("[ROOM]", result["protected_text"])
        self.assertIn("[STUDENT_ID]", result["protected_text"])
        self.assertNotIn("9123456789", result["protected_text"])
        self.assertNotIn("102", result["protected_text"])
        self.assertNotIn("56", result["protected_text"])
        self.assertNotIn("ASAPPP", result["protected_text"])
        self.assertNotIn("!!!!", result["protected_text"])
        self.assertTrue(result["risk_signals"]["has_urgent_language"])

    def test_07_normal_numbers_preserved(self):
        """Verify general numeric context (counts, time durations) is not removed."""
        input_text = "3 students waited for 45 minutes outside the gate."
        result = protect_text(input_text)
        
        self.assertFalse(result["pii_masked"])
        self.assertEqual(result["protected_text"], "3 students waited for 45 minutes outside the gate.")

    def test_08_empty_and_whitespace_input(self):
        """Verify empty and whitespace strings return clean empty results including preliminary_risk."""
        res1 = protect_text("")
        self.assertEqual(res1["protected_text"], "")
        self.assertFalse(res1["pii_masked"])
        self.assertEqual(res1["safe_representation"]["token_count"], 0)
        self.assertEqual(res1["risk_signals"]["distress_keyword_count"], 0)
        self.assertEqual(res1["sarcasm_signals"]["sarcasm_marker_count"], 0)
        self.assertEqual(res1["feature_summary"]["token_count"], 0)
        self.assertIn("preliminary_risk", res1)
        self.assertEqual(res1["preliminary_risk"]["risk_score"], 0)
        self.assertEqual(res1["preliminary_risk"]["risk_level"], "low")

        res2 = protect_text("   \t\n  ")
        self.assertEqual(res2["protected_text"], "")
        self.assertFalse(res2["pii_masked"])
        self.assertEqual(res2["safe_representation"]["token_count"], 0)
        self.assertEqual(res2["risk_signals"]["threat_keyword_count"], 0)
        self.assertEqual(res2["sarcasm_signals"]["coded_language_marker_count"], 0)
        self.assertEqual(res2["feature_summary"]["language_hint"], "unknown")
        self.assertIn("preliminary_risk", res2)

    def test_09_name_masking_in_pipeline(self):
        """Verify contextual person names are masked in full pipeline flow."""
        input_text = "My name is Rahul and my friend Aman from CSE was harassed by seniors."
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertNotIn("Rahul", result["protected_text"])
        self.assertNotIn("Aman", result["protected_text"])
        self.assertIn("[PERSON]", result["protected_text"])
        self.assertIn("My name is [PERSON]", result["protected_text"])
        self.assertTrue(result["risk_signals"]["has_threat_language"])

    def test_10_combined_pii_name_and_style_quirks(self):
        """Verify combined test with Name + Phone + Room + All-Caps + Punctuation."""
        input_text = "MY NAME IS RAHUL AND I LIVE IN ROOM 204. CALL ME ON 9876543210 PLEAAAASE HELP ME!!!!"
        result = protect_text(input_text)
        
        self.assertTrue(result["pii_masked"])
        self.assertIn("[PERSON]", result["protected_text"])
        self.assertIn("[ROOM]", result["protected_text"])
        self.assertIn("[PHONE]", result["protected_text"])
        self.assertIn("please help me!", result["protected_text"])
        self.assertNotIn("RAHUL", result["protected_text"])
        self.assertNotIn("204", result["protected_text"])
        self.assertNotIn("9876543210", result["protected_text"])
        self.assertNotIn("PLEAAAASE", result["protected_text"])
        self.assertFalse(result["protected_text"].isupper())
        self.assertTrue(result["safe_representation"]["token_count"] > 0)
        self.assertTrue(result["risk_signals"]["has_help_seeking"])
        self.assertIn("sarcasm_signals", result)
        self.assertIn("feature_summary", result)
        self.assertIn("preliminary_risk", result)

    def test_11_preliminary_risk_structure_and_safety(self):
        """Verify preliminary_risk sub-dictionary structure and privacy safety."""
        input_text = "Seniors threatened to beat me in room 101. Call 9876543210!"
        result = protect_text(input_text)
        
        self.assertIn("preliminary_risk", result)
        risk_dec = result["preliminary_risk"]
        
        self.assertIn("risk_level", risk_dec)
        self.assertIn("risk_score", risk_dec)
        self.assertIn("reasons", risk_dec)
        
        self.assertIsInstance(risk_dec["risk_score"], int)
        self.assertGreaterEqual(risk_dec["risk_score"], 0)
        self.assertLessEqual(risk_dec["risk_score"], 100)
        self.assertIn(risk_dec["risk_level"], {"low", "medium", "high", "critical"})
        
        # Verify no raw text or PII in reasons
        for reason in risk_dec["reasons"]:
            self.assertNotIn("9876543210", reason)
            self.assertNotIn("room 101", reason)
            self.assertNotIn("threatened", reason)

if __name__ == "__main__":
    unittest.main()

