"""
OMNITRIX Privacy Transformation Engine - Local SQLite Persistence Layer
Provides lightweight, privacy-safe local persistence for sanitized complaint records
and audit trail history for administrative status transitions.
Uses Python's built-in sqlite3 and json modules with zero external database dependencies.

Guarantees:
  - Stores ONLY the output of create_complaint_record().
  - Zero raw text, PII, student names, phone numbers, roll numbers, or device fingerprints.
  - Automatically creates data directory if it does not exist.
  - Idempotent database and schema initialization.
  - Atomic status updates with transition history logging.
"""

import os
import json
import sqlite3
from typing import Dict, Any, List, Optional

# Default database storage location: backend/data/complaints.db
DEFAULT_DB_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
DEFAULT_DB_PATH = os.path.join(DEFAULT_DB_DIR, "complaints.db")

FORBIDDEN_COLUMNS = {
    "raw_text", "original_text", "student_name", "phone", "email",
    "room_number", "roll_number", "ip_address", "device_id", "username",
    "location", "writing_style_fingerprint"
}

ALLOWED_STATUSES = {"new", "in_review", "resolved", "closed"}


DEFAULT_PRELIMINARY_RISK: Dict[str, Any] = {
    "risk_level": "low",
    "risk_score": 0,
    "reasons": []
}


from backend.config import get_db_path as resolve_db_path


def _get_db_path(db_path: Optional[str] = None) -> str:
    """Returns the provided db_path or resolved OMNITRIX_DB_PATH / DEFAULT_DB_PATH."""
    return resolve_db_path(db_path)


def _get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Creates a connection to the specified SQLite database path with WAL mode and foreign keys enabled."""
    path = _get_db_path(db_path)
    if path != ":memory:":
        parent_dir = os.path.dirname(os.path.abspath(path))
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0)
    conn.execute("PRAGMA foreign_keys = ON;")
    if path != ":memory:":
        try:
            conn.execute("PRAGMA journal_mode = WAL;")
        except Exception:
            pass
    return conn


def init_database(db_path: Optional[str] = None) -> None:
    """
    Initializes the SQLite database, creates tables, foreign keys, constraints, and indexes.
    
    Safe to call multiple times (idempotent).
    Does NOT run automatically upon module import.
    Handles seamless ALTER TABLE and index migration if existing database lacks newer columns/indexes.
    """
    path = _get_db_path(db_path)
    if path != ":memory:":
        parent_dir = os.path.dirname(os.path.abspath(path))
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)

    with _get_connection(path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS complaints (
                complaint_id TEXT PRIMARY KEY,
                status TEXT NOT NULL CHECK(status IN ('new', 'in_review', 'resolved', 'closed')),
                protected_text TEXT NOT NULL,
                pii_masked INTEGER NOT NULL CHECK(pii_masked IN (0, 1)),
                safe_representation TEXT NOT NULL,
                privacy_audit TEXT NOT NULL,
                risk_signals TEXT NOT NULL,
                sarcasm_signals TEXT NOT NULL,
                feature_summary TEXT NOT NULL,
                preliminary_risk TEXT NOT NULL DEFAULT '{}',
                encrypted_raw_text TEXT NOT NULL DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS complaint_status_history (
                history_id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT NOT NULL,
                previous_status TEXT NOT NULL CHECK(previous_status IN ('new', 'in_review', 'resolved', 'closed')),
                new_status TEXT NOT NULL CHECK(new_status IN ('new', 'in_review', 'resolved', 'closed')),
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id) ON DELETE CASCADE
            )
            """
        )

        # Migration check: Ensure existing complaints tables gain preliminary_risk & encrypted_raw_text columns safely
        cursor.execute("PRAGMA table_info(complaints);")
        existing_columns = [col[1] for col in cursor.fetchall()]
        if "preliminary_risk" not in existing_columns:
            cursor.execute("ALTER TABLE complaints ADD COLUMN preliminary_risk TEXT NOT NULL DEFAULT '{}';")
        if "encrypted_raw_text" not in existing_columns:
            cursor.execute("ALTER TABLE complaints ADD COLUMN encrypted_raw_text TEXT NOT NULL DEFAULT '';")

        # Create indexes for high-frequency admin list, status filtering, and audit lookups
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_complaints_created_at ON complaints(created_at DESC);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_history_complaint_id ON complaint_status_history(complaint_id, history_id ASC);")

        conn.commit()


def save_complaint_record(record: Dict[str, Any], db_path: Optional[str] = None) -> None:
    """
    Persists a privacy-safe complaint record into the SQLite database.
    
    Guarantees:
      - Validates that no forbidden identity fields are present.
      - Serializes nested dictionaries into JSON strings.
      - Rejects duplicate complaint IDs with sqlite3.IntegrityError.
      - Uses parameterized queries to prevent SQL injection.
    """
    if not isinstance(record, dict):
        raise ValueError("Complaint record must be a dictionary.")

    complaint_id = record.get("complaint_id")
    if not complaint_id or not isinstance(complaint_id, str):
        raise ValueError("Complaint record must contain a valid 'complaint_id' string.")

    # Defensive check: ensure no forbidden identity or raw fields are being passed
    for forbidden in FORBIDDEN_COLUMNS:
        if forbidden in record:
            raise ValueError(f"Forbidden field '{forbidden}' cannot be saved to database.")

    status = str(record.get("status", "new"))
    protected_text = str(record.get("protected_text", ""))
    pii_masked = 1 if record.get("pii_masked") else 0

    safe_representation_json = json.dumps(record.get("safe_representation", {}))
    privacy_audit_json = json.dumps(record.get("privacy_audit", {}))
    risk_signals_json = json.dumps(record.get("risk_signals", {}))
    sarcasm_signals_json = json.dumps(record.get("sarcasm_signals", {}))
    feature_summary_json = json.dumps(record.get("feature_summary", {}))
    preliminary_risk_json = json.dumps(record.get("preliminary_risk", DEFAULT_PRELIMINARY_RISK))
    encrypted_raw_text = str(record.get("encrypted_raw_text", ""))

    with _get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO complaints (
                complaint_id,
                status,
                protected_text,
                pii_masked,
                safe_representation,
                privacy_audit,
                risk_signals,
                sarcasm_signals,
                feature_summary,
                preliminary_risk,
                encrypted_raw_text
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                complaint_id,
                status,
                protected_text,
                pii_masked,
                safe_representation_json,
                privacy_audit_json,
                risk_signals_json,
                sarcasm_signals_json,
                feature_summary_json,
                preliminary_risk_json,
                encrypted_raw_text
            )
        )
        conn.commit()


def _row_to_record(row: tuple) -> Dict[str, Any]:
    """Helper to convert a database row tuple into a structured complaint record dictionary."""
    (
        complaint_id,
        status,
        protected_text,
        pii_masked,
        safe_repr_str,
        audit_str,
        risk_str,
        sarcasm_str,
        features_str,
        preliminary_risk_str,
        encrypted_raw_text,
        created_at
    ) = row

    preliminary_risk_dict = DEFAULT_PRELIMINARY_RISK.copy()
    if preliminary_risk_str:
        try:
            parsed = json.loads(preliminary_risk_str)
            if isinstance(parsed, dict) and "risk_level" in parsed:
                preliminary_risk_dict = parsed
        except Exception:
            pass

    return {
        "complaint_id": complaint_id,
        "status": status,
        "protected_text": protected_text,
        "pii_masked": bool(pii_masked),
        "safe_representation": json.loads(safe_repr_str) if safe_repr_str else {},
        "privacy_audit": json.loads(audit_str) if audit_str else {},
        "risk_signals": json.loads(risk_str) if risk_str else {},
        "sarcasm_signals": json.loads(sarcasm_str) if sarcasm_str else {},
        "feature_summary": json.loads(features_str) if features_str else {},
        "preliminary_risk": preliminary_risk_dict,
        "encrypted_raw_text": encrypted_raw_text or "",
        "created_at": str(created_at) if created_at else ""
    }


def get_complaint_record(complaint_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Retrieves a single privacy-safe complaint record by its complaint_id.
    
    Returns the deserialized dictionary or None if not found.
    """
    if not complaint_id or not isinstance(complaint_id, str):
        return None

    with _get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT
                complaint_id,
                status,
                protected_text,
                pii_masked,
                safe_representation,
                privacy_audit,
                risk_signals,
                sarcasm_signals,
                feature_summary,
                preliminary_risk,
                encrypted_raw_text,
                created_at
            FROM complaints
            WHERE complaint_id = ?
            """,
            (complaint_id,)
        )
        row = cursor.fetchone()
        if row is None:
            return None
        return _row_to_record(row)


def get_all_complaint_records(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Retrieves all privacy-safe complaint records currently stored in the database.
    
    Returns a list of deserialized complaint record dictionaries.
    """
    with _get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT
                complaint_id,
                status,
                protected_text,
                pii_masked,
                safe_representation,
                privacy_audit,
                risk_signals,
                sarcasm_signals,
                feature_summary,
                preliminary_risk,
                encrypted_raw_text,
                created_at
            FROM complaints
            ORDER BY created_at DESC
            """
        )
        rows = cursor.fetchall()
        return [_row_to_record(row) for row in rows]


def record_status_change(
    complaint_id: str,
    previous_status: str,
    new_status: str,
    db_path: Optional[str] = None
) -> None:
    """
    Records a single complaint status transition in the audit history table.
    
    Guarantees:
      - Validates that previous_status and new_status are in ALLOWED_STATUSES.
      - Uses parameterized queries.
      - Contains zero raw complaint text, protected text, signals, or student identities.
    """
    if previous_status not in ALLOWED_STATUSES:
        raise ValueError(f"Invalid previous_status '{previous_status}'. Must be one of {sorted(ALLOWED_STATUSES)}.")
    if new_status not in ALLOWED_STATUSES:
        raise ValueError(f"Invalid new_status '{new_status}'. Must be one of {sorted(ALLOWED_STATUSES)}.")
    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        raise ValueError("complaint_id must be a non-empty string.")

    cid = complaint_id.strip()

    with _get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO complaint_status_history (
                complaint_id,
                previous_status,
                new_status
            ) VALUES (?, ?, ?)
            """,
            (cid, previous_status, new_status)
        )
        conn.commit()


def get_status_history(
    complaint_id: str,
    db_path: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Retrieves all status transition audit records for a complaint in chronological order.
    
    Returns:
      [
          {
              "history_id": int,
              "complaint_id": str,
              "previous_status": str,
              "new_status": str,
              "changed_at": str
          },
          ...
      ]
    """
    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        return []

    cid = complaint_id.strip()

    with _get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT
                history_id,
                complaint_id,
                previous_status,
                new_status,
                changed_at
            FROM complaint_status_history
            WHERE complaint_id = ?
            ORDER BY history_id ASC
            """,
            (cid,)
        )
        rows = cursor.fetchall()
        return [
            {
                "history_id": row[0],
                "complaint_id": row[1],
                "previous_status": row[2],
                "new_status": row[3],
                "changed_at": row[4]
            }
            for row in rows
        ]


def update_complaint_status(
    complaint_id: str,
    status: str,
    db_path: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    """
    Updates ONLY the triage status of an existing complaint record and records
    the status transition history atomically in the same transaction.
    
    Guarantees:
      - Accepts ONLY statuses in ALLOWED_STATUSES ('new', 'in_review', 'resolved', 'closed').
      - Rejects invalid statuses with ValueError.
      - Uses parameterized SQLite queries.
      - If new status equals current status, NO history row is created.
      - If new status differs, updates status and inserts history in a single atomic transaction.
      - Modifies strictly the 'status' column and preserves all analytical/privacy fields.
      - Returns the updated complaint record dictionary, or None if complaint_id does not exist.
    """
    if not status or not isinstance(status, str) or status not in ALLOWED_STATUSES:
        raise ValueError(f"Invalid status '{status}'. Must be one of {sorted(ALLOWED_STATUSES)}.")

    if not complaint_id or not isinstance(complaint_id, str) or not complaint_id.strip():
        return None

    cid = complaint_id.strip()

    with _get_connection(db_path) as conn:
        cursor = conn.cursor()

        # 1. Read current status inside transaction
        cursor.execute(
            "SELECT status FROM complaints WHERE complaint_id = ?",
            (cid,)
        )
        row = cursor.fetchone()
        if row is None:
            return None

        current_status = row[0]

        # 2. If status is changing, atomically update complaints and record history
        if current_status != status:
            cursor.execute(
                "UPDATE complaints SET status = ? WHERE complaint_id = ?",
                (status, cid)
            )
            cursor.execute(
                """
                INSERT INTO complaint_status_history (
                    complaint_id,
                    previous_status,
                    new_status
                ) VALUES (?, ?, ?)
                """,
                (cid, current_status, status)
            )
            conn.commit()

    return get_complaint_record(cid, db_path=db_path)
