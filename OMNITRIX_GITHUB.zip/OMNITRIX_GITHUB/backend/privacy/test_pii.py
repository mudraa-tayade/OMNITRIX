"""
Unit tests for OMNITRIX PII Masker.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.pii import mask_pii

class TestPIIMasker(unittest.TestCase):

    def test_01_phone_masking(self):
        """Verify Indian phone formats (+91, spaced, hyphenated, direct) are masked."""
        input_text = "Call me on 9876543210 or +91 9123456789 if anything happens."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "Call me on [PHONE] or [PHONE] if anything happens.")

    def test_02_email_masking(self):
        """Verify student and standard email addresses are replaced with [EMAIL]."""
        input_text = "Send the proof to student.complaint2024@college.edu.in or victim@gmail.com."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "Send the proof to [EMAIL] or [EMAIL].")

    def test_03_url_masking(self):
        """Verify links (http, https, www) are replaced with [URL] while sentence punctuation is preserved."""
        input_text = "They posted my picture on https://instagram.com/ragging_leak and www.victimsite.org/post1."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "They posted my picture on [URL] and [URL].")

    def test_04_social_handle_masking(self):
        """Verify social media @tags are replaced with [SOCIAL_HANDLE]."""
        input_text = "The senior is threatening me from @rahul_sharma99 and @dark_knight."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "The senior is threatening me from [SOCIAL_HANDLE] and [SOCIAL_HANDLE].")

    def test_05_student_roll_id_masking(self):
        """Verify student roll numbers / registration IDs are masked."""
        input_text = "My roll no is 45 and the accused has Roll Number: 2023-CS-109."
        masked = mask_pii(input_text)
        self.assertIn("roll no is [STUDENT_ID]", masked)
        self.assertIn("Roll Number: [STUDENT_ID]", masked)
        self.assertNotIn("45", masked)
        self.assertNotIn("2023-CS-109", masked)

    def test_06_hostel_room_masking(self):
        """Verify hostel room numbers are masked."""
        input_text = "They came to my room 302 and threatened everyone in Room No. 4B."
        masked = mask_pii(input_text)
        self.assertIn("room [ROOM]", masked)
        self.assertIn("Room No. [ROOM]", masked)
        self.assertNotIn("302", masked)
        self.assertNotIn("4B", masked)

    def test_07_conservative_date_masking(self):
        """Verify calendar dates are masked while descriptive non-date numbers remain intact."""
        input_text = "The incident took place on 12/04/2026 and again on 15th August 2025."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "The incident took place on [DATE] and again on [DATE].")

    def test_08_multiple_pii_types_in_one_complaint(self):
        """Verify multiple mixed PII entities are masked cleanly in a single complaint."""
        input_text = "I am in room 204, my roll no is 88. Contact me at victim@test.com or @anon_user."
        masked = mask_pii(input_text)
        self.assertIn("[ROOM]", masked)
        self.assertIn("[STUDENT_ID]", masked)
        self.assertIn("[EMAIL]", masked)
        self.assertIn("[SOCIAL_HANDLE]", masked)
        self.assertNotIn("204", masked)
        self.assertNotIn("88", masked)
        self.assertNotIn("victim@test.com", masked)
        self.assertNotIn("@anon_user", masked)

    def test_09_normal_numbers_and_text_preserved(self):
        """Verify common non-PII quantities, counts, and durations are not replaced."""
        input_text = "There were 4 seniors standing outside for 2 hours and demanding 500 rupees."
        masked = mask_pii(input_text)
        self.assertEqual(masked, "There were 4 seniors standing outside for 2 hours and demanding 500 rupees.")

    def test_10_hinglish_code_mixed_pii(self):
        """Verify Hinglish code-mixed distress complaint with PII is accurately masked."""
        input_text = "Bhai room 108 me 3 seniors aaye the, unhone bola call 9876543210 pe karo."
        masked = mask_pii(input_text)
        self.assertIn("room [ROOM]", masked)
        self.assertIn("3 seniors", masked)  # Count preserved
        self.assertIn("[PHONE]", masked)
        self.assertNotIn("108", masked)
        self.assertNotIn("9876543210", masked)

if __name__ == "__main__":
    unittest.main()
