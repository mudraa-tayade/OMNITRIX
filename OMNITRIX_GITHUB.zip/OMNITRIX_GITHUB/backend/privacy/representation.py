"""
OMNITRIX Privacy Transformation Engine - Safe Analysis Representation
Generates lightweight, non-identifying structural and linguistic features exclusively from protected text.
"""

import re
from typing import Dict, Any

# Distinct Hinglish/Hindi marker vocabulary (excluding English homographs like in/to/do)
HINGLISH_MARKERS = {
    "hai", "hain", "tha", "thi", "the", "mujhe", "mera", "meri", "mere",
    "ko", "ne", "se", "ka", "ki", "ke", "nahi", "nahin", "mat", "bahut",
    "bohot", "kya", "kyu", "kyun", "kaise", "karo", "kare", "karna", "raha",
    "rahe", "rahi", "hona", "hua", "huye", "aaya", "aaye", "gaya", "gaye",
    "bhai", "yaar", "wala", "wali", "wale", "sab", "unhone", "usne", "unka",
    "uska", "hoga", "hogi", "bhi", "ek", "par", "pe", "ab", "kab", "jab",
    "tab", "aur", "toh", "sirf", "bol", "bola", "boli", "liye", "kal",
    "subah", "shaam", "aana", "padega", "kuch", "kisko", "kisne", "darr",
    "maar", "ladka", "ladki", "karenge", "karta", "karti"
}

# Common English functional words
ENGLISH_MARKERS = {
    "the", "is", "are", "was", "were", "and", "or", "in", "on", "at", "to",
    "for", "with", "from", "by", "about", "into", "through", "during", "they",
    "them", "their", "we", "our", "us", "he", "she", "his", "her", "it",
    "its", "this", "that", "these", "those", "have", "has", "had", "do",
    "does", "did", "can", "could", "will", "would", "should", "my", "your",
    "me", "you", "so", "because", "please", "help", "students", "seniors",
    "every", "night", "outside", "inside", "door", "locked", "saying"
}

def _detect_language_hint(words: list) -> str:
    """
    Lightweight deterministic language heuristic.
    
    Returns:
      - 'hinglish': when heavily dominated by Hindi/Hinglish marker words
      - 'english': when heavily dominated by English functional words
      - 'mixed': when balanced proportions of both English and Hinglish markers exist
      - 'unknown': for empty or unclassifiable inputs
      
    NOTICE: This is a fast, zero-dependency heuristic hint and not an ML-based LID model.
    """
    if not words:
        return "unknown"

    lower_words = [w.lower() for w in words]
    total_words = len(lower_words)

    h_count = sum(1 for w in lower_words if w in HINGLISH_MARKERS)
    e_count = sum(1 for w in lower_words if w in ENGLISH_MARKERS)

    if h_count == 0 and e_count == 0:
        return "english" if total_words > 0 else "unknown"

    if h_count > 0 and e_count == 0:
        return "hinglish"
    elif e_count > 0 and h_count == 0:
        return "english"
    else:
        # Both counts > 0
        if h_count >= 2 * e_count:
            return "hinglish"
        elif e_count >= 2 * h_count:
            return "english"
        else:
            return "mixed"

def build_safe_representation(protected_text: str) -> Dict[str, Any]:
    """
    Builds a privacy-safe structural representation from already-sanitized text.
    
    Guarantees:
      - Operates exclusively on protected_text (never raw text).
      - Contains zero personally identifiable information or raw tokens.
      - Safe for downstream ML consumption or logging.
    """
    if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
        return {
            "language_hint": "unknown",
            "token_count": 0,
            "character_count": 0,
            "has_question": False,
            "has_exclamation": False,
            "has_repeated_punctuation": False
        }

    # Extract words/tokens
    tokens = protected_text.split()
    words_only = re.findall(r'\b[A-Za-z]+\b', protected_text)

    # Detect structural indicators
    has_question = '?' in protected_text
    has_exclamation = '!' in protected_text
    has_repeated_punct = bool(re.search(r'\.{3}|\?!|!\?', protected_text))

    language_hint = _detect_language_hint(words_only)

    return {
        "language_hint": language_hint,
        "token_count": len(tokens),
        "character_count": len(protected_text),
        "has_question": has_question,
        "has_exclamation": has_exclamation,
        "has_repeated_punctuation": has_repeated_punct
    }
