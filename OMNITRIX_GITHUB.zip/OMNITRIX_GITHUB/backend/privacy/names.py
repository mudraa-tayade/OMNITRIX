"""
OMNITRIX Privacy Transformation Engine - Contextual Person Name Masker
Lightweight, conservative, regex and pattern-based person-name detection without heavy ML/NER models.
"""

import re

# Non-name capitalized words (days, months, common openers, titles, roles) to never mask
RESERVED_WORDS = {
    "Today", "Yesterday", "Tomorrow", "Tonight", "Monday", "Tuesday", "Wednesday",
    "Thursday", "Friday", "Saturday", "Sunday", "January", "February", "March",
    "April", "May", "June", "July", "August", "September", "October", "November",
    "December", "Hostel", "College", "Campus", "University", "Department",
    "Admin", "Administration", "Warden", "Dean", "Principal", "Director",
    "Senior", "Seniors", "Junior", "Juniors", "Student", "Students", "First",
    "Second", "Third", "Final", "Sir", "Madam", "Faculty", "Professor",
    "Please", "Help", "Someone", "Nobody", "Everybody", "Anyone", "There",
    "Here", "Where", "When", "What", "Why", "How", "This", "That", "These",
    "Those", "They", "Them", "Their", "We", "Our", "You", "Your", "He", "She",
    "His", "Her", "Him", "CSE", "ECE", "IT", "ME", "EE", "CIVIL", "Block", "Room"
}

# Common predicates / adjectives / pronouns that must never be treated as names
NON_NAME_PREDICATES = {
    "me", "us", "him", "her", "them", "everyone", "someone", "nobody", "all",
    "scared", "terrified", "worried", "writing", "reporting", "facing",
    "feeling", "depressed", "stressed", "complaining", "calling", "staying",
    "living", "suffering", "asking", "sorry", "afraid", "unable", "shocked",
    "crying", "alone", "new", "fine", "ok", "okay", "hurt", "traumatized",
    "anxious", "helpless", "hopeless", "exhausted", "distressed", "safe",
    "not", "in", "from", "at", "a", "an", "the", "too", "so", "very", "quiet"
}

# High-frequency student first names (lookup to augment contextual triggers safely)
COMMON_STUDENT_NAMES = {
    "Rahul", "Rohit", "Aman", "Pooja", "Priya", "Rohan", "Ankit", "Neha",
    "Sneha", "Aditya", "Aryan", "Vikas", "Abhishek", "Shreya", "Divya",
    "Kunal", "Amit", "Saurav", "Ayush", "Tanmay", "Ritu", "Simran",
    "Varun", "Karan", "Nikhil", "Deepak", "Sandeep", "Sachin", "Rakesh",
    "Manish", "Mayank", "Ananya", "Riya", "Rashi", "Akash", "Gaurav",
    "Harsh", "Ishita", "Megha", "Nitin", "Prateek", "Rishabh", "Sakshi",
    "Shivam", "Sumit", "Tarun", "Yash", "Aditi", "Bhavya", "Chirag"
}

def _mask_self_introduction(text: str) -> str:
    """Mask 'My name is X', 'Myself X', 'I am [Name]'."""
    def _replace_name(match):
        prefix = match.group(1)
        name = match.group(2)
        if name.lower() in NON_NAME_PREDICATES or name.capitalize() in RESERVED_WORDS:
            return match.group(0)
        return f"{prefix}[PERSON]"

    # e.g. "My name is Rahul", "MY NAME IS RAHUL", "Mera naam Rahul hai", "Myself Aman"
    text = re.sub(
        r'(\b(?:(?i:my\s+name\s+is|myself|this\s+is|mera\s+naam|uska\s+naam|unka\s+naam))\s+)([A-Za-z]+)\b',
        _replace_name,
        text
    )

    # e.g. "I am Rahul" / "I AM RAHUL" (guarded against "I am scared", "I am terrified")
    def _replace_i_am(match):
        prefix = match.group(1)
        cand = match.group(2)
        if cand.lower() in NON_NAME_PREDICATES or cand.capitalize() in RESERVED_WORDS:
            return match.group(0)
        return f"{prefix}[PERSON]"

    text = re.sub(
        r'(\b(?:(?i:i\s+am|i\'m))\s+)([A-Za-z]+)\b',
        _replace_i_am,
        text
    )

    return text

def _mask_peer_and_role_contexts(text: str) -> str:
    """Mask 'My friend X', 'Student named X', 'Guy named X'."""
    def _replace_peer(match):
        prefix = match.group(1)
        name = match.group(2)
        if name.capitalize() in RESERVED_WORDS or name.lower() in NON_NAME_PREDICATES:
            return match.group(0)
        return f"{prefix}[PERSON]"

    text = re.sub(
        r'(\b(?:(?i:my\s+(?:friend|classmate|roommate|batchmate|senior|junior|colleague|cousin|brother|sister)|student\s+named?|senior\s+named?|junior\s+named?|guy\s+named?|girl\s+named?|boy\s+named?))\s+)([A-Za-z]+)\b',
        _replace_peer,
        text
    )
    return text

def _mask_target_action_contexts(text: str) -> str:
    """Mask 'told X to', 'threatened X', 'asked X' where X is a proper noun/name."""
    def _replace_target(match):
        verb = match.group(1)
        name = match.group(2)
        suffix = match.group(3)
        if name.capitalize() in RESERVED_WORDS or name.lower() in NON_NAME_PREDICATES:
            return match.group(0)
        return f"{verb} [PERSON] {suffix}"

    text = re.sub(
        r'(\b(?:(?i:told|asked|warned|threatened|forced|abused|called|harassed|targeted|approached|bullied)))\s+([A-Za-z]+)\s+((?:(?i:to|and|that|in|on|at|for|by|from|yesterday|today|last|not))\b)',
        _replace_target,
        text
    )
    return text

def _mask_subject_and_department_contexts(text: str) -> str:
    """Mask 'X from CSE', 'X keeps calling me'."""
    def _replace_subj(match):
        name = match.group(1)
        suffix = match.group(2)
        if name.capitalize() in RESERVED_WORDS or name.lower() in NON_NAME_PREDICATES:
            return match.group(0)
        return f"[PERSON] {suffix}"

    text = re.sub(
        r'\b([A-Za-z]+)\s+((?:(?i:from\s+(?:CSE|ECE|IT|ME|EE|CIVIL|Hostel|Block|Room|Department|Class|Batch)|keeps\s+(?:calling|bothering|threatening|harassing|disturbing|forcing)|and\s+his\s+friends|and\s+her\s+friends|and\s+their\s+gang)))\b',
        _replace_subj,
        text
    )
    return text

def _mask_hinglish_name_contexts(text: str) -> str:
    """Mask 'Bhai X ne bola', 'X ne mujhe mara', 'naam hai X'."""
    def _replace_hinglish(match):
        prefix = match.group(1)
        name = match.group(2)
        post = match.group(3)
        if name.capitalize() in RESERVED_WORDS or name.lower() in NON_NAME_PREDICATES:
            return match.group(0)
        return f"{prefix}[PERSON] {post}"

    text = re.sub(
        r'(\b(?:(?i:bhai|yaar|senior))\s+)([A-Za-z]+)\s+((?:(?i:ne|ko|se|ka|ki|ke|bhi))\b)',
        _replace_hinglish,
        text
    )
    return text

def _mask_known_student_names(text: str) -> str:
    """Mask high-confidence common student names."""
    def _replace_known(match):
        word = match.group(0)
        cap = word.capitalize()
        if cap in COMMON_STUDENT_NAMES and cap not in RESERVED_WORDS and word.lower() not in NON_NAME_PREDICATES:
            return "[PERSON]"
        return word

    text = re.sub(r'\b[A-Za-z]+\b', _replace_known, text)
    return text

def mask_person_names(text: str) -> str:
    """
    Mask recognizable person names with [PERSON] using conservative contextual patterns.
    
    LIMITATION NOTICE:
    This is a conservative regex/rule-based masker and NOT a full Named Entity Recognition (NER)
    model. It intentionally prioritizes precision over recall to avoid corrupting normal words
    and emotional complaint vocabulary in Hinglish and English.
    """
    if not text or not isinstance(text, str):
        return ""

    masked = text

    # Apply contextual masking stages
    masked = _mask_self_introduction(masked)
    masked = _mask_peer_and_role_contexts(masked)
    masked = _mask_target_action_contexts(masked)
    masked = _mask_subject_and_department_contexts(masked)
    masked = _mask_hinglish_name_contexts(masked)
    masked = _mask_known_student_names(masked)

    return masked
