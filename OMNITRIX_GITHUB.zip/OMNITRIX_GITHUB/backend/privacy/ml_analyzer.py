"""
OMNITRIX Privacy ML Analyzer Interface.
Provides unified ML prediction entry point operating strictly on privacy-sanitized protected text.
Enforces zero model downloads and graceful safe fallback states when ML is disabled or missing.
"""

from typing import Dict, Any, Optional
from backend.config import get_ml_enabled
from backend.privacy.representation import build_safe_representation
from backend.privacy.ml.muril_adapter import MurilEmotionAdapter
from backend.privacy.ml.tfidf_adapter import TfidfEmotionAdapter, TfidfSarcasmAdapter


def analyze_ml(protected_text: str) -> Dict[str, Any]:
    """
    Analyzes privacy-transformed protected text using local ML model adapters if enabled.
    
    Processing Flow:
      1. Verify protected_text is valid non-empty string.
      2. Extract lightweight language hint via safe representation heuristic (score: 0.0).
      3. If OMNITRIX_ML_ENABLED is False, return safe 'not_loaded' state.
      4. If enabled, attempt inference with local TF-IDF or MuRIL model adapters.
      5. Return structured predictions for available models, with safe fallbacks for missing/unsupported tasks.
      
    Guarantees:
      - Accepts strictly protected_text (never raw text or PII).
      - Zero network calls or automatic model weight downloads.
      - Never fakes ML probabilities or confuses heuristic signals with ML predictions.
    """
    default_emotion = {"label": "unknown", "score": 0.0}
    default_sarcasm = {"label": "unknown", "score": 0.0}
    default_coded = {"label": "unknown", "score": 0.0}

    # Safe handling of empty/invalid inputs
    if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
        return {
            "emotion": default_emotion,
            "sarcasm": default_sarcasm,
            "coded_distress": default_coded,
            "language": {"label": "unknown", "score": 0.0},
            "model_status": "not_loaded"
        }

    # Extract lightweight language hint
    safe_repr = build_safe_representation(protected_text)
    lang_hint = safe_repr.get("language_hint", "unknown")
    language_res = {"label": lang_hint, "score": 0.0}

    # If ML is disabled in environment config
    if not get_ml_enabled():
        return {
            "emotion": default_emotion,
            "sarcasm": default_sarcasm,
            "coded_distress": default_coded,
            "language": language_res,
            "model_status": "not_loaded"
        }

    # Attempt adapter execution if available
    try:
        emotion_res = default_emotion
        sarcasm_res = default_sarcasm
        emotion_loaded = False
        sarcasm_loaded = False

        # 1. Emotion Adapter (Check MuRIL adapter first to support mocked tests, fallback to TF-IDF)
        muril_adapter = MurilEmotionAdapter()
        tfidf_emo = TfidfEmotionAdapter()

        if muril_adapter.is_available():
            emotion_res = muril_adapter.predict(protected_text)
            emotion_loaded = muril_adapter.loaded
        elif tfidf_emo.is_available():
            emotion_res = tfidf_emo.predict(protected_text)
            emotion_loaded = tfidf_emo.loaded

        # 2. Sarcasm Adapter (TF-IDF)
        tfidf_sarcasm = TfidfSarcasmAdapter()
        if tfidf_sarcasm.is_available():
            sarcasm_res = tfidf_sarcasm.predict(protected_text)
            sarcasm_loaded = tfidf_sarcasm.loaded

        model_active = emotion_loaded or sarcasm_loaded
        status = "available" if model_active else "not_loaded"

        return {
            "emotion": emotion_res,
            "sarcasm": sarcasm_res,
            "coded_distress": default_coded,
            "language": language_res,
            "model_status": status
        }

    except Exception:
        return {
            "emotion": default_emotion,
            "sarcasm": default_sarcasm,
            "coded_distress": default_coded,
            "language": language_res,
            "model_status": "error"
        }
