"""
Unit tests for OMNITRIX Risk Signal Extractor.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.risk_signals import extract_risk_signals
from backend.privacy.pipeline import protect_text

class TestRiskSignals(unittest.TestCase):

    def test_01_clean_neutral_complaint(self):
        """Verify neutral complaint has zero risk signal counts."""
        text = "The library timetable was updated for the second semester."
        signals = extract_risk_signals(text)

        self.assertEqual(signals["distress_keyword_count"], 0)
        self.assertEqual(signals["threat_keyword_count"], 0)
        self.assertEqual(signals["urgency_keyword_count"], 0)
        self.assertEqual(signals["help_seeking_count"], 0)
        self.assertEqual(signals["negative_emotion_count"], 0)
        self.assertFalse(signals["has_threat_language"])
        self.assertFalse(signals["has_help_seeking"])
        self.assertFalse(signals["has_urgent_language"])

    def test_02_english_distress_complaint(self):
        """Verify English distress indicators are detected."""
        text = "I am terrified and feel completely helpless and unsafe in the hostel."
        signals = extract_risk_signals(text)

        self.assertTrue(signals["distress_keyword_count"] >= 3)
        self.assertFalse(signals["has_threat_language"])

    def test_03_threat_related_complaint(self):
        """Verify threat and assault keywords are detected."""
        text = "Seniors threatened to beat me if I filed a ragging complaint."
        signals = extract_risk_signals(text)

        self.assertTrue(signals["threat_keyword_count"] >= 3)
        self.assertTrue(signals["has_threat_language"])
        self.assertTrue(signals["has_help_seeking"])  # "complaint" matched

    def test_04_urgent_help_seeking_complaint(self):
        """Verify urgency and help-seeking indicators are detected."""
        text = "Please help immediately, this is an emergency right now!"
        signals = extract_risk_signals(text)

        self.assertTrue(signals["has_help_seeking"])
        self.assertTrue(signals["has_urgent_language"])
        self.assertTrue(signals["urgency_keyword_count"] >= 3)
        self.assertTrue(signals["help_seeking_count"] >= 1)

    def test_05_hinglish_distress_complaint(self):
        """Verify Hinglish emotional distress keywords are counted."""
        text = "Bhai hostel me bohot darr lag raha hai, pareshan kar rahe hai."
        signals = extract_risk_signals(text)

        self.assertTrue(signals["distress_keyword_count"] >= 2)

    def test_06_mixed_english_hinglish_threat(self):
        """Verify mixed code-switched threat expressions are identified."""
        text = "Seniors ne dhamki di hai that they will hit anyone who leaves the room."
        signals = extract_risk_signals(text)

        self.assertTrue(signals["has_threat_language"])
        self.assertTrue(signals["threat_keyword_count"] >= 2)

    def test_07_multiple_signal_categories_together(self):
        """Verify complex complaint triggers all distinct signal indicators simultaneously."""
        text = "I am scared and terrified! Seniors threatened to beat me. Please help immediately!"
        signals = extract_risk_signals(text)

        self.assertTrue(signals["distress_keyword_count"] >= 2)
        self.assertTrue(signals["threat_keyword_count"] >= 2)
        self.assertTrue(signals["urgency_keyword_count"] >= 1)
        self.assertTrue(signals["help_seeking_count"] >= 1)
        self.assertTrue(signals["has_threat_language"])
        self.assertTrue(signals["has_help_seeking"])
        self.assertTrue(signals["has_urgent_language"])

    def test_08_empty_input(self):
        """Verify empty and whitespace inputs return clean zero counts."""
        signals = extract_risk_signals("")
        self.assertEqual(signals["distress_keyword_count"], 0)
        self.assertFalse(signals["has_threat_language"])

    def test_09_person_token_does_not_affect_matching(self):
        """Verify sanitized [PERSON] placeholder does not interfere with surrounding distress words."""
        text = "Seniors told [PERSON] that they will beat [PERSON] if he speaks."
        signals = extract_risk_signals(text)

        self.assertTrue(signals["has_threat_language"])
        self.assertTrue(signals["threat_keyword_count"] >= 1)

    def test_10_no_matched_keyword_strings_returned(self):
        """Verify dictionary contains only ints and bools, zero keyword strings."""
        text = "They are threatening to kill me, please help!"
        signals = extract_risk_signals(text)

        for k, v in signals.items():
            self.assertTrue(isinstance(v, (int, bool)), f"Non-primitive found in risk_signals: {k} = {type(v)}")

        sig_str = str(signals)
        self.assertNotIn("threatening", sig_str)
        self.assertNotIn("kill", sig_str)
        self.assertNotIn("please help", sig_str)

    def test_11_protected_pii_remains_irrelevant_to_extractor(self):
        """Verify [ROOM], [PHONE], [EMAIL] tokens do not generate false positive risk signals."""
        text = "I am staying in room [ROOM] and my contact is [PHONE]."
        signals = extract_risk_signals(text)

        self.assertEqual(signals["threat_keyword_count"], 0)
        self.assertEqual(signals["distress_keyword_count"], 0)
        self.assertFalse(signals["has_threat_language"])

    def test_12_protected_text_unmodified_during_extraction(self):
        """Verify original protected_text string reference remains strictly unchanged."""
        original_protected = "Seniors are threatening juniors in room [ROOM]!"
        text_copy = str(original_protected)
        _ = extract_risk_signals(text_copy)

        self.assertEqual(text_copy, original_protected)

if __name__ == "__main__":
    unittest.main()
