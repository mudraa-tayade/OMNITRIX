"""
Unit tests for OMNITRIX Unified ML Feature Summary Aggregator.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.features import build_feature_summary
from backend.privacy.pipeline import protect_text

class TestFeatureSummary(unittest.TestCase):

    def test_01_english_feature_summary(self):
        """Verify English complaint produces expected English feature summary."""
        raw_text = "Seniors are threatening first year students in the corridor."
        result = protect_text(raw_text)
        features = result["feature_summary"]

        self.assertEqual(features["language_hint"], "english")
        self.assertTrue(features["token_count"] > 0)
        self.assertTrue(features["has_threat_language"])
        self.assertFalse(features["has_sarcasm_markers"])

    def test_02_hinglish_feature_summary(self):
        """Verify Hinglish complaint reflects Hinglish language hint and distress count."""
        raw_text = "Bhai bohot darr lag raha hai hostel me, pareshan kar rahe hai."
        result = protect_text(raw_text)
        features = result["feature_summary"]

        self.assertEqual(features["language_hint"], "hinglish")
        self.assertTrue(features["distress_keyword_count"] >= 2)

    def test_03_mixed_language_feature_summary(self):
        """Verify mixed language complaint reflects mixed hint and threat signals."""
        raw_text = "Seniors ne dhamki di hai that they will hit anyone who leaves the room."
        result = protect_text(raw_text)
        features = result["feature_summary"]

        self.assertIn(features["language_hint"], ["mixed", "hinglish"])
        self.assertTrue(features["has_threat_language"])

    def test_04_distress_signals_correctly_copied(self):
        """Verify distress keyword counts are accurately mapped into features."""
        safe_rep = {"language_hint": "english", "token_count": 10, "character_count": 50}
        risk_sig = {"distress_keyword_count": 4, "threat_keyword_count": 0, "urgency_keyword_count": 0}
        sarcasm_sig = {"sarcasm_marker_count": 0}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertEqual(summary["distress_keyword_count"], 4)

    def test_05_threat_signals_correctly_copied(self):
        """Verify threat language indicators and counts are mapped."""
        safe_rep = {"token_count": 12}
        risk_sig = {"threat_keyword_count": 3, "has_threat_language": True}
        sarcasm_sig = {}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertEqual(summary["threat_keyword_count"], 3)
        self.assertTrue(summary["has_threat_language"])

    def test_06_urgency_signals_correctly_copied(self):
        """Verify urgency signals are mapped."""
        safe_rep = {}
        risk_sig = {"urgency_keyword_count": 2, "has_urgent_language": True}
        sarcasm_sig = {}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertEqual(summary["urgency_keyword_count"], 2)
        self.assertTrue(summary["has_urgent_language"])

    def test_07_help_seeking_signals_correctly_copied(self):
        """Verify help-seeking signals are mapped."""
        safe_rep = {}
        risk_sig = {"help_seeking_count": 1, "has_help_seeking": True}
        sarcasm_sig = {}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertEqual(summary["help_seeking_count"], 1)
        self.assertTrue(summary["has_help_seeking"])

    def test_08_sarcasm_signals_correctly_copied(self):
        """Verify sarcasm and coded language counts/flags are mapped."""
        safe_rep = {}
        risk_sig = {}
        sarcasm_sig = {
            "sarcasm_marker_count": 2,
            "coded_language_marker_count": 1,
            "has_sarcasm_markers": True,
            "has_coded_language_markers": True
        }

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertEqual(summary["sarcasm_marker_count"], 2)
        self.assertEqual(summary["coded_language_marker_count"], 1)
        self.assertTrue(summary["has_sarcasm_markers"])
        self.assertTrue(summary["has_coded_language_markers"])

    def test_09_empty_dictionaries_handled_safely(self):
        """Verify passing empty dicts or None produces default zero/boolean/unknown values without crashing."""
        summary1 = build_feature_summary({}, {}, {})
        self.assertEqual(summary1["language_hint"], "unknown")
        self.assertEqual(summary1["token_count"], 0)
        self.assertEqual(summary1["distress_keyword_count"], 0)
        self.assertFalse(summary1["has_threat_language"])
        self.assertFalse(summary1["has_sarcasm_markers"])

        summary2 = build_feature_summary(None, None, None)
        self.assertEqual(summary2["language_hint"], "unknown")
        self.assertEqual(summary2["character_count"], 0)

    def test_10_no_raw_complaint_text_accepted_or_stored(self):
        """Verify build_feature_summary has no raw_text parameter and stores zero raw strings."""
        raw_secret = "Secret student complaint details that must never appear in features."
        safe_rep = {"token_count": 5}
        risk_sig = {}
        sarcasm_sig = {}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        self.assertNotIn("raw_text", summary)
        self.assertNotIn(raw_secret, str(summary))

    def test_11_no_matched_keyword_strings_appear(self):
        """Verify summary values are strictly int, bool, or language string."""
        safe_rep = {"language_hint": "english", "token_count": 15, "character_count": 80}
        risk_sig = {"threat_keyword_count": 1, "has_threat_language": True}
        sarcasm_sig = {"sarcasm_marker_count": 1, "has_sarcasm_markers": True}

        summary = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        for k, v in summary.items():
            self.assertTrue(
                isinstance(v, (int, bool, str)),
                f"Invalid type for feature key '{k}': {type(v)}"
            )

    def test_12_protect_text_returns_feature_summary(self):
        """Verify pipeline returns feature_summary with all expected keys."""
        raw_text = "Please help me in room 102 immediately!"
        result = protect_text(raw_text)

        self.assertIn("feature_summary", result)
        features = result["feature_summary"]
        expected_keys = {
            "language_hint", "token_count", "character_count",
            "has_question", "has_exclamation", "has_repeated_punctuation",
            "distress_keyword_count", "threat_keyword_count", "urgency_keyword_count",
            "help_seeking_count", "negative_emotion_count",
            "sarcasm_marker_count", "coded_language_marker_count", "indirect_distress_marker_count",
            "has_threat_language", "has_help_seeking", "has_urgent_language",
            "has_sarcasm_markers", "has_coded_language_markers", "has_indirect_distress"
        }
        self.assertEqual(set(features.keys()), expected_keys)

    def test_13_existing_protected_text_remains_unchanged(self):
        """Verify protected_text output is untouched by feature summary creation."""
        raw_text = "My name is Rahul and I live in room 204."
        result = protect_text(raw_text)

        self.assertEqual(
            result["protected_text"],
            "My name is [PERSON] and I live in room [ROOM]."
        )

if __name__ == "__main__":
    unittest.main()
