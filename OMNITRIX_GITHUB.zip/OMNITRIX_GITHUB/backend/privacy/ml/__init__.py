"""
OMNITRIX Privacy ML Adapter Module.
Provides abstract interfaces and concrete model adapters for ML components.
"""

from backend.privacy.ml.base import BaseModelAdapter
from backend.privacy.ml.muril_adapter import MurilEmotionAdapter

__all__ = [
    "BaseModelAdapter",
    "MurilEmotionAdapter"
]
