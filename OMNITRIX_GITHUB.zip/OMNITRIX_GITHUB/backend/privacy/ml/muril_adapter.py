"""
OMNITRIX MuRIL Emotion Model Adapter.
Provides lightweight interface for MuRIL emotion classification model.
Enforces zero automatic model downloads and lazy loading.
Operates strictly on privacy-sanitized protected_text.
"""

import os
import json
from typing import Dict, Any, Optional
from backend.config import get_ml_enabled, get_ml_model_path
from backend.privacy.ml.base import BaseModelAdapter
from backend.privacy.ml.model_readiness import check_muril_readiness


class MurilEmotionAdapter(BaseModelAdapter):
    """
    Adapter for the fine-tuned MuRIL emotion classification model.
    Wraps model loading and inference while guaranteeing safe fallback states when disabled or uninitialized.
    """

    def __init__(self, model_path: Optional[str] = None):
        self.model_path = model_path or get_ml_model_path()
        self.loaded = False
        self.tokenizer = None
        self.model = None
        self.label_mapping: Dict[str, str] = {}

    def is_available(self) -> bool:
        """
        Checks if ML is enabled and local model directory & base weights exist.
        Does NOT trigger model download or heavy weight loading.
        """
        if not get_ml_enabled():
            return False

        readiness = check_muril_readiness(self.model_path)
        return readiness.get("ready_for_inference", False)

    def load(self) -> bool:
        """
        Lazy-loads tokenizer and model if available.
        Catches exceptions gracefully if weights or libraries are missing.
        Enforces local_files_only=True to prevent network downloads.
        """
        if self.loaded:
            return True

        if not self.is_available():
            return False

        try:
            label_map_file = os.path.join(self.model_path, "label_mapping.json")
            with open(label_map_file, "r", encoding="utf-8") as f:
                self.label_mapping = json.load(f)

            # Lazy import heavy ML frameworks inside load() only
            import torch
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            from peft import PeftModel

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_path,
                local_files_only=True
            )
            base_model = AutoModelForSequenceClassification.from_pretrained(
                "google/muril-base-cased",
                num_labels=len(self.label_mapping),
                attn_implementation="eager",
                local_files_only=True
            ).to(device)

            self.model = PeftModel.from_pretrained(base_model, self.model_path).to(device)
            self.model.eval()

            self.loaded = True
            return True

        except Exception:
            self.loaded = False
            self.model = None
            self.tokenizer = None
            return False

    def predict(self, protected_text: str) -> Dict[str, Any]:
        """
        Predicts emotion for privacy-transformed protected text.
        Returns {"label": "...", "score": 0.0}
        """
        default_state = {"label": "unknown", "score": 0.0}

        if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
            return default_state

        if not self.loaded:
            success = self.load()
            if not success:
                return default_state

        try:
            import torch
            device = next(self.model.parameters()).device

            inputs = self.tokenizer(
                protected_text,
                return_tensors="pt",
                truncation=True,
                max_length=128,
                padding=True
            ).to(device)

            with torch.no_grad():
                outputs = self.model(**inputs)

            probs = torch.nn.functional.softmax(outputs.logits, dim=1)
            conf, pred_id = torch.max(probs, dim=1)

            emotion_label = self.label_mapping.get(str(int(pred_id.item())), "unknown")
            confidence = round(float(conf.item()), 4)

            return {
                "label": emotion_label,
                "score": confidence
            }

        except Exception:
            return default_state
