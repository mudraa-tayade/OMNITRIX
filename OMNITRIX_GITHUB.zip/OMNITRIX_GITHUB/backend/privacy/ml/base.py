"""
OMNITRIX Base Model Adapter Interface.
Defines abstract contract for local ML models (emotion, sarcasm, coded distress, language).
Ensures models interact ONLY with privacy-transformed protected text.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional


class BaseModelAdapter(ABC):
    """
    Abstract base class for OMNITRIX ML model adapters.
    All ML models must implement this interface to be integrated into ml_analyzer.
    """

    @abstractmethod
    def is_available(self) -> bool:
        """
        Returns True if model weights and requirements are present locally and enabled.
        Must NOT attempt heavy loading or network downloads.
        """
        pass

    @abstractmethod
    def load(self) -> bool:
        """
        Loads the model weights and tokenizer into memory.
        Returns True if successful, False otherwise.
        Must fail gracefully without crashing the application.
        """
        pass

    @abstractmethod
    def predict(self, protected_text: str) -> Dict[str, Any]:
        """
        Executes inference strictly on privacy-transformed protected text.
        Returns a dictionary with 'label' and 'score'.
        """
        pass
