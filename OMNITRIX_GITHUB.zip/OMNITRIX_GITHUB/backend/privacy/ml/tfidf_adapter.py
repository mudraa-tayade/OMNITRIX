"""
OMNITRIX Lightweight TF-IDF Model Adapters (Step 55).
Provides lightweight, offline inference wrappers for scikit-learn Emotion and Sarcasm models.
Operates strictly on privacy-sanitized protected_text.
Enforces lazy loading and zero automatic external downloads.
"""

import os
import json
import numpy as np
from typing import Dict, Any, Optional
from backend.config import get_ml_enabled, get_ml_model_path
from backend.privacy.ml.base import BaseModelAdapter


def _sigmoid(x: float) -> float:
    """Helper sigmoid to map decision function values cleanly into (0, 1) scores."""
    return float(1.0 / (1.0 + np.exp(-x)))


class TfidfEmotionAdapter(BaseModelAdapter):
    """
    Lightweight adapter for the TF-IDF Emotion Classification model (10 classes).
    """

    def __init__(self, model_dir: Optional[str] = None):
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.model_dir = model_dir or os.path.join(base_dir, "ml", "models", "emotion_tfidf")
        self.loaded = False
        self.model = None
        self.label_mapping: Dict[str, str] = {}

    def is_available(self) -> bool:
        """Checks if ML is enabled and local model.joblib and label_mapping.json exist."""
        if not get_ml_enabled():
            return False

        env_path = get_ml_model_path()
        if env_path and not os.path.exists(env_path):
            return False

        if not self.model_dir or not os.path.exists(self.model_dir):
            return False

        model_file = os.path.join(self.model_dir, "model.joblib")
        label_map_file = os.path.join(self.model_dir, "label_mapping.json")

        return os.path.exists(model_file) and os.path.exists(label_map_file)

    def load(self) -> bool:
        """Lazy loads joblib model and label mapping."""
        if self.loaded:
            return True

        if not self.is_available():
            return False

        try:
            import joblib
            label_map_file = os.path.join(self.model_dir, "label_mapping.json")
            model_file = os.path.join(self.model_dir, "model.joblib")

            with open(label_map_file, "r", encoding="utf-8") as f:
                self.label_mapping = json.load(f)

            self.model = joblib.load(model_file)
            self.loaded = True
            return True

        except Exception:
            self.loaded = False
            self.model = None
            return False

    def predict(self, protected_text: str) -> Dict[str, Any]:
        """Predicts emotion for privacy-transformed protected text."""
        default_state = {"label": "unknown", "score": 0.0}

        if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
            return default_state

        if not self.loaded:
            success = self.load()
            if not success:
                return default_state

        try:
            pred_id = self.model.predict([protected_text])[0]
            pred_str = str(int(pred_id))
            label = self.label_mapping.get(pred_str, "unknown")

            score = 0.0
            if hasattr(self.model, "predict_proba"):
                probs = self.model.predict_proba([protected_text])[0]
                score = round(float(np.max(probs)), 4)
            elif hasattr(self.model, "decision_function"):
                decisions = self.model.decision_function([protected_text])[0]
                if isinstance(decisions, np.ndarray) and len(decisions) > int(pred_id):
                    # For multi-class decision_function, apply softmax over margins to bound score
                    max_dec = np.max(decisions)
                    exp_dec = np.exp(decisions - max_dec)
                    probs = exp_dec / np.sum(exp_dec)
                    score = round(float(probs[int(pred_id)]), 4)
                elif isinstance(decisions, (float, np.floating, int, np.integer)):
                    score = round(_sigmoid(float(decisions)), 4)

            return {
                "label": label,
                "score": score
            }

        except Exception:
            return default_state


class TfidfSarcasmAdapter(BaseModelAdapter):
    """
    Lightweight adapter for the TF-IDF Sarcasm Classification model (binary).
    """

    def __init__(self, model_dir: Optional[str] = None):
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.model_dir = model_dir or os.path.join(base_dir, "ml", "models", "sarcasm_tfidf")
        self.loaded = False
        self.model = None
        self.label_mapping: Dict[str, str] = {}

    def is_available(self) -> bool:
        """Checks if ML is enabled and local model.joblib and label_mapping.json exist."""
        if not get_ml_enabled():
            return False

        env_path = get_ml_model_path()
        if env_path and not os.path.exists(env_path):
            return False

        if not self.model_dir or not os.path.exists(self.model_dir):
            return False

        model_file = os.path.join(self.model_dir, "model.joblib")
        label_map_file = os.path.join(self.model_dir, "label_mapping.json")

        return os.path.exists(model_file) and os.path.exists(label_map_file)

    def load(self) -> bool:
        """Lazy loads joblib model and label mapping."""
        if self.loaded:
            return True

        if not self.is_available():
            return False

        try:
            import joblib
            label_map_file = os.path.join(self.model_dir, "label_mapping.json")
            model_file = os.path.join(self.model_dir, "model.joblib")

            with open(label_map_file, "r", encoding="utf-8") as f:
                self.label_mapping = json.load(f)

            self.model = joblib.load(model_file)
            self.loaded = True
            return True

        except Exception:
            self.loaded = False
            self.model = None
            return False

    def predict(self, protected_text: str) -> Dict[str, Any]:
        """Predicts sarcasm for privacy-transformed protected text."""
        default_state = {"label": "unknown", "score": 0.0}

        if not protected_text or not isinstance(protected_text, str) or not protected_text.strip():
            return default_state

        if not self.loaded:
            success = self.load()
            if not success:
                return default_state

        try:
            pred_id = self.model.predict([protected_text])[0]
            pred_str = str(int(pred_id))
            label = self.label_mapping.get(pred_str, "unknown")

            score = 0.0
            if hasattr(self.model, "predict_proba"):
                probs = self.model.predict_proba([protected_text])[0]
                score = round(float(np.max(probs)), 4)
            elif hasattr(self.model, "decision_function"):
                decisions = self.model.decision_function([protected_text])[0]
                if isinstance(decisions, (float, np.floating, int, np.integer)):
                    score = round(_sigmoid(float(decisions)), 4)
                elif isinstance(decisions, np.ndarray) and len(decisions) > 0:
                    margin = float(decisions[int(pred_id)]) if len(decisions) > int(pred_id) else float(decisions[0])
                    score = round(_sigmoid(margin), 4)

            return {
                "label": label,
                "score": score
            }

        except Exception:
            return default_state
