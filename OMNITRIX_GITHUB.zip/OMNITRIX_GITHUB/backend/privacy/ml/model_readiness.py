"""
OMNITRIX MuRIL Model Readiness Audit Module (Step 52).
Performs lightweight, offline inspection of local MuRIL emotion checkpoint,
tokenizer files, label mappings, and local HuggingFace base model cache.
Guarantees zero model downloads and zero network requests.
"""

import os
import json
from typing import Dict, Any, Optional
from backend.config import get_ml_model_path


def is_base_model_cached_locally(model_name: str = "google/muril-base-cased") -> bool:
    """
    Checks whether base model weights exist in local HuggingFace cache or custom cache directory.
    Operates strictly via local filesystem inspection without network calls or framework imports.
    """
    if not model_name or not isinstance(model_name, str):
        return False

    # Determine HuggingFace hub cache directory
    hf_home = os.environ.get("HF_HOME")
    transformers_cache = os.environ.get("TRANSFORMERS_CACHE")

    if hf_home:
        hub_cache = os.path.join(hf_home, "hub")
    elif transformers_cache:
        hub_cache = transformers_cache
    else:
        hub_cache = os.path.expanduser("~/.cache/huggingface/hub")

    if not os.path.exists(hub_cache):
        return False

    # Standard HF cache directory naming: models--<org>--<repo>
    folder_name = "models--" + model_name.replace("/", "--")
    model_cache_dir = os.path.join(hub_cache, folder_name)

    if not os.path.exists(model_cache_dir):
        return False

    # Inspect snapshots directory for model weight files
    snapshots_dir = os.path.join(model_cache_dir, "snapshots")
    if not os.path.exists(snapshots_dir):
        return False

    try:
        snapshots = os.listdir(snapshots_dir)
        for snapshot in snapshots:
            snap_path = os.path.join(snapshots_dir, snapshot)
            if os.path.isdir(snap_path):
                files = os.listdir(snap_path)
                has_weights = any(
                    f in files or f.endswith(".safetensors") or f.endswith(".bin")
                    for f in ["pytorch_model.bin", "model.safetensors", "model.bin"]
                )
                has_config = "config.json" in files
                if has_weights and has_config:
                    return True
    except Exception:
        return False

    return False


def check_muril_readiness(model_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Evaluates the existing local MuRIL emotion model/checkpoint safely.
    
    Inspects adapter configuration, tokenizer files, label mapping, and local base weights.
    Returns structured readiness information without making network requests or loading heavy ML libraries.
    """
    target_path = model_path or get_ml_model_path()
    base_model_name = "google/muril-base-cased"

    if not target_path or not os.path.exists(target_path):
        return {
            "model_name": base_model_name,
            "adapter_path": target_path or "",
            "adapter_present": False,
            "tokenizer_present": False,
            "label_mapping_present": False,
            "base_model_available_locally": False,
            "ready_for_inference": False,
            "reason": "Model directory does not exist"
        }

    # Inspect adapter config & weights
    adapter_config_file = os.path.join(target_path, "adapter_config.json")
    adapter_weights_st = os.path.join(target_path, "adapter_model.safetensors")
    adapter_weights_bin = os.path.join(target_path, "adapter_model.bin")

    adapter_present = os.path.exists(adapter_config_file) and (
        os.path.exists(adapter_weights_st) or os.path.exists(adapter_weights_bin)
    )

    # Extract base model name from adapter config if available
    if os.path.exists(adapter_config_file):
        try:
            with open(adapter_config_file, "r", encoding="utf-8") as f:
                config_data = json.load(f)
                base_model_name = config_data.get("base_model_name_or_path", base_model_name)
        except Exception:
            pass

    # Inspect tokenizer files
    tokenizer_json = os.path.join(target_path, "tokenizer.json")
    tokenizer_config = os.path.join(target_path, "tokenizer_config.json")
    tokenizer_present = os.path.exists(tokenizer_json) or os.path.exists(tokenizer_config)

    # Inspect label mapping
    label_map_file = os.path.join(target_path, "label_mapping.json")
    label_mapping_present = os.path.exists(label_map_file)

    # Inspect base model availability locally
    base_model_in_adapter_dir = (
        os.path.exists(os.path.join(target_path, "config.json")) and
        (os.path.exists(os.path.join(target_path, "pytorch_model.bin")) or
         os.path.exists(os.path.join(target_path, "model.safetensors")))
    )
    base_model_available = base_model_in_adapter_dir or is_base_model_cached_locally(base_model_name)

    # Determine inference readiness and reason
    if not adapter_present:
        ready = False
        reason = "Adapter configuration or model weights missing"
    elif not tokenizer_present:
        ready = False
        reason = "Tokenizer files missing"
    elif not label_mapping_present:
        ready = False
        reason = "Label mapping file missing"
    elif not base_model_available:
        ready = False
        reason = f"Base MuRIL weights ({base_model_name}) are not available locally"
    else:
        ready = True
        reason = "Model ready for offline inference"

    return {
        "model_name": base_model_name,
        "adapter_path": target_path,
        "adapter_present": adapter_present,
        "tokenizer_present": tokenizer_present,
        "label_mapping_present": label_mapping_present,
        "base_model_available_locally": base_model_available,
        "ready_for_inference": ready,
        "reason": reason
    }
