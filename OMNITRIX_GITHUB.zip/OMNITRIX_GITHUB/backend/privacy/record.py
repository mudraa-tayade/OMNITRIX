"""
OMNITRIX Privacy Transformation Engine - Privacy-Safe Complaint Record Model
Defines the structure for persisting and triaging anonymous anti-ragging complaint records.
Guarantees zero retention of raw text, personal identifiers, device telemetry, or IP addresses.
"""

import uuid
from typing import Dict, Any, Optional

# Forbidden identity and hardware metadata keys that must never enter a record
FORBIDDEN_IDENTITY_FIELDS = {
    "raw_text", "original_text", "student_name", "phone", "email",
    "room_number", "roll_number", "ip_address", "device_id", "username",
    "location", "writing_style_fingerprint", "matched_keywords", "matched_phrases"
}

def create_complaint_record(
    protected_result: Optional[Dict[str, Any]],
    encrypted_raw_text: Optional[str] = None
) -> Dict[str, Any]:
    """
    Constructs a complaint record from the output of protect_complaint() and optional encrypted raw text.
    """
    res = protected_result or {}

    # Generate a cryptographically random UUID independent of text content
    complaint_id = str(uuid.uuid4())

    default_risk = {
        "risk_level": "low",
        "risk_score": 0,
        "reasons": []
    }
    preliminary_risk = res.get("preliminary_risk", default_risk)

    record = {
        "complaint_id": complaint_id,
        "status": "new",
        "protected_text": res.get("protected_text", ""),
        "pii_masked": res.get("pii_masked", False),
        "safe_representation": res.get("safe_representation", {}),
        "privacy_audit": res.get("privacy_audit", {}),
        "risk_signals": res.get("risk_signals", {}),
        "sarcasm_signals": res.get("sarcasm_signals", {}),
        "feature_summary": res.get("feature_summary", {}),
        "preliminary_risk": preliminary_risk,
        "encrypted_raw_text": encrypted_raw_text or "",
        "created_at": res.get("created_at")
    }

    # Defensive check: ensure no forbidden identity key was smuggled into the record
    for forbidden_key in FORBIDDEN_IDENTITY_FIELDS:
        if forbidden_key in record:
            del record[forbidden_key]

    return record
