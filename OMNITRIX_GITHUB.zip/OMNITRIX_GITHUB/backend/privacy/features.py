"""
OMNITRIX Privacy Transformation Engine - ML-Ready Feature Aggregator
Combines non-identifying linguistic, structural, distress, and sarcasm signals into a single
compact feature dictionary for downstream transformer / classifier consumption.

ARCHITECTURAL & SAFETY NOTICE:
This module performs feature aggregation ONLY. It does NOT compute risk scores, risk levels,
or safety classifications, nor does it assign arbitrary weights or heuristics. Downstream
ML models determine how these features contribute to prediction.
"""

from typing import Dict, Any

def build_feature_summary(
    safe_representation: Dict[str, Any],
    risk_signals: Dict[str, Any],
    sarcasm_signals: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Combines privacy-safe signal dictionaries into a single ML-ready feature dictionary.
    
    Guarantees:
      - Operates exclusively on already-created privacy-safe dictionaries.
      - Never accepts raw_text or original complaints.
      - Contains zero personally identifiable information or matched string tokens.
      - Handles missing or empty dictionaries with safe default primitives.
      - Excludes privacy_audit (which is reserved for compliance telemetry).
    """
    safe_rep = safe_representation or {}
    risk_sig = risk_signals or {}
    sarcasm_sig = sarcasm_signals or {}

    return {
        # Structural & Linguistic Metadata
        "language_hint": safe_rep.get("language_hint", "unknown"),
        "token_count": safe_rep.get("token_count", 0),
        "character_count": safe_rep.get("character_count", 0),
        "has_question": safe_rep.get("has_question", False),
        "has_exclamation": safe_rep.get("has_exclamation", False),
        "has_repeated_punctuation": safe_rep.get("has_repeated_punctuation", False),

        # Distress & Threat Signal Counts
        "distress_keyword_count": risk_sig.get("distress_keyword_count", 0),
        "threat_keyword_count": risk_sig.get("threat_keyword_count", 0),
        "urgency_keyword_count": risk_sig.get("urgency_keyword_count", 0),
        "help_seeking_count": risk_sig.get("help_seeking_count", 0),
        "negative_emotion_count": risk_sig.get("negative_emotion_count", 0),

        # Sarcasm & Coded Language Counts
        "sarcasm_marker_count": sarcasm_sig.get("sarcasm_marker_count", 0),
        "coded_language_marker_count": sarcasm_sig.get("coded_language_marker_count", 0),
        "indirect_distress_marker_count": sarcasm_sig.get("indirect_distress_marker_count", 0),

        # Boolean Indicators
        "has_threat_language": risk_sig.get("has_threat_language", False),
        "has_help_seeking": risk_sig.get("has_help_seeking", False),
        "has_urgent_language": risk_sig.get("has_urgent_language", False),
        "has_sarcasm_markers": sarcasm_sig.get("has_sarcasm_markers", False),
        "has_coded_language_markers": sarcasm_sig.get("has_coded_language_markers", False),
        "has_indirect_distress": sarcasm_sig.get("has_indirect_distress", False)
    }
