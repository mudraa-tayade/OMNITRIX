"""
OMNITRIX Privacy Transformation Engine - Base Sanitizer
Deterministic, CPU-only text normalization to remove author-specific stylistic cues.
"""

import re
import unicodedata

# Common short institutional/official acronyms to preserve when normalizing uppercase
PRESERVED_ACRONYMS = {"FIR", "UGC", "HOD", "SOS", "VIP", "AICTE", "ID", "IP", "NCC", "NSS"}

# Recognized PII placeholders to keep canonical uppercase
PII_PLACEHOLDERS = {"[PHONE]", "[EMAIL]", "[URL]", "[SOCIAL_HANDLE]", "[STUDENT_ID]", "[ROOM]", "[DATE]"}

def _normalize_whitespace(text: str) -> str:
    """Normalize tabs, non-breaking spaces, multi-spaces, and excessive blank lines."""
    # Convert all unicode whitespace to standard ascii space
    text = re.sub(r'[\t\r\f\v]+', ' ', text)
    # Collapse multiple spaces into a single space
    text = re.sub(r'[ ]{2,}', ' ', text)
    # Collapse 3+ newlines into a maximum of 2 newlines (paragraph separation)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

def _normalize_punctuation(text: str) -> str:
    """
    Collapse repeated and chaotic punctuation sequences to standard forms.
    Examples:
        'WHY????!!!!' -> 'WHY?!'
        'really......' -> 'really...'
        'no!!!!!!'     -> 'no!'
        'what??'       -> 'what?'
    """
    # Collapse mixed exclamation and question marks into standard '?!' or '!?'
    text = re.sub(r'[?!]{2,}', lambda m: '?!' if '?' in m.group(0) and '!' in m.group(0) else ('?' if '?' in m.group(0) else '!'), text)
    
    # Collapse 4+ consecutive periods into standard ellipsis '...'
    text = re.sub(r'\.{4,}', '...', text)
    
    # Collapse other repeated punctuation marks (e.g., commas, dashes, semicolons, tildes)
    text = re.sub(r'([,;:~_\-–—])\1+', r'\1', text)
    
    return text

def _normalize_repeated_characters(text: str) -> str:
    """
    Normalize elongated word spellings (3+ consecutive identical characters).
    Examples:
        'pleaaaaase' -> 'please'
        'bhaaaaai'   -> 'bhai'
        'soooooo'    -> 'so'
        'helpppp'    -> 'help'
    """
    text = re.sub(r'([a-zA-Z])\1{2,}', r'\1', text)
    return text

def _normalize_emojis_and_symbols(text: str) -> str:
    """
    Normalize consecutive identical emojis or symbols down to a single instance.
    Examples:
        '😭😭😭😭' -> '😭'
        '😡😡😡'   -> '😡'
    """
    # Match consecutive identical non-alphanumeric, non-ASCII/extended symbols
    # preserving bracketed tokens [TAG]
    pattern = re.compile(r'([^\w\s.,?!:;\'"()\[\]\/\-–—])\1+')
    text = pattern.sub(r'\1', text)
    return text

def _normalize_capitalization(text: str) -> str:
    """
    Neutralize aggressive ALL-CAPS or erratic SHOUTING stylistic cues.
    If the text or long words are entirely uppercase, convert to standard sentence casing.
    Preserves bracketed PII placeholders like [EMAIL], [PHONE] and recognized acronyms.
    """
    # Temporarily mask bracketed placeholders [TAG] to preserve their uppercase casing
    placeholders = []
    def _save_placeholder(m):
        placeholders.append(m.group(0))
        return f"__PII_TOKEN_{len(placeholders)-1}__"

    text_masked = re.sub(r'\[[A-Z_]+\]', _save_placeholder, text)

    alpha_chars = [c for c in text_masked if c.isalpha()]
    if not alpha_chars:
        # Restore placeholders and return
        for idx, token in enumerate(placeholders):
            text_masked = text_masked.replace(f"__PII_TOKEN_{idx}__", token)
        return text_masked

    upper_count = sum(1 for c in alpha_chars if c.isupper())
    upper_ratio = upper_count / len(alpha_chars)

    # If the whole text is shouting (all-caps or >60% uppercase with more than 8 letters)
    if upper_ratio > 0.6 and len(alpha_chars) >= 8:
        text_lower = text_masked.lower()
        sentences = re.split(r'([.?!]\s+)', text_lower)
        capitalized_sentences = []
        for s in sentences:
            if s and s[0].isalpha():
                capitalized_sentences.append(s[0].upper() + s[1:])
            else:
                capitalized_sentences.append(s)
        text_masked = "".join(capitalized_sentences)
    else:
        def _lower_if_shouty(match):
            word = match.group(0)
            if word in PRESERVED_ACRONYMS or word.startswith("__PII_TOKEN_"):
                return word
            return word.lower()

        text_masked = re.sub(r'\b[A-Z]{4,}\b', _lower_if_shouty, text_masked)

    # Restore placeholders in exact original form
    for idx, token in enumerate(placeholders):
        text_masked = text_masked.replace(f"__pii_token_{idx}__", token)
        text_masked = text_masked.replace(f"__PII_TOKEN_{idx}__", token)

    return text_masked

def sanitize_text(text: str) -> str:
    """
    Main entry point for local, deterministic stylometry and text normalization.
    Strips author-specific texting habits while preserving complaint semantics and distress signals.
    """
    if not text or not isinstance(text, str):
        return ""

    # 1. Standardize Unicode encoding
    cleaned = unicodedata.normalize("NFKC", text)

    # 2. Normalize whitespace
    cleaned = _normalize_whitespace(cleaned)

    # 3. Normalize repeated characters
    cleaned = _normalize_repeated_characters(cleaned)

    # 4. Normalize repeated punctuation
    cleaned = _normalize_punctuation(cleaned)

    # 5. Normalize repeated emojis / emotional symbols
    cleaned = _normalize_emojis_and_symbols(cleaned)

    # 6. Normalize stylistic ALL-CAPS writing
    cleaned = _normalize_capitalization(cleaned)

    # 7. Final trim
    return _normalize_whitespace(cleaned)
