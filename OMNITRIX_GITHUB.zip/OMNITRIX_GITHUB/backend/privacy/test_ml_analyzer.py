"""
OMNITRIX ML Analyzer Architecture Unit Tests (Step 51)
Tests lightweight ML analyzer interface, safe fallback state handling, privacy boundaries,
language detection, adapter decoupling, and zero model loading/download guarantees.
"""

import os
import unittest
from unittest.mock import patch, MagicMock

from backend.config import (
    get_ml_enabled,
    get_ml_model_path,
    ML_ENABLED_ENV,
    ML_MODEL_PATH_ENV
)
from backend.privacy.ml.base import BaseModelAdapter
from backend.privacy.ml.muril_adapter import MurilEmotionAdapter
from backend.privacy.ml_analyzer import analyze_ml
from backend.privacy.analysis_service import analyze_complaint


class TestMLAnalyzer(unittest.TestCase):

    def setUp(self):
        # Guarantee ML is disabled by default for tests
        os.environ[ML_ENABLED_ENV] = "false"

    def tearDown(self):
        os.environ.pop(ML_ENABLED_ENV, None)
        os.environ.pop(ML_MODEL_PATH_ENV, None)

    def test_01_ml_disabled_returns_not_loaded(self):
        """Test 1: When ML is disabled, analyze_ml returns model_status 'not_loaded'."""
        os.environ[ML_ENABLED_ENV] = "false"
        res = analyze_ml("Seniors in hostel wing B are threatening freshers.")
        self.assertEqual(res["model_status"], "not_loaded")
        self.assertEqual(res["emotion"]["label"], "unknown")
        self.assertEqual(res["emotion"]["score"], 0.0)

    def test_02_empty_protected_text_handled_safely(self):
        """Test 2: Empty or whitespace protected text handled safely without crashing."""
        res_empty = analyze_ml("")
        self.assertEqual(res_empty["model_status"], "not_loaded")
        self.assertEqual(res_empty["language"]["label"], "unknown")

        res_ws = analyze_ml("   \n\t  ")
        self.assertEqual(res_ws["model_status"], "not_loaded")
        self.assertEqual(res_ws["language"]["label"], "unknown")

    def test_03_none_input_handled_safely(self):
        """Test 3: None input handled safely without crashing."""
        res = analyze_ml(None)
        self.assertEqual(res["model_status"], "not_loaded")
        self.assertEqual(res["emotion"]["label"], "unknown")
        self.assertEqual(res["language"]["label"], "unknown")

    def test_04_analyze_ml_operates_on_protected_text_only(self):
        """Test 4: Verify analyze_ml accepts protected text and returns valid structure."""
        text = "Seniors are threatening freshers in hostel wing B urgently."
        res = analyze_ml(text)
        expected_keys = {"emotion", "sarcasm", "coded_distress", "language", "model_status"}
        self.assertEqual(set(res.keys()), expected_keys)

    def test_05_raw_text_cannot_leak_into_ml_result(self):
        """Test 5: Raw text, PII, names, and numbers do not leak into returned ML dictionary."""
        raw_with_pii = "John Doe 9876543210 john@test.com room 402 is threatening freshers"
        res = analyze_ml(raw_with_pii)
        res_str = str(res)
        self.assertNotIn("John Doe", res_str)
        self.assertNotIn("9876543210", res_str)
        self.assertNotIn("john@test.com", res_str)

    def test_06_no_automatic_model_loading_on_import(self):
        """Test 6: Importing module or instantiating adapter does not set loaded=True."""
        adapter = MurilEmotionAdapter()
        self.assertFalse(adapter.loaded)
        self.assertIsNone(adapter.model)
        self.assertIsNone(adapter.tokenizer)

    def test_07_no_automatic_model_downloads(self):
        """Test 7: is_available returns False when ML is disabled without attempting weight downloads."""
        os.environ[ML_ENABLED_ENV] = "false"
        adapter = MurilEmotionAdapter()
        self.assertFalse(adapter.is_available())

    def test_08_missing_model_path_yields_not_loaded(self):
        """Test 8: Setting non-existent model path yields model_status 'not_loaded'."""
        os.environ[ML_ENABLED_ENV] = "true"
        os.environ[ML_MODEL_PATH_ENV] = "/non/existent/path/to/model"
        adapter = MurilEmotionAdapter()
        self.assertFalse(adapter.is_available())

        res = analyze_ml("Seniors are causing trouble")
        self.assertEqual(res["model_status"], "not_loaded")

    def test_09_language_result_remains_valid(self):
        """Test 9: Language hint label is preserved with score 0.0."""
        res_eng = analyze_ml("Please help us seniors are threatening freshers")
        self.assertEqual(res_eng["language"]["label"], "english")
        self.assertEqual(res_eng["language"]["score"], 0.0)

        res_hin = analyze_ml("bhai bohot darr lag raha hai room pe aagaye")
        self.assertEqual(res_hin["language"]["label"], "hinglish")
        self.assertEqual(res_hin["language"]["score"], 0.0)

    def test_10_analysis_service_works_with_ml_disabled(self):
        """Test 10: analyze_complaint includes ml_analysis dictionary in 'not_loaded' state."""
        raw_complaint = "Seniors are harassing freshers in the hostel."
        result = analyze_complaint(raw_complaint)
        self.assertIn("ml_analysis", result)
        self.assertEqual(result["ml_analysis"]["model_status"], "not_loaded")

    def test_11_existing_preliminary_risk_remains_unchanged(self):
        """Test 11: Preliminary risk assessment remains identical regardless of ML availability."""
        raw_complaint = "Seniors in hostel wing B are threatening freshers urgently."
        
        # Disabled ML run
        os.environ[ML_ENABLED_ENV] = "false"
        res_disabled = analyze_complaint(raw_complaint)

        # Enabled ML run with unavailable weights
        os.environ[ML_ENABLED_ENV] = "true"
        res_enabled = analyze_complaint(raw_complaint)

        self.assertEqual(res_disabled["preliminary_risk"], res_enabled["preliminary_risk"])

    def test_12_ml_result_contains_no_pii_fields(self):
        """Test 12: Output keys do not contain forbidden PII or identity fields."""
        forbidden_keys = {"raw_text", "student_name", "email", "phone", "room_number", "ip_address"}
        res = analyze_ml("Test complaint text")
        for key in forbidden_keys:
            self.assertNotIn(key, res)

    def test_13_ml_result_contains_no_matched_keywords(self):
        """Test 13: Output does not contain raw phrase lists or matched keywords."""
        res = analyze_ml("Seniors are threatening freshers urgently")
        self.assertNotIn("matched_keywords", res)
        self.assertNotIn("matched_phrases", res)

    @patch("backend.privacy.ml_analyzer.MurilEmotionAdapter")
    def test_14_mock_model_prediction_when_enabled(self, mock_adapter_cls):
        """Test 14: Mock adapter execution returns model_status 'available' and prediction."""
        os.environ[ML_ENABLED_ENV] = "true"

        mock_instance = MagicMock(spec=BaseModelAdapter)
        mock_instance.is_available.return_value = True
        mock_instance.predict.return_value = {"label": "fear", "score": 0.8921}
        mock_instance.loaded = True
        mock_adapter_cls.return_value = mock_instance

        res = analyze_ml("Seniors in hostel wing B are threatening freshers.")
        self.assertEqual(res["model_status"], "available")
        self.assertEqual(res["emotion"]["label"], "fear")
        self.assertEqual(res["emotion"]["score"], 0.8921)


if __name__ == "__main__":
    unittest.main()
