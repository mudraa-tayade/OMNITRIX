"""
Unit tests for OMNITRIX Privacy-Safe Complaint Record Model.
Standard library unittest - no database or external dependencies required.
"""

import unittest
from backend.privacy import protect_complaint, create_complaint_record
from backend.privacy.record import FORBIDDEN_IDENTITY_FIELDS

class TestComplaintRecord(unittest.TestCase):

    def test_01_create_record_from_normal_protected_result(self):
        """Verify record creation from output of protect_complaint()."""
        raw_text = "Seniors told junior students to clean the corridor."
        protected_res = protect_complaint(raw_text)
        record = create_complaint_record(protected_res)

        self.assertIn("complaint_id", record)
        self.assertEqual(record["status"], "new")
        self.assertEqual(record["protected_text"], "Seniors told junior students to clean the corridor.")

    def test_02_complaint_id_exists_and_is_string(self):
        """Verify complaint_id is generated as a non-empty string."""
        protected_res = protect_complaint("Help me please!")
        record = create_complaint_record(protected_res)

        self.assertTrue(isinstance(record["complaint_id"], str))
        self.assertTrue(len(record["complaint_id"]) >= 32)

    def test_03_complaint_id_unique_across_two_different_records(self):
        """Verify complaint_ids for different complaints are completely unique."""
        res1 = protect_complaint("First complaint text.")
        res2 = protect_complaint("Second complaint text.")
        rec1 = create_complaint_record(res1)
        rec2 = create_complaint_record(res2)

        self.assertNotEqual(rec1["complaint_id"], rec2["complaint_id"])

    def test_04_status_defaults_to_new(self):
        """Verify initial triage status is set to 'new'."""
        protected_res = protect_complaint("Sample complaint")
        record = create_complaint_record(protected_res)

        self.assertEqual(record["status"], "new")

    def test_05_feature_summary_preserved(self):
        """Verify feature_summary dictionary is preserved in the record."""
        protected_res = protect_complaint("Threatened by seniors in room 102!")
        record = create_complaint_record(protected_res)

        self.assertIn("feature_summary", record)
        self.assertIn("has_threat_language", record["feature_summary"])
        self.assertTrue(record["feature_summary"]["has_threat_language"])

    def test_06_risk_signals_preserved(self):
        """Verify risk_signals dictionary is preserved."""
        protected_res = protect_complaint("I am scared and terrified in the hostel.")
        record = create_complaint_record(protected_res)

        self.assertIn("risk_signals", record)
        self.assertTrue(record["risk_signals"]["distress_keyword_count"] >= 2)

    def test_07_sarcasm_signals_preserved(self):
        """Verify sarcasm_signals dictionary is preserved."""
        protected_res = protect_complaint("Yeah right, everything is fine.")
        record = create_complaint_record(protected_res)

        self.assertIn("sarcasm_signals", record)
        self.assertTrue(record["sarcasm_signals"]["has_sarcasm_markers"])

    def test_08_privacy_audit_preserved(self):
        """Verify privacy_audit dictionary is preserved."""
        protected_res = protect_complaint("My name is Rahul, call 9876543210")
        record = create_complaint_record(protected_res)

        self.assertIn("privacy_audit", record)
        self.assertEqual(record["privacy_audit"]["phone_count"], 1)
        self.assertEqual(record["privacy_audit"]["person_name_count"], 1)

    def test_09_safe_representation_preserved(self):
        """Verify safe_representation dictionary is preserved."""
        protected_res = protect_complaint("Bhai darr lag raha hai.")
        record = create_complaint_record(protected_res)

        self.assertIn("safe_representation", record)
        self.assertEqual(record["safe_representation"]["language_hint"], "hinglish")

    def test_10_raw_complaint_text_not_accepted_or_stored(self):
        """Verify record contains only protected_text and zero raw_text fields."""
        raw_input = "SECRET_STUDENT_DATA_12345"
        protected_res = protect_complaint(raw_input)
        record = create_complaint_record(protected_res)

        self.assertNotIn("raw_text", record)
        self.assertNotIn("original_text", record)
        self.assertNotIn("raw_complaint", record)

    def test_11_record_does_not_contain_forbidden_identity_fields(self):
        """Verify none of the forbidden identity keys exist in the record."""
        protected_res = protect_complaint("My name is Rahul, room 204")
        record = create_complaint_record(protected_res)

        for forbidden in FORBIDDEN_IDENTITY_FIELDS:
            self.assertNotIn(forbidden, record, f"Forbidden key found in record: {forbidden}")

    def test_12_same_protected_result_receives_different_uuids(self):
        """Verify UUID generation is non-deterministic and independent of text content."""
        protected_res = protect_complaint("Identical input text.")
        rec1 = create_complaint_record(protected_res)
        rec2 = create_complaint_record(protected_res)

        # Same content produces distinct UUIDs
        self.assertNotEqual(rec1["complaint_id"], rec2["complaint_id"])

    def test_13_missing_or_none_result_handled_safely(self):
        """Verify passing None or empty dictionary does not crash."""
        rec1 = create_complaint_record(None)
        self.assertIn("complaint_id", rec1)
        self.assertEqual(rec1["status"], "new")
        self.assertEqual(rec1["protected_text"], "")
        self.assertIn("preliminary_risk", rec1)

        rec2 = create_complaint_record({})
        self.assertIn("complaint_id", rec2)
        self.assertEqual(rec2["status"], "new")
        self.assertIn("preliminary_risk", rec2)

    def test_14_preliminary_risk_carried_from_protected_result(self):
        """Verify preliminary_risk is copied directly from protected_result to complaint record."""
        raw_text = "Seniors threatened to beat me in room 101. Call 9876543210!"
        protected_res = protect_complaint(raw_text)
        record = create_complaint_record(protected_res)

        self.assertIn("preliminary_risk", record)
        self.assertEqual(record["preliminary_risk"], protected_res["preliminary_risk"])

        risk_dec = record["preliminary_risk"]
        self.assertIn("risk_level", risk_dec)
        self.assertIn("risk_score", risk_dec)
        self.assertIn("reasons", risk_dec)

        self.assertIsInstance(risk_dec["risk_score"], int)
        self.assertGreaterEqual(risk_dec["risk_score"], 0)
        self.assertLessEqual(risk_dec["risk_score"], 100)
        self.assertIn(risk_dec["risk_level"], {"low", "medium", "high", "critical"})

        # Verify no raw text or PII in reasons
        for reason in risk_dec["reasons"]:
            self.assertNotIn("9876543210", reason)
            self.assertNotIn("room 101", reason)
            self.assertNotIn("threatened", reason)

    def test_15_record_creation_copies_risk_without_recalculation(self):
        """Verify create_complaint_record copies the existing risk dictionary without calling classify_preliminary_risk."""
        custom_risk = {
            "risk_level": "medium",
            "risk_score": 35,
            "reasons": ["Threat-related language detected"]
        }
        protected_res = {
            "protected_text": "Sanitized text",
            "pii_masked": False,
            "preliminary_risk": custom_risk
        }
        record = create_complaint_record(protected_res)

        self.assertEqual(record["preliminary_risk"], custom_risk)


if __name__ == "__main__":
    unittest.main()
