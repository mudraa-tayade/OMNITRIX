"""
Unit tests for OMNITRIX Privacy Audit Reporter.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.audit import build_privacy_audit
from backend.privacy.pipeline import protect_text

class TestPrivacyAudit(unittest.TestCase):

    def test_01_complaint_with_phone(self):
        """Verify audit reports phone_count=1 and pii_masking transformation."""
        raw_text = "Call me on 9876543210 regarding the ragging."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertEqual(audit["phone_count"], 1)
        self.assertEqual(audit["email_count"], 0)
        self.assertIn("pii_masking", audit["transformations_applied"])

    def test_02_complaint_with_email(self):
        """Verify audit reports email_count=1."""
        raw_text = "Send proofs to admin@college.edu.in"
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertEqual(audit["email_count"], 1)
        self.assertEqual(audit["phone_count"], 0)

    def test_03_complaint_with_url(self):
        """Verify audit reports url_count=1."""
        raw_text = "They created a bullying page on https://instagram.com/ragging_cell"
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertEqual(audit["url_count"], 1)

    def test_04_complaint_with_student_id(self):
        """Verify audit reports student_id_count=1."""
        raw_text = "My roll no is 45 and I was cornered."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertEqual(audit["student_id_count"], 1)

    def test_05_complaint_with_room_number(self):
        """Verify audit reports room_count=1."""
        raw_text = "Incident happened in room 302."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertEqual(audit["room_count"], 1)

    def test_06_complaint_with_person_name(self):
        """Verify audit reports person_name_count=1 and name_detected=True."""
        raw_text = "My name is Rahul and seniors threatened me."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["name_detected"])
        self.assertEqual(audit["person_name_count"], 1)
        self.assertIn("person_name_masking", audit["transformations_applied"])

    def test_07_complaint_with_multiple_pii_types(self):
        """Verify audit accurately tallies mixed PII identifiers."""
        raw_text = "My name is Rahul from room 204. Call me on 9876543210 or email test@edu.in"
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["pii_detected"])
        self.assertTrue(audit["name_detected"])
        self.assertEqual(audit["person_name_count"], 1)
        self.assertEqual(audit["room_count"], 1)
        self.assertEqual(audit["phone_count"], 1)
        self.assertEqual(audit["email_count"], 1)
        self.assertIn("pii_masking", audit["transformations_applied"])
        self.assertIn("person_name_masking", audit["transformations_applied"])

    def test_08_complaint_with_style_normalization(self):
        """Verify audit reports style_normalized=True when letter-stretching or shouting is fixed."""
        raw_text = "PLEAAAASSEEEE STOP THEM NOWWWW!!!!"
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertTrue(audit["style_normalized"])
        self.assertIn("style_normalization", audit["transformations_applied"])

    def test_09_clean_complaint_no_transformations(self):
        """Verify clean text has all zero counts and empty transformations list."""
        raw_text = "Seniors are making juniors stand in the corridor."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertFalse(audit["pii_detected"])
        self.assertFalse(audit["name_detected"])
        self.assertFalse(audit["style_normalized"])
        self.assertEqual(audit["phone_count"], 0)
        self.assertEqual(audit["email_count"], 0)
        self.assertEqual(audit["person_name_count"], 0)
        self.assertEqual(audit["transformations_applied"], [])

    def test_10_counts_only_never_identifier_values(self):
        """Verify audit dictionary contains only primitives (ints, bools, list of strings) and zero raw identifiers."""
        raw_text = "Contact Rahul at rahul99@gmail.com in room 108"
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        # Check values are strictly int, bool, or list of generic category strings
        for key, value in audit.items():
            if key == "transformations_applied":
                self.assertIsInstance(value, list)
                for item in value:
                    self.assertIn(item, ["pii_masking", "person_name_masking", "style_normalization"])
            elif isinstance(value, bool) or isinstance(value, int):
                pass
            else:
                self.fail(f"Unexpected data type in audit for key '{key}': {type(value)}")

        # Ensure no original values are stored anywhere in audit
        audit_str = str(audit)
        self.assertNotIn("Rahul", audit_str)
        self.assertNotIn("rahul99@gmail.com", audit_str)
        self.assertNotIn("108", audit_str)

    def test_11_audit_does_not_contain_raw_text(self):
        """Verify raw complaint string is absent from the audit object."""
        raw_text = "Very specific secret complaint sentence that must never leak."
        result = protect_text(raw_text)
        audit = result["privacy_audit"]

        self.assertNotIn("raw_text", audit)
        self.assertNotIn(raw_text, str(audit))

    def test_12_empty_input(self):
        """Verify empty input returns empty audit with zero counts."""
        result = protect_text("")
        audit = result["privacy_audit"]

        self.assertFalse(audit["pii_detected"])
        self.assertFalse(audit["name_detected"])
        self.assertFalse(audit["style_normalized"])
        self.assertEqual(audit["phone_count"], 0)
        self.assertEqual(audit["person_name_count"], 0)
        self.assertEqual(audit["transformations_applied"], [])

if __name__ == "__main__":
    unittest.main()
