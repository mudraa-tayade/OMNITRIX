"""
Unit tests for OMNITRIX Contextual Person Name Masker.
Standard library unittest - no third party dependencies required.
"""

import unittest
from backend.privacy.names import mask_person_names

class TestNameMasker(unittest.TestCase):

    def test_01_self_introduction(self):
        """Verify 'My name is X' masks the name to [PERSON]."""
        input_text = "My name is Rahul and I need urgent help."
        masked = mask_person_names(input_text)
        self.assertIn("[PERSON]", masked)
        self.assertNotIn("Rahul", masked)
        self.assertEqual(masked, "My name is [PERSON] and I need urgent help.")

    def test_02_peer_relationship_context(self):
        """Verify 'My friend X' masks the peer name."""
        input_text = "My friend Aman keeps bothering me during study hours."
        masked = mask_person_names(input_text)
        self.assertIn("[PERSON]", masked)
        self.assertNotIn("Aman", masked)
        self.assertEqual(masked, "My friend [PERSON] keeps bothering me during study hours.")

    def test_03_department_and_action_context(self):
        """Verify 'X from CSE was threatened' / 'Seniors told Pooja to stay quiet'."""
        input_text1 = "Pooja from CSE was threatened in the lab."
        masked1 = mask_person_names(input_text1)
        self.assertIn("[PERSON]", masked1)
        self.assertNotIn("Pooja", masked1)

        input_text2 = "Seniors told Pooja to stay quiet."
        masked2 = mask_person_names(input_text2)
        self.assertIn("[PERSON]", masked2)
        self.assertNotIn("Pooja", masked2)

    def test_04_multiple_names_in_one_complaint(self):
        """Verify multiple student names are masked in a single complaint."""
        input_text = "Rahul and Rohit cornered my roommate Aman outside the hostel."
        masked = mask_person_names(input_text)
        self.assertNotIn("Rahul", masked)
        self.assertNotIn("Rohit", masked)
        self.assertNotIn("Aman", masked)
        self.assertEqual(masked.count("[PERSON]"), 3)

    def test_05_normal_capitalized_words_not_masked(self):
        """Verify normal openers, feelings, and roles are never falsely masked."""
        cases = [
            ("I am scared of what might happen.", "I am scared of what might happen."),
            ("Today was bad for everyone.", "Today was bad for everyone."),
            ("Senior students threatened me in the canteen.", "Senior students threatened me in the canteen."),
            ("Please help me solve this issue.", "Please help me solve this issue.")
        ]
        for input_text, expected in cases:
            masked = mask_person_names(input_text)
            self.assertEqual(masked, expected, f"Failed for: {input_text}")

    def test_06_hinglish_contextual_name(self):
        """Verify Hinglish sentence with names and context particles is masked."""
        input_text = "Bhai Rahul ne bola ki hostel mat aana warna maar padegi."
        masked = mask_person_names(input_text)
        self.assertIn("[PERSON]", masked)
        self.assertNotIn("Rahul", masked)

    def test_07_empty_input(self):
        """Verify empty string is handled safely."""
        self.assertEqual(mask_person_names(""), "")
        self.assertEqual(mask_person_names(None), "")

if __name__ == "__main__":
    unittest.main()
