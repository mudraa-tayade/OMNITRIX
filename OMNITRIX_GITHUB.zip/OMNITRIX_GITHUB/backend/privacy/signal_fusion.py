"""
OMNITRIX Privacy Multi-Signal Analysis Engine (Step 53).
Fuses privacy-safe linguistic risk signals, sarcasm/coded markers, ML feature summaries,
preliminary risk decisions, and optional ML analysis into a structured, explainable analysis payload.

ARCHITECTURAL & SAFETY GUARANTEES:
1. Does NOT accept or process raw complaint text or unmasked PII.
2. Does NOT calculate a second competing risk score; preserves risk_decision.py as sole source of truth.
3. Does NOT generate fake probabilities or fake confidence values (confidence remains None for rule_based).
4. Does NOT label rule-based analysis as ML-assisted when no ML prediction exists.
5. Returns privacy-safe boolean signal summaries, human-readable explanations, and count metadata.
"""

from typing import Dict, Any, List, Optional


def fuse_analysis(
    risk_signals: Optional[Dict[str, Any]] = None,
    sarcasm_signals: Optional[Dict[str, Any]] = None,
    feature_summary: Optional[Dict[str, Any]] = None,
    preliminary_risk: Optional[Dict[str, Any]] = None,
    ml_analysis: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Fuses privacy-safe signal dictionaries into a unified, explainable multi-signal analysis payload.

    Input Signals:
      - risk_signals (distress, threat, urgency, help-seeking, negative emotion counts & flags)
      - sarcasm_signals (sarcasm, coded language, indirect distress counts & flags)
      - feature_summary (aggregated feature primitives)
      - preliminary_risk (sole source of truth for risk_level & risk_score)
      - ml_analysis (optional ML predictions if available)

    Returns:
      {
          "risk_level": "low" | "medium" | "high" | "critical",
          "risk_score": int (0-100),
          "confidence": None,
          "signal_summary": {
              "distress": bool,
              "threat": bool,
              "urgency": bool,
              "help_seeking": bool,
              "negative_emotion": bool,
              "sarcasm": bool,
              "coded_distress": bool,
              "indirect_distress": bool
          },
          "analysis_mode": "rule_based" | "ml_assisted" | "hybrid",
          "ml_available": bool,
          "explanation": List[str],
          "signals_detected": int,
          "model_status": str
      }
    """
    rs = risk_signals if isinstance(risk_signals, dict) else {}
    ss = sarcasm_signals if isinstance(sarcasm_signals, dict) else {}
    fs = feature_summary if isinstance(feature_summary, dict) else {}
    pr = preliminary_risk if isinstance(preliminary_risk, dict) else {}
    ml = ml_analysis if isinstance(ml_analysis, dict) else {}

    # 1. Build boolean signal summary (using flags or counts > 0)
    distress = bool(rs.get("distress_keyword_count", fs.get("distress_keyword_count", 0)) > 0)
    
    threat = bool(
        rs.get("has_threat_language", False) or
        rs.get("threat_keyword_count", fs.get("threat_keyword_count", 0)) > 0 or
        fs.get("has_threat_language", False)
    )
    
    urgency = bool(
        rs.get("has_urgent_language", False) or
        rs.get("urgency_keyword_count", fs.get("urgency_keyword_count", 0)) > 0 or
        fs.get("has_urgent_language", False)
    )
    
    help_seeking = bool(
        rs.get("has_help_seeking", False) or
        rs.get("help_seeking_count", fs.get("help_seeking_count", 0)) > 0 or
        fs.get("has_help_seeking", False)
    )
    
    negative_emotion = bool(
        rs.get("negative_emotion_count", fs.get("negative_emotion_count", 0)) > 0
    )
    
    sarcasm = bool(
        ss.get("has_sarcasm_markers", False) or
        ss.get("sarcasm_marker_count", fs.get("sarcasm_marker_count", 0)) > 0 or
        fs.get("has_sarcasm_markers", False)
    )
    
    coded_distress = bool(
        ss.get("has_coded_language_markers", False) or
        ss.get("coded_language_marker_count", fs.get("coded_language_marker_count", 0)) > 0 or
        fs.get("has_coded_language_markers", False)
    )
    
    indirect_distress = bool(
        ss.get("has_indirect_distress", False) or
        ss.get("indirect_distress_marker_count", fs.get("indirect_distress_marker_count", 0)) > 0 or
        fs.get("has_indirect_distress", False)
    )

    signal_summary = {
        "distress": distress,
        "threat": threat,
        "urgency": urgency,
        "help_seeking": help_seeking,
        "negative_emotion": negative_emotion,
        "sarcasm": sarcasm,
        "coded_distress": coded_distress,
        "indirect_distress": indirect_distress
    }

    # 2. Count detected boolean signal categories
    signals_detected = sum(1 for active in signal_summary.values() if active)

    # 3. Safe human-readable explanations based on signal categories
    explanations: List[str] = []
    if threat:
        explanations.append("Threat-related indicators detected")
    if distress:
        explanations.append("Distress indicators detected")
    if urgency:
        explanations.append("Urgency indicators detected")
    if help_seeking:
        explanations.append("Help-seeking indicators detected")
    if negative_emotion:
        explanations.append("Negative emotion indicators detected")
    if sarcasm:
        explanations.append("Possible sarcasm or irony detected")
    if coded_distress:
        explanations.append("Possible coded or indirect distress detected")
    if indirect_distress:
        explanations.append("Indirect distress or withdrawal indicators detected")

    if not explanations:
        explanations.append("No elevated risk indicators detected")

    # 4. Preserve preliminary risk decision without recalculation
    raw_level = pr.get("risk_level")
    raw_score = pr.get("risk_score")

    valid_levels = {"low", "medium", "high", "critical"}
    if isinstance(raw_level, str) and raw_level.lower() in valid_levels and isinstance(raw_score, (int, float)):
        risk_level = raw_level.lower()
        risk_score = min(max(int(raw_score), 0), 100)
    else:
        risk_level = "low"
        risk_score = 0

    # 5. Handle ML state & analysis mode
    model_status = ml.get("model_status", "not_loaded")
    ml_available = (model_status == "available")

    if ml_available:
        analysis_mode = "ml_assisted"
        # If ML is available and provides score, confidence may be extracted if provided by model
        ml_score = ml.get("emotion", {}).get("score")
        confidence = float(ml_score) if isinstance(ml_score, (int, float)) else None
    else:
        analysis_mode = "rule_based"
        confidence = None

    return {
        "risk_level": risk_level,
        "risk_score": risk_score,
        "confidence": confidence,
        "signal_summary": signal_summary,
        "analysis_mode": analysis_mode,
        "ml_available": ml_available,
        "explanation": explanations,
        "signals_detected": signals_detected,
        "model_status": model_status
    }
