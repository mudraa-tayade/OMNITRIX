"""
OMNITRIX Complaint Content Encryption Module
Provides lightweight, zero-dependency, reversible encryption for student complaint narrative text.
Uses SHA-256 derived key stream with Base64 encoding based on OMNITRIX_COMPLAINT_ENCRYPTION_KEY.
"""

import os
import base64
import hashlib
from typing import Optional

ENCRYPTION_KEY_ENV = "OMNITRIX_COMPLAINT_ENCRYPTION_KEY"
DEFAULT_LOCAL_KEY = "omnitrix-local-complaint-encryption-key-2026"


def get_encryption_key() -> str:
    """Returns configured OMNITRIX_COMPLAINT_ENCRYPTION_KEY or default local dev fallback."""
    raw_key = os.environ.get(ENCRYPTION_KEY_ENV)
    if not raw_key or not raw_key.strip():
        return DEFAULT_LOCAL_KEY
    return raw_key.strip()


def encrypt_complaint_text(plaintext: str) -> str:
    """
    Encrypts raw complaint narrative text into a Base64-encoded encrypted string.
    
    Guarantees:
      - Uses SHA-256 key stream derived from OMNITRIX_COMPLAINT_ENCRYPTION_KEY.
      - Handles multi-line text, Unicode, and special characters losslessly.
      - Returns empty string if plaintext is empty or None.
    """
    if not plaintext or not isinstance(plaintext, str) or not plaintext.strip():
        return ""

    key = get_encryption_key()
    key_bytes = hashlib.sha256(key.encode("utf-8")).digest()
    text_bytes = plaintext.encode("utf-8")

    encrypted_bytes = bytearray(len(text_bytes))
    for i in range(len(text_bytes)):
        encrypted_bytes[i] = text_bytes[i] ^ key_bytes[i % len(key_bytes)]

    return base64.b64encode(encrypted_bytes).decode("utf-8")


def decrypt_complaint_text(ciphertext: str) -> Optional[str]:
    """
    Decrypts a Base64-encoded encrypted complaint text back into the original raw plaintext.
    
    Returns:
      - Decrypted original narrative string if valid.
      - None if ciphertext is missing, empty, or failed to decrypt.
    """
    if not ciphertext or not isinstance(ciphertext, str) or not ciphertext.strip():
        return None

    try:
        key = get_encryption_key()
        key_bytes = hashlib.sha256(key.encode("utf-8")).digest()
        encrypted_bytes = base64.b64decode(ciphertext.strip().encode("utf-8"))

        decrypted_bytes = bytearray(len(encrypted_bytes))
        for i in range(len(encrypted_bytes)):
            decrypted_bytes[i] = encrypted_bytes[i] ^ key_bytes[i % len(key_bytes)]

        return decrypted_bytes.decode("utf-8")
    except Exception:
        return None
