"""
OMNITRIX Privacy Transformation Engine - End-to-End Privacy Pipeline
Chains PII masking, contextual person-name masking, stylometry normalization,
safe representation extraction, privacy auditing, observable risk signals,
sarcasm/coded-language signals, and unified ML-ready feature aggregation
into a single privacy-preserving flow.
"""

from typing import Dict, Any
from .pii import mask_pii
from .names import mask_person_names
from .sanitizer import sanitize_text
from .representation import build_safe_representation
from .audit import build_privacy_audit
from .risk_signals import extract_risk_signals
from .sarcasm_signals import extract_sarcasm_signals
from .features import build_feature_summary
from .risk_decision import classify_preliminary_risk

def protect_text(text: str) -> Dict[str, Any]:
    """
    Complete privacy protection pipeline.
    
    Execution Order:
      1. RAW TEXT input
      2. PII MASKING (detect and replace phone, email, url, social, id, room, date)
      3. CONTEXTUAL PERSON-NAME MASKING (detect and replace student/person names)
      4. STYLE NORMALIZATION (de-shout, remove letter stretching, flatten whitespace, condense punctuation & emojis)
      5. SAFE REPRESENTATION BUILDING (compute non-identifying structural and linguistic signals from protected text)
      6. PRIVACY AUDIT REPORT (generate zero-knowledge transformation telemetry with counts only)
      7. OBSERVABLE RISK SIGNAL EXTRACTION (extract observable distress/threat/urgency indicators from protected text)
      8. SARCASM & CODED-LANGUAGE SIGNAL EXTRACTION (extract observable irony and indirect distress markers from protected text)
      9. UNIFIED ML-READY FEATURE AGGREGATION (combine safe signals into a single compact feature dictionary)
      10. PRELIMINARY RISK DECISION (classify risk level and score from privacy-safe signal dictionaries ONLY)
      11. PRIVACY-SAFE OUTPUT
      
    Returns:
      {
          "protected_text": str,
          "pii_masked": bool,
          "safe_representation": {...},
          "privacy_audit": {...},
          "risk_signals": {...},
          "sarcasm_signals": {...},
          "feature_summary": {...},
          "preliminary_risk": {
              "risk_level": str,
              "risk_score": int,
              "reasons": list
          }
      }
      
    Guarantees:
      - Raw original text is NEVER retained in the output, audit, or logs.
      - Audit, risk signals, sarcasm signals, feature summaries, and risk decisions contain strictly aggregate counts and boolean flags.
      - All representations, features, and risk decision functions operate exclusively on sanitized text / safe dicts.
      - Returns clean empty structure safely for empty or whitespace-only inputs.
    """
    if not text or not isinstance(text, str) or not text.strip():
        safe_rep = build_safe_representation("")
        risk_sig = extract_risk_signals("")
        sarcasm_sig = extract_sarcasm_signals("")
        feat_sum = build_feature_summary(safe_rep, risk_sig, sarcasm_sig)
        risk_dec = classify_preliminary_risk(
            risk_signals=risk_sig,
            sarcasm_signals=sarcasm_sig,
            feature_summary=feat_sum
        )
        return {
            "protected_text": "",
            "pii_masked": False,
            "safe_representation": safe_rep,
            "privacy_audit": build_privacy_audit(),
            "risk_signals": risk_sig,
            "sarcasm_signals": sarcasm_sig,
            "feature_summary": feat_sum,
            "preliminary_risk": risk_dec
        }

    # Step 1: Mask direct & indirect PII identifiers
    stage1_masked = mask_pii(text)

    phone_count = stage1_masked.count("[PHONE]")
    email_count = stage1_masked.count("[EMAIL]")
    url_count = stage1_masked.count("[URL]")
    social_count = stage1_masked.count("[SOCIAL_HANDLE]")
    student_id_count = stage1_masked.count("[STUDENT_ID]")
    room_count = stage1_masked.count("[ROOM]")
    date_count = stage1_masked.count("[DATE]")

    # Step 2: Mask contextual person names
    stage2_masked = mask_person_names(stage1_masked)
    person_name_count = stage2_masked.count("[PERSON]")

    total_pii_count = (
        phone_count + email_count + url_count + social_count +
        student_id_count + room_count + date_count + person_name_count
    )
    pii_detected = total_pii_count > 0

    # Step 3: Normalize stylistic idiosyncrasies & stylometry cues
    protected_text = sanitize_text(stage2_masked)
    style_normalized = (stage2_masked != protected_text)

    # Step 4: Build safe representation from protected text ONLY
    safe_representation = build_safe_representation(protected_text)

    # Step 5: Build zero-knowledge privacy audit
    privacy_audit = build_privacy_audit(
        phone_count=phone_count,
        email_count=email_count,
        url_count=url_count,
        student_id_count=student_id_count,
        room_count=room_count,
        date_count=date_count,
        person_name_count=person_name_count,
        style_normalized=style_normalized
    )

    # Step 6: Extract observable risk/distress signals from protected text ONLY
    risk_signals = extract_risk_signals(protected_text)

    # Step 7: Extract observable sarcasm and coded-language signals from protected text ONLY
    sarcasm_signals = extract_sarcasm_signals(protected_text)

    # Step 8: Build unified ML-ready feature summary from safe signal dictionaries ONLY
    feature_summary = build_feature_summary(
        safe_representation=safe_representation,
        risk_signals=risk_signals,
        sarcasm_signals=sarcasm_signals
    )

    # Step 9: Compute preliminary risk classification from safe signal dictionaries ONLY
    preliminary_risk = classify_preliminary_risk(
        risk_signals=risk_signals,
        sarcasm_signals=sarcasm_signals,
        feature_summary=feature_summary
    )

    return {
        "protected_text": protected_text,
        "pii_masked": pii_detected,
        "safe_representation": safe_representation,
        "privacy_audit": privacy_audit,
        "risk_signals": risk_signals,
        "sarcasm_signals": sarcasm_signals,
        "feature_summary": feature_summary,
        "preliminary_risk": preliminary_risk
    }
