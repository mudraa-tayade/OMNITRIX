"""
Unit tests for OMNITRIX In-Memory Rate Limiter (backend/rate_limit.py and backend/main.py).
Verifies sliding window enforcement, IP-based key isolation, HTTP 429 behavior,
privacy safety (zero IP persistence/logging/returning), and non-interference with other endpoints.
"""

import os
import shutil
import tempfile
import time
import sqlite3
import unittest
from unittest.mock import patch

from backend.rate_limit import (
    check_rate_limit,
    reset_rate_limiter,
    get_client_identifier,
    MAX_REQUESTS,
    WINDOW_SECONDS,
    HTTPException
)
from backend.main import (
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    modify_complaint_status,
    view_complaint_status_history,
    ComplaintRequest,
    ComplaintStatusUpdateRequest
)
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH,
    get_complaint_record
)
from backend.auth import ADMIN_API_KEY_ENV_VAR

TEST_ADMIN_KEY = "test-admin-secret-key-999"


class DummyRequest:
    def __init__(self, host: str = "192.168.1.100"):
        self.client = type("Client", (), {"host": host})()


class TestRateLimiter(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_rate_limit.db")
        init_database(self.test_db_path)
        self._orig_env = os.environ.get(ADMIN_API_KEY_ENV_VAR)
        os.environ[ADMIN_API_KEY_ENV_VAR] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_env is None:
            os.environ.pop(ADMIN_API_KEY_ENV_VAR, None)
        else:
            os.environ[ADMIN_API_KEY_ENV_VAR] = self._orig_env

    def test_01_first_request_is_allowed(self):
        """Test 1: First request from a client succeeds without raising HTTP 429."""
        req = DummyRequest("10.0.0.1")
        # Should not raise exception
        check_rate_limit(request=req)

    def test_02_requests_up_to_max_requests_allowed(self):
        """Test 2: Exactly MAX_REQUESTS (5) consecutive requests within window are allowed."""
        client_ip = "10.0.0.2"
        req = DummyRequest(client_ip)
        for _ in range(MAX_REQUESTS):
            check_rate_limit(request=req)

    def test_03_request_exceeding_max_requests_returns_429(self):
        """Test 3: The 6th request within window raises HTTP 429 with exact error detail."""
        client_ip = "10.0.0.3"
        req = DummyRequest(client_ip)
        for _ in range(MAX_REQUESTS):
            check_rate_limit(request=req)

        with self.assertRaises(HTTPException) as ctx:
            check_rate_limit(request=req)

        self.assertEqual(ctx.exception.status_code, 429)
        self.assertEqual(
            ctx.exception.detail,
            "Too many complaint submissions. Please try again later."
        )

    def test_04_request_allowed_after_window_expires(self):
        """Test 4: After WINDOW_SECONDS passes, rate limit resets for client."""
        client_ip = "10.0.0.4"
        base_time = 1000.0
        # Fill window at base_time
        for _ in range(MAX_REQUESTS):
            check_rate_limit(client_identifier=client_ip, now=base_time)

        # 6th request at base_time fails
        with self.assertRaises(HTTPException):
            check_rate_limit(client_identifier=client_ip, now=base_time)

        # Request at base_time + WINDOW_SECONDS + 1 succeeds
        future_time = base_time + WINDOW_SECONDS + 1.0
        check_rate_limit(client_identifier=client_ip, now=future_time)

    def test_05_old_timestamps_are_removed(self):
        """Test 5: Expired timestamps outside sliding window are purged from tracking list."""
        client_ip = "10.0.0.5"
        base_time = 2000.0
        check_rate_limit(client_identifier=client_ip, now=base_time)
        check_rate_limit(client_identifier=client_ip, now=base_time + 10)

        future_time = base_time + WINDOW_SECONDS + 5
        # Old timestamp (base_time) should be pruned, leaving 1 timestamp (base_time + 10)
        check_rate_limit(client_identifier=client_ip, now=future_time)

    def test_06_different_client_addresses_have_independent_limits(self):
        """Test 6: Client A reaching MAX_REQUESTS does not block Client B."""
        client_a = DummyRequest("10.0.0.6")
        client_b = DummyRequest("10.0.0.7")

        # Exceed limit for client A
        for _ in range(MAX_REQUESTS):
            check_rate_limit(request=client_a)

        with self.assertRaises(HTTPException):
            check_rate_limit(request=client_a)

        # Client B should still succeed
        check_rate_limit(request=client_b)

    def test_07_complaint_text_never_used_as_rate_limit_key(self):
        """Test 7: Submitting identical complaint texts from different clients does not trigger limit."""
        same_text = ComplaintRequest(text="Same complaint text submitted by different students.")

        # 5 requests from Client 1
        req1 = DummyRequest("192.168.1.1")
        for _ in range(MAX_REQUESTS):
            analyze_complaint(same_text, http_request=req1, db_path=self.test_db_path)

        # 6th request from Client 1 fails
        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(same_text, http_request=req1, db_path=self.test_db_path)
        self.assertEqual(ctx.exception.status_code, 429)

        # Client 2 submitting the SAME text succeeds
        req2 = DummyRequest("192.168.1.2")
        res2 = analyze_complaint(same_text, http_request=req2, db_path=self.test_db_path)
        res2_dict = res2 if isinstance(res2, dict) else res2.__dict__
        self.assertIn("complaint_id", res2_dict)

    def test_08_rate_limit_state_not_written_to_sqlite(self):
        """Test 8: Database tables contain zero rate-limiting state or client IP values."""
        client_ip = "192.168.1.99"
        req = DummyRequest(client_ip)
        analyze_complaint(ComplaintRequest(text="Test database check"), http_request=req, db_path=self.test_db_path)

        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM complaints;")
        complaint_rows = cursor.fetchall()
        cursor.execute("PRAGMA table_info(complaints);")
        columns = [col[1] for col in cursor.fetchall()]
        conn.close()

        self.assertNotIn("client_ip", columns)
        self.assertNotIn("ip_address", columns)
        self.assertNotIn(client_ip, str(complaint_rows))

    def test_09_client_ip_not_returned_in_api_response(self):
        """Test 9: API response dictionary does not contain client IP address."""
        client_ip = "192.168.1.88"
        req = DummyRequest(client_ip)
        res = analyze_complaint(ComplaintRequest(text="Response structure check"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn(client_ip, str(res_dict))
        self.assertNotIn("client_ip", str(res_dict))
        self.assertNotIn("ip", str(res_dict))

    def test_10_client_ip_not_in_complaint_records(self):
        """Test 10: Complaint records stored in memory or DB omit client IP."""
        client_ip = "192.168.1.77"
        req = DummyRequest(client_ip)
        res = analyze_complaint(ComplaintRequest(text="Record content check"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        for k in res_dict.keys():
            self.assertNotIn("ip", k.lower())

    def test_11_client_ip_not_logged(self):
        """Test 11: Rate limiting logic executes silently without printing or logging IP."""
        client_ip = "192.168.1.66"
        req = DummyRequest(client_ip)

        with patch("sys.stdout.write") as mock_stdout:
            check_rate_limit(request=req)
            mock_stdout.assert_not_called()

    def test_12_rate_limiter_applied_only_to_post_api_complaint(self):
        """Test 12: Rate limiter is enforced on POST /api/complaint."""
        req = DummyRequest("192.168.1.55")
        for _ in range(MAX_REQUESTS):
            analyze_complaint(ComplaintRequest(text="Filling window"), http_request=req, db_path=self.test_db_path)

        with self.assertRaises(HTTPException) as ctx:
            analyze_complaint(ComplaintRequest(text="Exceeding window"), http_request=req, db_path=self.test_db_path)
        self.assertEqual(ctx.exception.status_code, 429)

    def test_13_student_tracking_remains_unaffected(self):
        """Test 13: GET /api/complaint/{id} is NOT rate limited even if client exceeded submission limit."""
        client_ip = "192.168.1.44"
        req = DummyRequest(client_ip)

        # Create a complaint first
        res = analyze_complaint(ComplaintRequest(text="Trackable complaint"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        cid = res_dict["complaint_id"]

        # Fill rate limit window for POST /api/complaint
        for _ in range(MAX_REQUESTS - 1):
            analyze_complaint(ComplaintRequest(text="More complaints"), http_request=req, db_path=self.test_db_path)

        # POST /api/complaint now fails
        with self.assertRaises(HTTPException):
            analyze_complaint(ComplaintRequest(text="Blocked complaint"), http_request=req, db_path=self.test_db_path)

        # GET /api/complaint/{id} STILL SUCCEEDS 10+ times
        for _ in range(10):
            track_res = track_complaint(cid, db_path=self.test_db_path)
            track_dict = track_res if isinstance(track_res, dict) else track_res.__dict__
            self.assertEqual(track_dict["complaint_id"], cid)

    def test_14_admin_endpoints_remain_unaffected(self):
        """Test 14: GET and PATCH admin endpoints are NOT rate limited."""
        client_ip = "192.168.1.33"
        req = DummyRequest(client_ip)

        # Create complaint
        res = analyze_complaint(ComplaintRequest(text="Admin target complaint"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        cid = res_dict["complaint_id"]

        # Exceed rate limit for submission
        for _ in range(MAX_REQUESTS):
            try:
                analyze_complaint(ComplaintRequest(text="Spam"), http_request=req, db_path=self.test_db_path)
            except HTTPException:
                pass

        # Admin GET listing succeeds
        admin_list = list_admin_complaints(db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        self.assertGreater(len(admin_list), 0)

        # Admin PATCH status update succeeds
        status_update = modify_complaint_status(cid, ComplaintStatusUpdateRequest(status="in_review"), db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        status_dict = status_update if isinstance(status_update, dict) else status_update.__dict__
        self.assertEqual(status_dict["status"], "in_review")

        # Admin GET history succeeds
        history_res = view_complaint_status_history(cid, db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)
        hist_dict = history_res if isinstance(history_res, dict) else history_res.__dict__
        self.assertEqual(hist_dict["complaint_id"], cid)

    def test_15_existing_privacy_behavior_remains_unchanged(self):
        """Test 15: Successful complaint submission preserves PII masking and risk signals."""
        req = DummyRequest("192.168.1.22")
        res = analyze_complaint(ComplaintRequest(text="My name is Rohan Sharma and call 9876543210 urgently!"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        rec = get_complaint_record(res_dict["complaint_id"], db_path=self.test_db_path)

        self.assertTrue(rec["pii_masked"])
        self.assertNotIn("9876543210", rec["protected_text"])
        self.assertNotIn("Rohan Sharma", rec["protected_text"])
        self.assertIn("[PHONE]", rec["protected_text"])
        self.assertIn("[PERSON]", rec["protected_text"])

    def test_16_existing_api_response_structure_remains_unchanged(self):
        """Test 16: Return dict matches exact schema expected by callers."""
        req = DummyRequest("192.168.1.11")
        res = analyze_complaint(ComplaintRequest(text="Schema check"), http_request=req, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        expected_keys = {
            "complaint_id", "status", "preliminary_risk"
        }
        self.assertEqual(set(res_dict.keys()), expected_keys)

    def test_17_http_429_exact_message(self):
        """Test 17: HTTP 429 detail matches exact required string."""
        req = DummyRequest("192.168.1.5")
        for _ in range(MAX_REQUESTS):
            check_rate_limit(request=req)

        with self.assertRaises(HTTPException) as ctx:
            check_rate_limit(request=req)

        self.assertEqual(ctx.exception.status_code, 429)
        self.assertEqual(
            ctx.exception.detail,
            "Too many complaint submissions. Please try again later."
        )


if __name__ == "__main__":
    unittest.main()
