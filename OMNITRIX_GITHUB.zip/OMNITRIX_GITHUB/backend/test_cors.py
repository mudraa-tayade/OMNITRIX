"""
Unit tests for OMNITRIX Restricted CORS Middleware configuration (backend/main.py).
Verifies origin environment variable parsing, default local origins, disallowed origin rejection,
method/header restrictions, credentials prohibition, and non-bypassing of admin authentication.
"""

import os
import unittest
from unittest.mock import patch

from backend.main import (
    app,
    get_allowed_frontend_origins,
    DEFAULT_FRONTEND_ORIGINS,
    list_admin_complaints,
    HTTPException
)


class TestCORS(unittest.TestCase):
    def setUp(self):
        self._orig_env = os.environ.get("OMNITRIX_FRONTEND_ORIGINS")

    def tearDown(self):
        if self._orig_env is None:
            os.environ.pop("OMNITRIX_FRONTEND_ORIGINS", None)
        else:
            os.environ["OMNITRIX_FRONTEND_ORIGINS"] = self._orig_env

    def test_01_default_origins_used_when_env_unconfigured(self):
        """Test 1: When OMNITRIX_FRONTEND_ORIGINS is absent, defaults to localhost:3000 and localhost:5173."""
        os.environ.pop("OMNITRIX_FRONTEND_ORIGINS", None)
        origins = get_allowed_frontend_origins()
        self.assertEqual(origins, ["http://localhost:3000", "http://localhost:5173"])

    def test_02_default_origins_used_when_env_is_whitespace_or_empty(self):
        """Test 2: Empty or whitespace-only env variable falls back to local development defaults."""
        for empty_val in ["", "   ", " , ,  "]:
            os.environ["OMNITRIX_FRONTEND_ORIGINS"] = empty_val
            origins = get_allowed_frontend_origins()
            self.assertEqual(origins, ["http://localhost:3000", "http://localhost:5173"])

    def test_03_comma_separated_origins_parsed_and_trimmed(self):
        """Test 3: Comma-separated env value is parsed cleanly with trimmed whitespace."""
        os.environ["OMNITRIX_FRONTEND_ORIGINS"] = "http://localhost:3000, http://localhost:5173, https://app.omnitrix.edu "
        origins = get_allowed_frontend_origins()
        self.assertEqual(origins, [
            "http://localhost:3000",
            "http://localhost:5173",
            "https://app.omnitrix.edu"
        ])

    def test_04_empty_items_in_comma_separated_env_ignored(self):
        """Test 4: Consecutive or trailing commas are safely ignored."""
        os.environ["OMNITRIX_FRONTEND_ORIGINS"] = " https://portal.school.edu, , http://localhost:8080 , "
        origins = get_allowed_frontend_origins()
        self.assertEqual(origins, [
            "https://portal.school.edu",
            "http://localhost:8080"
        ])

    def test_05_wildcard_origin_is_not_used(self):
        """Test 5: Guarantees allow_origins is never '*'. """
        origins = get_allowed_frontend_origins()
        self.assertNotIn("*", origins)

    def test_06_disallowed_origin_is_not_in_allowed_origins(self):
        """Test 6: Arbitrary external origins are excluded from allowed origins."""
        os.environ["OMNITRIX_FRONTEND_ORIGINS"] = "http://localhost:3000,http://localhost:5173"
        origins = get_allowed_frontend_origins()
        self.assertNotIn("http://evil-tracker.com", origins)
        self.assertNotIn("http://malicious.org", origins)
        self.assertIn("http://localhost:3000", origins)

    def test_07_cors_middleware_registered_with_correct_parameters(self):
        """Test 7: Inspects app user_middleware registration for CORSMiddleware configuration."""
        self.assertTrue(hasattr(app, "user_middleware"))
        self.assertGreater(len(app.user_middleware), 0)

        cors_entry = None
        for mw in app.user_middleware:
            mw_cls = getattr(mw, "cls", None) or getattr(mw, "middleware_class", None)
            if mw_cls and "CORSMiddleware" in str(mw_cls):
                cors_entry = mw
                break

        self.assertIsNotNone(cors_entry, "CORSMiddleware must be added to app.user_middleware")
        opts = getattr(cors_entry, "options", None) or getattr(cors_entry, "kwargs", {})

        self.assertFalse(opts.get("allow_credentials"))
        self.assertEqual(sorted(opts.get("allow_methods", [])), sorted(["GET", "POST", "PATCH", "OPTIONS"]))
        self.assertEqual(sorted(opts.get("allow_headers", [])), sorted(["Content-Type", "X-Admin-API-Key"]))

    def test_08_cors_does_not_bypass_admin_authentication(self):
        """Test 8: Requests to admin endpoints still strictly require X-Admin-API-Key header."""
        with patch.dict(os.environ, {"OMNITRIX_ADMIN_API_KEY": "valid-secret-key-1234"}):
            with self.assertRaises(HTTPException) as ctx_missing:
                list_admin_complaints(x_admin_api_key=None)
            self.assertEqual(ctx_missing.exception.status_code, 401)

            with self.assertRaises(HTTPException) as ctx_wrong:
                list_admin_complaints(x_admin_api_key="wrong-key")
            self.assertEqual(ctx_wrong.exception.status_code, 403)


if __name__ == "__main__":
    unittest.main()
