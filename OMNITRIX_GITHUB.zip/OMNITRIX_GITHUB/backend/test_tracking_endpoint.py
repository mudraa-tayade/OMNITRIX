"""
Unit tests for FastAPI Complaint Tracking API Endpoint (GET /api/complaint/{complaint_id}).
Standard library unittest using isolated temporary SQLite databases.
Guarantees zero leakage of complaint content, PII, risk signals, or audit metadata, while returning preliminary_risk.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    analyze_complaint,
    track_complaint,
    ComplaintRequest,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH
)


class TestTrackingEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_tracking.db")
        init_database(self.test_db_path)

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def _create_sample_complaint(self, text: str) -> dict:
        req = ComplaintRequest(text=text)
        res = analyze_complaint(req, db_path=self.test_db_path)
        return res if isinstance(res, dict) else res.__dict__

    def test_01_existing_complaint_can_be_tracked(self):
        """Test 1: An existing complaint can be successfully tracked using complaint_id."""
        saved = self._create_sample_complaint("Help me in wing B seniors are threatening freshers.")
        complaint_id = saved["complaint_id"]

        tracking_res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = tracking_res if isinstance(tracking_res, dict) else tracking_res.__dict__

        self.assertIsInstance(res_dict, dict)
        self.assertEqual(res_dict["complaint_id"], complaint_id)

    def test_02_correct_complaint_id_is_returned(self):
        """Test 2: Returned tracking payload contains the exact queried complaint_id."""
        saved = self._create_sample_complaint("Hostel issue near mess hall.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict.get("complaint_id"), complaint_id)

    def test_03_correct_status_is_returned(self):
        """Test 3: Returned tracking payload contains status 'new'."""
        saved = self._create_sample_complaint("Distress report regarding seniors.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict.get("status"), "new")

    def test_04_preliminary_risk_is_returned_with_required_structure(self):
        """Test 4: Response contains preliminary_risk with risk_level, risk_score, and reasons."""
        saved = self._create_sample_complaint("Seniors are threatening me and demanding money.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("preliminary_risk", res_dict)
        risk = res_dict["preliminary_risk"]
        if not isinstance(risk, dict):
            risk = risk.__dict__

        self.assertIn("risk_level", risk)
        self.assertIn("risk_score", risk)
        self.assertIn("reasons", risk)

        self.assertIn(risk["risk_level"], ["low", "medium", "high", "critical"])
        self.assertIsInstance(risk["risk_score"], int)
        self.assertTrue(0 <= risk["risk_score"] <= 100)
        self.assertIsInstance(risk["reasons"], list)

    def test_05_reasons_are_generic_and_privacy_safe(self):
        """Test 5: Reasons in preliminary_risk do not contain raw text or PII."""
        saved = self._create_sample_complaint("My name is Rohan Sharma call 9876543210 urgently.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        risk = res_dict["preliminary_risk"]
        if not isinstance(risk, dict):
            risk = risk.__dict__

        for reason in risk["reasons"]:
            self.assertNotIn("Rohan Sharma", reason)
            self.assertNotIn("9876543210", reason)

    def test_06_protected_complaint_text_not_returned(self):
        """Test 6: Protected complaint text is NOT returned in tracking response."""
        saved = self._create_sample_complaint("Seniors in room 101 forced juniors to stay awake.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("protected_text", res_dict)
        self.assertNotIn("text", res_dict)
        self.assertNotIn("forced juniors", str(res_dict))

    def test_07_risk_signals_not_returned(self):
        """Test 7: Risk signals dictionary is NOT returned in tracking response."""
        saved = self._create_sample_complaint("Please help me urgently seniors are beating us!")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("risk_signals", res_dict)
        self.assertNotIn("has_threat_language", res_dict)
        self.assertNotIn("distress_keyword_count", res_dict)

    def test_08_privacy_audit_not_returned(self):
        """Test 8: Privacy audit metrics are NOT returned in tracking response."""
        saved = self._create_sample_complaint("Call 9876543210 or email test@college.edu.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("privacy_audit", res_dict)
        self.assertNotIn("pii_detected", res_dict)
        self.assertNotIn("phone_count", res_dict)

    def test_09_feature_summary_and_sarcasm_signals_not_returned(self):
        """Test 9: Feature summary vector and sarcasm signals are NOT returned in tracking response."""
        saved = self._create_sample_complaint("Such a welcoming college culture truly wonderful!")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertNotIn("feature_summary", res_dict)
        self.assertNotIn("safe_representation", res_dict)
        self.assertNotIn("sarcasm_signals", res_dict)

    def test_10_person_name_and_pii_not_returned(self):
        """Test 10: Person names, phone numbers, emails, room numbers mentioned in complaint are NOT returned."""
        saved = self._create_sample_complaint("My name is Rohit call 9876543210 email test@univ.edu room 404.")
        complaint_id = saved["complaint_id"]

        res = track_complaint(complaint_id, db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__
        res_dict_check = {k: v for k, v in res_dict.items() if k != "complaint_id"}
        s = str(res_dict_check)
        self.assertNotIn("Rohit", s)
        self.assertNotIn("9876543210", s)
        self.assertNotIn("test@univ.edu", s)
        self.assertNotIn("404", s)
        self.assertNotIn("[PERSON]", s)
        self.assertNotIn("[PHONE]", s)
        self.assertNotIn("[EMAIL]", s)
        self.assertNotIn("[ROOM]", s)

    def test_11_unknown_complaint_id_returns_404(self):
        """Test 11: Querying non-existent complaint_id raises HTTPException with status 404."""
        with self.assertRaises(HTTPException) as ctx:
            track_complaint("e5b8d234-5678-4321-9876-000000000000", db_path=self.test_db_path)

        self.assertEqual(ctx.exception.status_code, 404)
        self.assertEqual(ctx.exception.detail, "Complaint not found")

    def test_12_invalid_complaint_id_handled_safely(self):
        """Test 12: Empty or malformed IDs raise HTTP 404 without crashing or leaking details."""
        invalid_ids = ["", "   ", "invalid-id-xyz", None]
        for invalid_id in invalid_ids:
            with self.assertRaises(HTTPException) as ctx:
                track_complaint(invalid_id, db_path=self.test_db_path)  # type: ignore
            self.assertEqual(ctx.exception.status_code, 404)
            self.assertEqual(ctx.exception.detail, "Complaint not found")

    def test_13_two_different_complaint_ids_return_own_statuses_and_risks(self):
        """Test 13: Distinct complaint IDs return their respective individual tracking payloads."""
        saved1 = self._create_sample_complaint("First issue in Block A.")
        saved2 = self._create_sample_complaint("Seniors are threatening me urgently with violence.")

        res1 = track_complaint(saved1["complaint_id"], db_path=self.test_db_path)
        res2 = track_complaint(saved2["complaint_id"], db_path=self.test_db_path)

        dict1 = res1 if isinstance(res1, dict) else res1.__dict__
        dict2 = res2 if isinstance(res2, dict) else res2.__dict__

        self.assertEqual(dict1["complaint_id"], saved1["complaint_id"])
        self.assertEqual(dict2["complaint_id"], saved2["complaint_id"])
        self.assertNotEqual(dict1["complaint_id"], dict2["complaint_id"])
        self.assertEqual(dict1["status"], "new")
        self.assertEqual(dict2["status"], "new")
        self.assertIn("preliminary_risk", dict1)
        self.assertIn("preliminary_risk", dict2)

    def test_14_endpoint_does_not_calculate_risk_independently(self):
        """Test 14: Verifies that track_complaint relies on get_complaint_record rather than recalculating risk."""
        mock_risk = {"risk_level": "high", "risk_score": 75, "reasons": ["Urgent threat language detected"]}
        with patch("backend.main.get_complaint_record", wraps=lambda cid, db_path=None: {"complaint_id": cid, "status": "in_review", "preliminary_risk": mock_risk}) as mock_get:
            with patch("backend.privacy.risk_decision.classify_preliminary_risk") as mock_classify:
                res = track_complaint("mocked-uuid-1234", db_path=self.test_db_path)
                res_dict = res if isinstance(res, dict) else res.__dict__

                mock_get.assert_called_once_with("mocked-uuid-1234", db_path=self.test_db_path)
                mock_classify.assert_not_called()
                self.assertEqual(res_dict["complaint_id"], "mocked-uuid-1234")
                self.assertEqual(res_dict["status"], "in_review")
                risk = res_dict["preliminary_risk"]
                if not isinstance(risk, dict):
                    risk = risk.__dict__
                self.assertEqual(risk["risk_level"], "high")
                self.assertEqual(risk["risk_score"], 75)

    def test_15_tests_use_temporary_database(self):
        """Test 15: Verifies tests execute against temporary database without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
