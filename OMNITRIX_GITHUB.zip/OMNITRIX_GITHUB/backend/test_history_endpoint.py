"""
Unit tests for FastAPI Admin Complaint Status History API Endpoint
(GET /api/admin/complaints/{complaint_id}/history).
Standard library unittest using isolated temporary SQLite databases.
Guarantees strict privacy non-exposure, inclusion of preliminary_risk, and read-only delegation to persistence layer.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    analyze_complaint,
    modify_complaint_status,
    view_complaint_status_history,
    ComplaintRequest,
    ComplaintStatusUpdateRequest,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    get_status_history,
    DEFAULT_DB_PATH
)

TEST_ADMIN_KEY = "test-admin-secret-key-98765"


class TestHistoryEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_api_history.db")
        init_database(self.test_db_path)
        self._orig_key = os.environ.get("OMNITRIX_ADMIN_API_KEY")
        os.environ["OMNITRIX_ADMIN_API_KEY"] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_key is None:
            os.environ.pop("OMNITRIX_ADMIN_API_KEY", None)
        else:
            os.environ["OMNITRIX_ADMIN_API_KEY"] = self._orig_key

    def _create_sample_complaint(self, text: str) -> dict:
        req = ComplaintRequest(text=text)
        res = analyze_complaint(req, db_path=self.test_db_path)
        return res if isinstance(res, dict) else res.__dict__

    def _view_history(self, complaint_id: str, key=TEST_ADMIN_KEY):
        return view_complaint_status_history(complaint_id, db_path=self.test_db_path, x_admin_api_key=key)

    def _modify_status(self, complaint_id: str, status: str):
        req = ComplaintStatusUpdateRequest(status=status)
        return modify_complaint_status(complaint_id, req, db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)

    def test_01_existing_complaint_with_no_history_returns_200(self):
        """Test 1: Existing complaint with no status changes returns HTTP 200 with empty history []."""
        saved = self._create_sample_complaint("Fresh complaint in hostel block B.")
        complaint_id = saved["complaint_id"]

        res = self._view_history(complaint_id)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict["complaint_id"], complaint_id)
        self.assertEqual(res_dict["history"], [])

    def test_02_auth_missing_key_returns_401(self):
        """Test 2: Missing admin API key returns HTTP 401."""
        with self.assertRaises(HTTPException) as ctx:
            self._view_history("some-cid", key=None)
        self.assertEqual(ctx.exception.status_code, 401)

    def test_03_auth_wrong_key_returns_403(self):
        """Test 3: Incorrect admin API key returns HTTP 403."""
        with self.assertRaises(HTTPException) as ctx:
            self._view_history("some-cid", key="wrong-key")
        self.assertEqual(ctx.exception.status_code, 403)

    def test_04_preliminary_risk_is_returned_with_correct_structure(self):
        """Test 4: History response contains preliminary_risk with risk_level, risk_score, and reasons."""
        saved = self._create_sample_complaint("Seniors threatened to beat me urgently.")
        complaint_id = saved["complaint_id"]

        res = self._view_history(complaint_id)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertIn("preliminary_risk", res_dict)
        risk = res_dict["preliminary_risk"]
        if not isinstance(risk, dict):
            risk = risk.__dict__

        self.assertIn("risk_level", risk)
        self.assertIn("risk_score", risk)
        self.assertIn("reasons", risk)

        self.assertIn(risk["risk_level"], ["low", "medium", "high", "critical"])
        self.assertIsInstance(risk["risk_score"], int)
        self.assertTrue(0 <= risk["risk_score"] <= 100)
        self.assertIsInstance(risk["reasons"], list)

    def test_05_preliminary_risk_remains_unchanged_after_status_updates(self):
        """Test 5: Status updates do not alter preliminary_risk in history responses."""
        saved = self._create_sample_complaint("Threat language in room 101 urgently.")
        cid = saved["complaint_id"]
        initial_risk = saved["preliminary_risk"]

        self._modify_status(cid, "in_review")
        self._modify_status(cid, "resolved")

        res = self._view_history(cid)
        res_dict = res if isinstance(res, dict) else res.__dict__
        risk = res_dict["preliminary_risk"]
        if not isinstance(risk, dict):
            risk = risk.__dict__

        self.assertEqual(risk["risk_level"], initial_risk["risk_level"])
        self.assertEqual(risk["risk_score"], initial_risk["risk_score"])
        self.assertEqual(risk["reasons"], initial_risk["reasons"])

    def test_06_endpoint_does_not_recalculate_risk(self):
        """Test 6: Verifies view_complaint_status_history relies on database record and does not call classify_preliminary_risk."""
        mock_risk = {"risk_level": "high", "risk_score": 85, "reasons": ["Urgent threat language"]}
        with patch("backend.main.get_complaint_record", wraps=lambda cid, db_path=None: {"complaint_id": cid, "preliminary_risk": mock_risk}) as mock_rec, \
             patch("backend.main.get_status_history", wraps=lambda cid, db_path=None: []) as mock_hist, \
             patch("backend.privacy.risk_decision.classify_preliminary_risk") as mock_classify:

            res = self._view_history("mock-cid-99")
            res_dict = res if isinstance(res, dict) else res.__dict__

            mock_rec.assert_called_once_with("mock-cid-99", db_path=self.test_db_path)
            mock_hist.assert_called_once_with("mock-cid-99", db_path=self.test_db_path)
            mock_classify.assert_not_called()
            self.assertEqual(res_dict["preliminary_risk"], mock_risk)

    def test_07_existing_history_entries_remain_unchanged(self):
        """Test 7: History items preserve history_id, previous_status, new_status, and changed_at fields."""
        saved = self._create_sample_complaint("Sample complaint for history fields check.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_dict = res if isinstance(res, dict) else res.__dict__
        hist = res_dict["history"]

        self.assertEqual(len(hist), 1)
        item = hist[0]
        self.assertIn("history_id", item)
        self.assertIsInstance(item["history_id"], int)
        self.assertEqual(item["previous_status"], "new")
        self.assertEqual(item["new_status"], "in_review")
        self.assertIn("changed_at", item)

    def test_08_multiple_history_entries_returned_in_order(self):
        """Test 8: Multiple transitions return history items in chronological/database order."""
        saved = self._create_sample_complaint("Multiple status transitions test.")
        cid = saved["complaint_id"]

        self._modify_status(cid, "in_review")
        self._modify_status(cid, "resolved")
        self._modify_status(cid, "closed")

        res = self._view_history(cid)
        res_dict = res if isinstance(res, dict) else res.__dict__
        hist = res_dict["history"]

        self.assertEqual(len(hist), 3)
        self.assertEqual(hist[0]["previous_status"], "new")
        self.assertEqual(hist[0]["new_status"], "in_review")
        self.assertEqual(hist[1]["previous_status"], "in_review")
        self.assertEqual(hist[1]["new_status"], "resolved")
        self.assertEqual(hist[2]["previous_status"], "resolved")
        self.assertEqual(hist[2]["new_status"], "closed")

    def test_09_unknown_complaint_id_returns_404(self):
        """Test 9: Querying non-existent complaint_id returns HTTP 404 'Complaint not found'."""
        with self.assertRaises(HTTPException) as ctx:
            self._view_history("unknown-uuid-00000")

        self.assertEqual(ctx.exception.status_code, 404)
        self.assertEqual(ctx.exception.detail, "Complaint not found")

    def test_10_raw_complaint_text_never_returned(self):
        """Test 10: Raw complaint text is never present in history response."""
        secret = "VERY_SECRET_RAW_COMPLAINT_TEXT_12345"
        saved = self._create_sample_complaint(secret)
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("raw_text", res_str)
        self.assertNotIn("original_text", res_str)
        self.assertNotIn(secret, res_str)

    def test_11_protected_text_never_returned(self):
        """Test 11: Protected text is never present in history response."""
        saved = self._create_sample_complaint("Seniors forced juniors to stay up all night.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("protected_text", res_str)
        self.assertNotIn("forced juniors", res_str)

    def test_12_privacy_audit_never_returned(self):
        """Test 12: Privacy audit metrics are never present in history response."""
        saved = self._create_sample_complaint("Call 9876543210 or email test@college.edu in room 101.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("privacy_audit", res_str)
        self.assertNotIn("pii_detected", res_str)

    def test_13_risk_signals_never_returned(self):
        """Test 13: Risk signals dictionary is never present in history response."""
        saved = self._create_sample_complaint("Urgent threat and beating report.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("risk_signals", res_str)
        self.assertNotIn("has_threat_language", res_str)

    def test_14_sarcasm_signals_never_returned(self):
        """Test 14: Sarcasm signals dictionary is never present in history response."""
        saved = self._create_sample_complaint("Such a welcoming department!")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("sarcasm_signals", res_str)
        self.assertNotIn("has_sarcasm_markers", res_str)

    def test_15_feature_summary_never_returned(self):
        """Test 15: Feature summary vector is never present in history response."""
        saved = self._create_sample_complaint("Testing feature_summary isolation.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn("feature_summary", res_str)
        self.assertNotIn("safe_representation", res_str)

    def test_16_no_identity_information_returned(self):
        """Test 16: Names, phone numbers, emails, room numbers are never present in history response."""
        raw_phone = "9876543210"
        raw_email = "victim@univ.edu.in"
        raw_name = "Amit Kumar"
        raw_room = "777888999"
        saved = self._create_sample_complaint(f"I am {raw_name}, phone {raw_phone}, email {raw_email}, room {raw_room}.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        res = self._view_history(cid)
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn(raw_phone, res_str)
        self.assertNotIn(raw_email, res_str)
        self.assertNotIn(raw_name, res_str)
        self.assertNotIn(raw_room, res_str)

    def test_17_endpoint_is_read_only(self):
        """Test 17: Querying status history does not mutate database or history table."""
        saved = self._create_sample_complaint("Read-only test.")
        cid = saved["complaint_id"]
        self._modify_status(cid, "in_review")

        hist_before = get_status_history(cid, db_path=self.test_db_path)
        self._view_history(cid)
        hist_after = get_status_history(cid, db_path=self.test_db_path)

        self.assertEqual(hist_before, hist_after)

    def test_18_temporary_database_used(self):
        """Test 18: Verifies tests execute against temporary test DB without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
