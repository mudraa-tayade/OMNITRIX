"""
Unit tests for OMNITRIX Unified Complaint Analysis Service (backend/privacy/analysis_service.py).
Verifies:
  - End-to-end processing for English, Hinglish, and mixed-language complaints.
  - PII masking (phone, email, URL) and contextual person-name masking.
  - Sarcasm, coded/indirect distress, threat, distress, and urgency signal extraction.
  - Safe error handling for empty strings and None inputs without crashing.
  - Complete exclusion of raw input text, matched phrases, and forbidden identity attributes.
  - Presence and consistency of preliminary_risk output.
"""

import unittest
from backend.privacy import analyze_complaint
from backend.privacy.analysis_service import FORBIDDEN_FIELDS


class TestAnalysisService(unittest.TestCase):

    def test_01_normal_english_complaint(self):
        """Test 1: Processes normal English complaint and returns structured privacy-safe result."""
        text = "Seniors forced us to stay up all night near the hostel gate."
        res = analyze_complaint(text)

        self.assertIn("protected_text", res)
        self.assertIn("pii_masked", res)
        self.assertIn("safe_representation", res)
        self.assertIn("privacy_audit", res)
        self.assertIn("risk_signals", res)
        self.assertIn("sarcasm_signals", res)
        self.assertIn("feature_summary", res)
        self.assertIn("preliminary_risk", res)

        self.assertEqual(res["safe_representation"]["language_hint"], "english")
        self.assertIsInstance(res["preliminary_risk"]["risk_score"], int)
        self.assertIn(res["preliminary_risk"]["risk_level"], {"low", "medium", "high", "critical"})

    def test_02_hinglish_complaint(self):
        """Test 2: Processes Hinglish complaint and identifies hinglish language hint."""
        text = "Seniors hostel mein bohot pareshan kar rahe hain aur ragging kar rahe hain."
        res = analyze_complaint(text)

        self.assertEqual(res["safe_representation"]["language_hint"], "hinglish")
        self.assertIn("preliminary_risk", res)
        self.assertIsInstance(res["preliminary_risk"]["reasons"], list)

    def test_03_mixed_language_complaint(self):
        """Test 3: Processes mixed English and Hinglish complaint text."""
        text = "Need help urgent seniors threatening me hostel room mein urgently."
        res = analyze_complaint(text)

        self.assertTrue(res["risk_signals"]["has_threat_language"])
        self.assertTrue(res["risk_signals"]["has_urgent_language"])
        self.assertGreater(res["preliminary_risk"]["risk_score"], 0)

    def test_04_complaint_containing_phone_email_url(self):
        """Test 4: Masks phone numbers, emails, and URLs with [TAG] and updates audit flags."""
        text = "Contact Rahul at 9876543210 or email test@college.edu at http://ragging.edu"
        res = analyze_complaint(text)

        self.assertTrue(res["pii_masked"])
        self.assertNotIn("9876543210", res["protected_text"])
        self.assertNotIn("test@college.edu", res["protected_text"])
        self.assertNotIn("http://ragging.edu", res["protected_text"])
        self.assertIn("[PHONE]", res["protected_text"])
        self.assertIn("[EMAIL]", res["protected_text"])
        self.assertIn("[URL]", res["protected_text"])
        self.assertTrue(res["privacy_audit"]["pii_detected"])

    def test_05_complaint_containing_contextual_person_name(self):
        """Test 5: Contextual student/peer names are masked with [PERSON]."""
        text = "Rohan and Amit forced freshers to clean rooms."
        res = analyze_complaint(text)

        self.assertNotIn("Rohan", res["protected_text"])
        self.assertNotIn("Amit", res["protected_text"])
        self.assertIn("[PERSON]", res["protected_text"])
        self.assertTrue(res["privacy_audit"]["name_detected"])

    def test_06_sarcasm_detection(self):
        """Test 6: Identifies sarcasm markers and indirect expressions in text."""
        text = "Oh great, seniors are so wonderful waking us up at 3 AM every night."
        res = analyze_complaint(text)

        self.assertTrue(res["sarcasm_signals"]["has_sarcasm_markers"])
        self.assertGreater(res["sarcasm_signals"]["sarcasm_marker_count"], 0)

    def test_07_coded_indirect_distress(self):
        """Test 7: Identifies coded language and indirect distress markers."""
        text = "I don't know what to do, please leave me alone."
        res = analyze_complaint(text)

        self.assertTrue(res["sarcasm_signals"]["has_indirect_distress"])
        self.assertGreater(res["sarcasm_signals"]["indirect_distress_marker_count"], 0)

    def test_08_threat_distress_urgency_signals(self):
        """Test 8: Detects threat, distress, urgency, and help-seeking indicators."""
        text = "Threatening to beat me up in room 101! Please help immediately urgent!"
        res = analyze_complaint(text)

        self.assertTrue(res["risk_signals"]["has_threat_language"])
        self.assertTrue(res["risk_signals"]["has_help_seeking"])
        self.assertTrue(res["risk_signals"]["has_urgent_language"])
        self.assertEqual(res["preliminary_risk"]["risk_level"], "critical")

    def test_09_empty_input(self):
        """Test 9: Handles empty string and whitespace-only inputs safely without crashing."""
        for empty_text in ["", "   ", "\t\n"]:
            res = analyze_complaint(empty_text)
            self.assertEqual(res["protected_text"], "")
            self.assertFalse(res["pii_masked"])
            self.assertEqual(res["preliminary_risk"]["risk_level"], "low")
            self.assertEqual(res["preliminary_risk"]["risk_score"], 0)

    def test_10_none_input(self):
        """Test 10: Handles None input safely without crashing."""
        res = analyze_complaint(None)
        self.assertEqual(res["protected_text"], "")
        self.assertFalse(res["pii_masked"])
        self.assertEqual(res["preliminary_risk"]["risk_level"], "low")
        self.assertEqual(res["preliminary_risk"]["risk_score"], 0)

    def test_11_raw_input_is_absent_from_returned_structure(self):
        """Test 11: Raw complaint text input is never retained in returned dictionary keys."""
        raw_sensitive_input = "Secret complaint raw input text with confidential details"
        res = analyze_complaint(raw_sensitive_input)

        self.assertNotIn("raw_text", res)
        self.assertNotIn("original_text", res)
        self.assertNotIn("text", res)
        self.assertNotIn("input", res)

    def test_12_no_forbidden_identity_fields_introduced(self):
        """Test 12: Ensures no forbidden identity keys or matched phrase dumps exist in analysis result."""
        text = "Senior Suresh in Room 402 email suresh@college.edu phone 9123456789"
        res = analyze_complaint(text)

        for field in FORBIDDEN_FIELDS:
            self.assertNotIn(field, res)

    def test_13_preliminary_risk_is_present_and_consistent(self):
        """Test 13: preliminary_risk matches existing rule-based risk classification engine output."""
        text = "Emergency! Help me right now!"
        res = analyze_complaint(text)

        self.assertIn("preliminary_risk", res)
        risk = res["preliminary_risk"]
        self.assertIn("risk_level", risk)
        self.assertIn("risk_score", risk)
        self.assertIn("reasons", risk)
        self.assertIsInstance(risk["reasons"], list)
        self.assertGreaterEqual(risk["risk_score"], 0)
        self.assertLessEqual(risk["risk_score"], 100)


if __name__ == "__main__":
    unittest.main()
