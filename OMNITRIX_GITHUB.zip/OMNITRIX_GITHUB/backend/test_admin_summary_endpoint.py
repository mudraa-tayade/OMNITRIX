"""
Unit tests for FastAPI Admin Complaint Summary API Endpoint (GET /api/admin/summary).
Standard library unittest using isolated temporary SQLite databases.
Guarantees privacy-safe aggregate statistics with zero exposure of individual complaint IDs or content.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    analyze_complaint,
    modify_complaint_status,
    get_admin_summary,
    ComplaintRequest,
    ComplaintStatusUpdateRequest,
    HTTPException
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH
)

TEST_ADMIN_KEY = "test-admin-secret-key-98765"


class TestAdminSummaryEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_admin_summary.db")
        init_database(self.test_db_path)
        self._orig_key = os.environ.get("OMNITRIX_ADMIN_API_KEY")
        os.environ["OMNITRIX_ADMIN_API_KEY"] = TEST_ADMIN_KEY

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)
        if self._orig_key is None:
            os.environ.pop("OMNITRIX_ADMIN_API_KEY", None)
        else:
            os.environ["OMNITRIX_ADMIN_API_KEY"] = self._orig_key

    def _create_sample_complaint(self, text: str) -> dict:
        req = ComplaintRequest(text=text)
        res = analyze_complaint(req, db_path=self.test_db_path)
        return res if isinstance(res, dict) else res.__dict__

    def _modify_status(self, complaint_id: str, status: str):
        req = ComplaintStatusUpdateRequest(status=status)
        return modify_complaint_status(complaint_id, req, db_path=self.test_db_path, x_admin_api_key=TEST_ADMIN_KEY)

    def _get_summary(self, key=TEST_ADMIN_KEY):
        return get_admin_summary(db_path=self.test_db_path, x_admin_api_key=key)

    def test_01_auth_missing_key_returns_401(self):
        """Test 1: Missing X-Admin-API-Key header raises HTTP 401."""
        with self.assertRaises(HTTPException) as ctx:
            self._get_summary(key=None)
        self.assertEqual(ctx.exception.status_code, 401)

    def test_02_auth_wrong_key_returns_403(self):
        """Test 2: Incorrect X-Admin-API-Key header raises HTTP 403."""
        with self.assertRaises(HTTPException) as ctx:
            self._get_summary(key="wrong-admin-key")
        self.assertEqual(ctx.exception.status_code, 403)

    def test_03_auth_correct_key_returns_200(self):
        """Test 3: Correct X-Admin-API-Key header returns HTTP 200 summary response."""
        res = self._get_summary(key=TEST_ADMIN_KEY)
        res_dict = res if isinstance(res, dict) else res.__dict__
        self.assertIn("total_complaints", res_dict)

    def test_04_empty_database_returns_all_zero_counts(self):
        """Test 4: Empty database returns total_complaints = 0 and zero status/risk counts."""
        res = self._get_summary()
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict["total_complaints"], 0)
        self.assertEqual(res_dict["status_counts"], {
            "new": 0,
            "in_review": 0,
            "resolved": 0,
            "closed": 0
        })
        self.assertEqual(res_dict["risk_counts"], {
            "low": 0,
            "medium": 0,
            "high": 0,
            "critical": 0
        })

    def test_05_total_complaints_count_is_accurate(self):
        """Test 5: Creating multiple complaints reflects exact total_complaints count."""
        self._create_sample_complaint("Complaint 1: library issue.")
        self._create_sample_complaint("Complaint 2: hostel issue.")
        self._create_sample_complaint("Complaint 3: canteen issue.")

        res = self._get_summary()
        res_dict = res if isinstance(res, dict) else res.__dict__
        self.assertEqual(res_dict["total_complaints"], 3)

    def test_06_status_counts_are_accurate(self):
        """Test 6: Updating complaint statuses reflects accurate status_counts."""
        c1 = self._create_sample_complaint("Complaint 1.")
        c2 = self._create_sample_complaint("Complaint 2.")
        c3 = self._create_sample_complaint("Complaint 3.")
        c4 = self._create_sample_complaint("Complaint 4.")

        self._modify_status(c2["complaint_id"], "in_review")
        self._modify_status(c3["complaint_id"], "resolved")
        self._modify_status(c4["complaint_id"], "closed")

        res = self._get_summary()
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict["status_counts"]["new"], 1)
        self.assertEqual(res_dict["status_counts"]["in_review"], 1)
        self.assertEqual(res_dict["status_counts"]["resolved"], 1)
        self.assertEqual(res_dict["status_counts"]["closed"], 1)

    def test_07_risk_counts_are_accurate(self):
        """Test 7: Complaints with varied preliminary risks reflect in risk_counts."""
        self._create_sample_complaint("General library complaint.") # low
        self._create_sample_complaint("Seniors are threatening to beat me urgently.") # high/critical

        res = self._get_summary()
        res_dict = res if isinstance(res, dict) else res.__dict__
        risk_counts = res_dict["risk_counts"]

        total_risk = sum(risk_counts.values())
        self.assertEqual(total_risk, 2)
        self.assertGreater(risk_counts["low"] + risk_counts["medium"] + risk_counts["high"] + risk_counts["critical"], 0)

    def test_08_endpoint_does_not_recalculate_risk(self):
        """Test 8: Verifies summary relies on persisted records and does not call classify_preliminary_risk."""
        mock_records = [
            {"status": "new", "preliminary_risk": {"risk_level": "medium", "risk_score": 50, "reasons": []}},
            {"status": "in_review", "preliminary_risk": {"risk_level": "high", "risk_score": 75, "reasons": []}}
        ]
        with patch("backend.main.get_all_complaint_records", wraps=lambda db_path=None: mock_records) as mock_get_all, \
             patch("backend.privacy.risk_decision.classify_preliminary_risk") as mock_classify:

            res = self._get_summary()
            res_dict = res if isinstance(res, dict) else res.__dict__

            mock_get_all.assert_called_once_with(db_path=self.test_db_path)
            mock_classify.assert_not_called()
            self.assertEqual(res_dict["total_complaints"], 2)
            self.assertEqual(res_dict["status_counts"]["new"], 1)
            self.assertEqual(res_dict["status_counts"]["in_review"], 1)
            self.assertEqual(res_dict["risk_counts"]["medium"], 1)
            self.assertEqual(res_dict["risk_counts"]["high"], 1)

    def test_09_response_contains_only_aggregate_fields(self):
        """Test 9: Response payload contains strictly total_complaints, status_counts, and risk_counts."""
        res = self._get_summary()
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(set(res_dict.keys()), {"total_complaints", "status_counts", "risk_counts"})

    def test_10_no_complaint_ids_or_content_exposed(self):
        """Test 10: Summary response string contains zero complaint IDs, raw text, or PII."""
        secret_text = "SECRET_COMPLAINT_TEXT_IN_SUMMARY_TEST_99"
        c = self._create_sample_complaint(secret_text)

        res = self._get_summary()
        res_str = str(res if isinstance(res, dict) else res.__dict__)

        self.assertNotIn(c["complaint_id"], res_str)
        self.assertNotIn(secret_text, res_str)
        self.assertNotIn("raw_text", res_str)
        self.assertNotIn("protected_text", res_str)
        self.assertNotIn("privacy_audit", res_str)

    def test_11_temporary_database_used(self):
        """Test 11: Verifies tests execute against temporary DB without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
