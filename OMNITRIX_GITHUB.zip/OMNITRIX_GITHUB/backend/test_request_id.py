"""
Unit tests for OMNITRIX Privacy-Safe Request ID Middleware and Handler (backend/main.py).
Standard library unittest verifying that every HTTP response includes a server-generated UUID4 X-Request-ID header,
ignores client-supplied X-Request-ID headers, omits request ID from JSON bodies and database records,
and attaches X-Request-ID to 200, 400, 401, 403, 404, 500, and 503 responses.
"""

import os
import uuid
import asyncio
import tempfile
import shutil
import unittest
from unittest.mock import patch

from backend.main import (
    app,
    add_request_id_header,
    global_exception_handler,
    health_check,
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    ComplaintRequest,
    HTTPException,
    JSONResponse,
    Request
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    get_all_complaint_records,
    get_complaint_record
)


class TestRequestId(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_request_id.db")
        init_database(self.test_db_path)
        self.dummy_req = Request("127.0.0.1")

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def _run(self, coro):
        return asyncio.run(coro)

    def test_01_normal_request_receives_x_request_id_header(self):
        """Test 1: Normal 200 request receives X-Request-ID header via middleware."""
        async def mock_call_next(req):
            return JSONResponse({"status": "ok"}, status_code=200)

        res = self._run(add_request_id_header(self.dummy_req, mock_call_next))
        self.assertEqual(res.status_code, 200)
        self.assertIn("X-Request-ID", res.headers)

    def test_02_request_id_is_valid_uuid4(self):
        """Test 2: X-Request-ID is a valid UUID4 string."""
        async def mock_call_next(req):
            return JSONResponse({"status": "ok"}, status_code=200)

        res = self._run(add_request_id_header(self.dummy_req, mock_call_next))
        req_id = res.headers.get("X-Request-ID")
        self.assertIsNotNone(req_id)
        
        parsed_uuid = uuid.UUID(req_id, version=4)
        self.assertEqual(str(parsed_uuid), req_id)

    def test_03_two_requests_receive_different_request_ids(self):
        """Test 3: Consecutive requests receive distinct UUID4 request IDs."""
        async def mock_call_next(req):
            return JSONResponse({"status": "ok"}, status_code=200)

        res1 = self._run(add_request_id_header(self.dummy_req, mock_call_next))
        res2 = self._run(add_request_id_header(self.dummy_req, mock_call_next))

        id1 = res1.headers.get("X-Request-ID")
        id2 = res2.headers.get("X-Request-ID")

        self.assertIsNotNone(id1)
        self.assertIsNotNone(id2)
        self.assertNotEqual(id1, id2)

    def test_04_client_supplied_x_request_id_is_ignored_and_replaced(self):
        """Test 4: Client-supplied X-Request-ID header is ignored and replaced with a fresh server UUID4."""
        custom_client_id = "custom-client-supplied-id-999"
        req_with_client_header = Request("127.0.0.1")
        setattr(req_with_client_header, "headers", {"X-Request-ID": custom_client_id})

        async def mock_call_next(req):
            return JSONResponse({"status": "ok"}, status_code=200)

        res = self._run(add_request_id_header(req_with_client_header, mock_call_next))
        server_id = res.headers.get("X-Request-ID")
        
        self.assertIsNotNone(server_id)
        self.assertNotEqual(server_id, custom_client_id)
        
        parsed_uuid = uuid.UUID(server_id, version=4)
        self.assertEqual(str(parsed_uuid), server_id)

    def test_05_400_response_contains_x_request_id(self):
        """Test 5: Validation HTTP 400 error response contains X-Request-ID header."""
        exc = HTTPException(status_code=400, detail="Complaint text cannot be empty")
        res = global_exception_handler(self.dummy_req, exc)
        
        self.assertEqual(res.status_code, 400)
        self.assertIn("X-Request-ID", res.headers)
        
        parsed_uuid = uuid.UUID(res.headers["X-Request-ID"], version=4)
        self.assertEqual(str(parsed_uuid), res.headers["X-Request-ID"])

    def test_06_401_response_contains_x_request_id(self):
        """Test 6: Missing admin API key HTTP 401 response contains X-Request-ID header."""
        exc = HTTPException(status_code=401, detail="Missing X-Admin-API-Key header")
        res = global_exception_handler(self.dummy_req, exc)
        
        self.assertEqual(res.status_code, 401)
        self.assertIn("X-Request-ID", res.headers)

        parsed_uuid = uuid.UUID(res.headers["X-Request-ID"], version=4)
        self.assertEqual(str(parsed_uuid), res.headers["X-Request-ID"])

    def test_07_403_response_contains_x_request_id(self):
        """Test 7: Invalid admin API key HTTP 403 response contains X-Request-ID header."""
        exc = HTTPException(status_code=403, detail="Invalid admin API key")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 403)
        self.assertIn("X-Request-ID", res.headers)

        parsed_uuid = uuid.UUID(res.headers["X-Request-ID"], version=4)
        self.assertEqual(str(parsed_uuid), res.headers["X-Request-ID"])

    def test_08_404_response_contains_x_request_id(self):
        """Test 8: Unknown complaint HTTP 404 response contains X-Request-ID header."""
        exc = HTTPException(status_code=404, detail="Complaint not found")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 404)
        self.assertIn("X-Request-ID", res.headers)

        parsed_uuid = uuid.UUID(res.headers["X-Request-ID"], version=4)
        self.assertEqual(str(parsed_uuid), res.headers["X-Request-ID"])

    def test_09_500_response_contains_x_request_id(self):
        """Test 9: Unexpected backend failure HTTP 500 response contains X-Request-ID header."""
        exc = Exception("Internal database crash")
        res = global_exception_handler(self.dummy_req, exc)

        self.assertEqual(res.status_code, 500)
        self.assertIn("X-Request-ID", res.headers)
        
        content = res.content if hasattr(res, "content") else res.__dict__
        self.assertEqual(content, {"detail": "Internal server error"})

        parsed_uuid = uuid.UUID(res.headers["X-Request-ID"], version=4)
        self.assertEqual(str(parsed_uuid), res.headers["X-Request-ID"])

    def test_10_health_503_response_contains_x_request_id(self):
        """Test 10: /health database access failure HTTP 503 response contains X-Request-ID header."""
        with patch("backend.main.get_all_complaint_records", side_effect=Exception("DB unavailable")):
            res = health_check(db_path=self.test_db_path)
            self.assertIsInstance(res, JSONResponse)
            self.assertEqual(res.status_code, 503)

            async def mock_call_next(req):
                return res

            res_mw = self._run(add_request_id_header(self.dummy_req, mock_call_next))
            self.assertIn("X-Request-ID", res_mw.headers)

            parsed_uuid = uuid.UUID(res_mw.headers["X-Request-ID"], version=4)
            self.assertEqual(str(parsed_uuid), res_mw.headers["X-Request-ID"])

    def test_11_request_id_not_present_in_json_response_bodies(self):
        """Test 11: Request ID is never returned inside JSON response bodies for 200, 400, 401, or 500."""
        req = ComplaintRequest(text="Valid student complaint text")
        res200 = analyze_complaint(req, db_path=self.test_db_path)
        self.assertNotIn("request_id", res200)
        self.assertNotIn("X-Request-ID", res200)
        self.assertNotIn("x_request_id", res200)

        exc_400 = HTTPException(status_code=400, detail="Invalid text")
        res400 = global_exception_handler(self.dummy_req, exc_400)
        content_400 = res400.content if hasattr(res400, "content") else res400.__dict__
        self.assertNotIn("request_id", content_400)
        self.assertNotIn("X-Request-ID", content_400)

        exc_500 = Exception("Crash")
        res500 = global_exception_handler(self.dummy_req, exc_500)
        content_500 = res500.content if hasattr(res500, "content") else res500.__dict__
        self.assertEqual(content_500, {"detail": "Internal server error"})
        self.assertNotIn("request_id", content_500)
        self.assertNotIn("X-Request-ID", content_500)

    def test_12_database_records_do_not_store_request_ids(self):
        """Test 12: Submitted complaint records and database schema do not receive or store request IDs."""
        req = ComplaintRequest(text="Seniors ragging freshers near hostel entrance")
        res = analyze_complaint(req, db_path=self.test_db_path)
        cid = res["complaint_id"]

        records = get_all_complaint_records(db_path=self.test_db_path)
        self.assertGreater(len(records), 0)

        rec = get_complaint_record(cid, db_path=self.test_db_path)
        self.assertIsNotNone(rec)

        self.assertNotIn("request_id", rec)
        self.assertNotIn("x_request_id", rec)
        self.assertNotIn("X-Request-ID", rec)


if __name__ == "__main__":
    unittest.main()
