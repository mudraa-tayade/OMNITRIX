"""
Unit tests for FastAPI Public Health Check Endpoint (GET /health).
Standard library unittest using isolated temporary SQLite databases.
Guarantees public availability, zero authentication requirement, and safe 200/503 status responses.
"""

import os
import shutil
import tempfile
import unittest
from unittest.mock import patch

from backend.main import (
    health_check,
    analyze_complaint,
    ComplaintRequest,
    JSONResponse
)
from backend.rate_limit import reset_rate_limiter
from backend.privacy import (
    init_database,
    DEFAULT_DB_PATH
)


class TestHealthEndpoint(unittest.TestCase):
    def setUp(self):
        reset_rate_limiter()
        self.test_dir = tempfile.mkdtemp()
        self.test_db_path = os.path.join(self.test_dir, "test_health.db")
        init_database(self.test_db_path)

    def tearDown(self):
        reset_rate_limiter()
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_01_health_check_returns_200_when_database_is_healthy(self):
        """Test 1: GET /health returns status ok and database ok when DB is available."""
        res = health_check(db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(res_dict, {
            "status": "ok",
            "database": "ok"
        })

    def test_02_health_check_response_contains_only_safe_fields(self):
        """Test 2: Health check response dictionary contains strictly 'status' and 'database' keys."""
        res = health_check(db_path=self.test_db_path)
        res_dict = res if isinstance(res, dict) else res.__dict__

        self.assertEqual(set(res_dict.keys()), {"status", "database"})

    def test_03_endpoint_does_not_require_admin_authentication(self):
        """Test 3: GET /health functions cleanly without X-Admin-API-Key or env key set."""
        with patch.dict(os.environ, {}, clear=True):
            res = health_check(db_path=self.test_db_path)
            res_dict = res if isinstance(res, dict) else res.__dict__

            self.assertEqual(res_dict["status"], "ok")
            self.assertEqual(res_dict["database"], "ok")

    def test_04_database_failure_produces_503_error_response(self):
        """Test 4: Database access failure returns HTTP 503 with status error and database unavailable."""
        with patch("backend.main.get_all_complaint_records", side_effect=Exception("Database connection error")):
            res = health_check(db_path=self.test_db_path)

            if isinstance(res, JSONResponse):
                self.assertEqual(res.status_code, 503)
                content = res.content if hasattr(res, "content") else res.__dict__
                self.assertEqual(content, {
                    "status": "error",
                    "database": "unavailable"
                })
            else:
                res_dict = res if isinstance(res, dict) else res.__dict__
                self.assertEqual(res_dict, {
                    "status": "error",
                    "database": "unavailable"
                })

    def test_05_no_complaint_data_or_pii_exposed_in_health_or_error(self):
        """Test 5: Health check never exposes complaint text, complaint IDs, PII, or internal exception details."""
        req = ComplaintRequest(text="Secret text with Rahul and phone 9876543210")
        analyze_complaint(req, db_path=self.test_db_path)

        healthy_res = health_check(db_path=self.test_db_path)
        h_str = str(healthy_res if isinstance(healthy_res, dict) else healthy_res.__dict__)
        self.assertNotIn("Rahul", h_str)
        self.assertNotIn("9876543210", h_str)
        self.assertNotIn("complaint_id", h_str)
        self.assertNotIn("protected_text", h_str)

        with patch("backend.main.get_all_complaint_records", side_effect=Exception("Internal SQL error in DB path /var/data/internal.db")):
            error_res = health_check(db_path=self.test_db_path)
            if isinstance(error_res, JSONResponse):
                e_str = str(error_res.content)
            else:
                e_str = str(error_res if isinstance(error_res, dict) else error_res.__dict__)

            self.assertNotIn("Rahul", e_str)
            self.assertNotIn("9876543210", e_str)
            self.assertNotIn("Internal SQL error", e_str)
            self.assertNotIn("/var/data/internal.db", e_str)

    def test_06_temporary_database_used(self):
        """Test 6: Verifies tests execute against temporary DB without touching DEFAULT_DB_PATH."""
        self.assertNotEqual(self.test_db_path, DEFAULT_DB_PATH)


if __name__ == "__main__":
    unittest.main()
