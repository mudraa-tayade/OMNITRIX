"""
OMNITRIX Lightweight Standalone HTTP Server
Exposes public FastAPI route handlers over standard HTTP (port 8000) using standard library http.server.
Zero external dependencies required.
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import sys

# Ensure repository root is on sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.main import (
    health_check,
    get_api_version,
    analyze_complaint,
    track_complaint,
    list_admin_complaints,
    get_admin_complaint_detail,
    modify_complaint_status,
    view_complaint_status_history,
    get_admin_summary,
    ComplaintRequest,
    ComplaintStatusUpdateRequest,
    HTTPException
)
from backend.privacy import init_database

# Ensure default admin API key is configured if unset
if not os.environ.get("OMNITRIX_ADMIN_API_KEY"):
    os.environ["OMNITRIX_ADMIN_API_KEY"] = "omnitrix-admin-key-2026"

# Initialize local SQLite database
init_database()


class OmnitrixHTTPHandler(BaseHTTPRequestHandler):

    def _set_headers(self, status_code=200):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Admin-API-Key")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    def do_GET(self):
        url_path = self.path.split("?")[0].rstrip("/")
        admin_key = self.headers.get("X-Admin-API-Key")

        if url_path in ["/health", ""]:
            res = health_check()
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode("utf-8"))
            return

        if url_path == "/api/version":
            res = get_api_version()
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode("utf-8"))
            return

        if url_path == "/api/admin/summary":
            try:
                res = get_admin_summary(x_admin_api_key=admin_key)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        if url_path == "/api/admin/complaints":
            try:
                res = list_admin_complaints(x_admin_api_key=admin_key)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        if url_path.startswith("/api/admin/complaints/") and not url_path.endswith("/history") and not url_path.endswith("/status"):
            complaint_id = url_path.replace("/api/admin/complaints/", "").strip()
            try:
                res = get_admin_complaint_detail(complaint_id, x_admin_api_key=admin_key)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        if url_path.startswith("/api/admin/complaints/") and url_path.endswith("/history"):
            complaint_id = url_path.replace("/api/admin/complaints/", "").replace("/history", "").strip()
            try:
                res = view_complaint_status_history(complaint_id, x_admin_api_key=admin_key)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        if url_path.startswith("/api/complaint/"):
            complaint_id = url_path.replace("/api/complaint/", "").strip()
            try:
                res = track_complaint(complaint_id)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        self._set_headers(404)
        self.wfile.write(json.dumps({"detail": "Not found"}).encode("utf-8"))

    def do_POST(self):
        url_path = self.path.split("?")[0].rstrip("/")

        if url_path == "/api/complaint":
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length)

            try:
                data = json.loads(post_data.decode("utf-8")) if post_data else {}
                text = data.get("text", "")
                req = ComplaintRequest(text=text)
                res = analyze_complaint(req)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        self._set_headers(404)
        self.wfile.write(json.dumps({"detail": "Not found"}).encode("utf-8"))

    def do_PATCH(self):
        url_path = self.path.split("?")[0].rstrip("/")
        admin_key = self.headers.get("X-Admin-API-Key")

        if url_path.startswith("/api/admin/complaints/") and url_path.endswith("/status"):
            complaint_id = url_path.replace("/api/admin/complaints/", "").replace("/status", "").strip()
            content_length = int(self.headers.get("Content-Length", 0))
            patch_data = self.rfile.read(content_length)

            try:
                data = json.loads(patch_data.decode("utf-8")) if patch_data else {}
                status_val = data.get("status", "")
                req = ComplaintStatusUpdateRequest(status=status_val)
                res = modify_complaint_status(complaint_id, req, x_admin_api_key=admin_key)
                self._set_headers(200)
                self.wfile.write(json.dumps(res).encode("utf-8"))
            except HTTPException as e:
                self._set_headers(e.status_code)
                self.wfile.write(json.dumps({"detail": e.detail}).encode("utf-8"))
            except Exception:
                self._set_headers(500)
                self.wfile.write(json.dumps({"detail": "Internal server error"}).encode("utf-8"))
            return

        self._set_headers(404)
        self.wfile.write(json.dumps({"detail": "Not found"}).encode("utf-8"))


def run_server(host="0.0.0.0", port=8000):
    server_address = (host, port)
    httpd = HTTPServer(server_address, OmnitrixHTTPHandler)
    print(f"OMNITRIX Backend Server running on http://{host}:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        httpd.server_close()


if __name__ == "__main__":
    run_server()

