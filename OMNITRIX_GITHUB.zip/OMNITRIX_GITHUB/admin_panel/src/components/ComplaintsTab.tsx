import React, { useState } from 'react';
import type { AdminComplaintItem } from '../types/admin';
import { Search, Filter, Lock, ExternalLink, Copy, Check } from 'lucide-react';

interface ComplaintsTabProps {
  complaints: AdminComplaintItem[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  onSelectComplaint: (complaint: AdminComplaintItem) => void;
}

export const ComplaintsTab: React.FC<ComplaintsTabProps> = ({
  complaints,
  searchTerm,
  setSearchTerm,
  onSelectComplaint
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredComplaints = complaints.filter((item) => {
    const matchesSearch = item.complaint_id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesRisk = riskFilter === 'all' || item.preliminary_risk.risk_level === riskFilter;
    return matchesSearch && matchesStatus && matchesRisk;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Privacy Guarantee Header Banner */}
      <div className="disclaimer-banner" style={{ background: 'var(--accent-blue-light)', borderColor: 'var(--accent-blue)', color: 'var(--accent-blue)' }}>
        <Lock size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Privacy Engine Active:</strong> All listed complaint data strictly consists of analytical signals and privacy-safe metadata. Raw narrative text, student identities, roll numbers, and device telemetry are omitted by design.
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '260px' }}>
          <Search
            size={16}
            style={{
              position: 'absolute',
              left: '0.85rem',
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'var(--text-muted)'
            }}
          />
          <input
            type="text"
            className="form-input"
            placeholder="Filter by Complaint ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ paddingLeft: '2.5rem' }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <Filter size={16} style={{ color: 'var(--text-muted)' }} />
          <select
            className="form-input"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ width: 'auto', padding: '0.6rem 1rem' }}
          >
            <option value="all">All Statuses</option>
            <option value="new">New</option>
            <option value="in_review">In Review</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>

          <select
            className="form-input"
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            style={{ width: 'auto', padding: '0.6rem 1rem' }}
          >
            <option value="all">All Risk Levels</option>
            <option value="low">Low Risk</option>
            <option value="medium">Medium Risk</option>
            <option value="high">High Risk</option>
            <option value="critical">Critical Risk</option>
          </select>
        </div>
      </div>

      {/* Complaints Table */}
      <div className="table-wrapper">
        {filteredComplaints.length === 0 ? (
          <div style={{ padding: '3.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
            No complaints match the current filter criteria.
          </div>
        ) : (
          <table className="custom-table">
            <thead>
              <tr>
                <th>Case ID</th>
                <th>Status</th>
                <th>Preliminary Risk</th>
                <th>Risk Score</th>
                <th>Language Hint</th>
                <th>Created At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredComplaints.map((item) => (
                <tr key={item.complaint_id} onClick={() => onSelectComplaint(item)}>
                  <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: '0.85rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span>{item.complaint_id}</span>
                      <button
                        onClick={(e) => handleCopyId(item.complaint_id, e)}
                        style={{
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          color: copiedId === item.complaint_id ? 'var(--accent-emerald)' : 'var(--text-muted)'
                        }}
                        title="Copy Complaint ID"
                      >
                        {copiedId === item.complaint_id ? <Check size={14} /> : <Copy size={14} />}
                      </button>
                    </div>
                  </td>
                  <td>
                    <span className={`badge badge-status-${item.status}`}>
                      {item.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td>
                    <span className={`badge badge-risk-${item.preliminary_risk.risk_level}`}>
                      {item.preliminary_risk.risk_level}
                    </span>
                  </td>
                  <td>
                    <span style={{ fontWeight: 700 }}>
                      {item.preliminary_risk.risk_score} / 100
                    </span>
                  </td>
                  <td style={{ textTransform: 'capitalize', color: 'var(--text-secondary)' }}>
                    {item.safe_representation?.language_hint || 'N/A'}
                  </td>
                  <td style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                    {item.created_at || 'N/A'}
                  </td>
                  <td>
                    <button
                      className="btn-secondary"
                      style={{ padding: '0.3rem 0.75rem', fontSize: '0.78rem' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectComplaint(item);
                      }}
                    >
                      <span>Inspect Case</span>
                      <ExternalLink size={12} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
