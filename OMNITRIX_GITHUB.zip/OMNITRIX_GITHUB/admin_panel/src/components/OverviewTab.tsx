import React from 'react';
import type { AdminSummaryResponse, AdminComplaintItem } from '../types/admin';
import { SafetyRadarMatrix } from './SafetyRadarMatrix';
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  ArrowUpRight,
  Activity,
  CheckCheck,
  Radio
} from 'lucide-react';

interface OverviewTabProps {
  summary: AdminSummaryResponse | null;
  complaints: AdminComplaintItem[];
  onSelectComplaint: (complaint: AdminComplaintItem) => void;
  onGoToComplaints: () => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  summary,
  complaints,
  onSelectComplaint,
  onGoToComplaints
}) => {
  if (!summary) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>
        Initializing 3D Command Environment & Safety Intelligence Matrix...
      </div>
    );
  }

  const { total_complaints, status_counts, risk_counts } = summary;

  const totalRiskCount = Math.max(
    risk_counts.low + risk_counts.medium + risk_counts.high + risk_counts.critical,
    1
  );

  const lowPct = Math.round((risk_counts.low / totalRiskCount) * 100);
  const mediumPct = Math.round((risk_counts.medium / totalRiskCount) * 100);
  const highPct = Math.round((risk_counts.high / totalRiskCount) * 100);
  const criticalPct = Math.round((risk_counts.critical / totalRiskCount) * 100);

  const activeCasesCount = status_counts.new + status_counts.in_review;
  const urgentCasesCount = risk_counts.high + risk_counts.critical;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
      {/* Main Colorful Statistics Grid */}
      <div className="stats-grid">
        <div className="stat-card blue">
          <div className="stat-icon blue">
            <FileText size={22} />
          </div>
          <div>
            <div className="stat-number">{total_complaints}</div>
            <div className="stat-title">Total Reports</div>
          </div>
        </div>

        <div className="stat-card cyan">
          <div className="stat-icon cyan">
            <Clock size={22} />
          </div>
          <div>
            <div className="stat-number">{status_counts.new}</div>
            <div className="stat-title">New Cases</div>
          </div>
        </div>

        <div className="stat-card amber">
          <div className="stat-icon amber">
            <Activity size={22} />
          </div>
          <div>
            <div className="stat-number">{status_counts.in_review}</div>
            <div className="stat-title">In Review</div>
          </div>
        </div>

        <div className="stat-card emerald">
          <div className="stat-icon emerald">
            <CheckCircle2 size={22} />
          </div>
          <div>
            <div className="stat-number">{status_counts.resolved}</div>
            <div className="stat-title">Resolved</div>
          </div>
        </div>

        <div className="stat-card rose">
          <div className="stat-icon rose">
            <AlertTriangle size={22} />
          </div>
          <div>
            <div className="stat-number">{urgentCasesCount}</div>
            <div className="stat-title">High / Critical Risk</div>
          </div>
        </div>
      </div>

      {/* Safety Pulse & Risk Overview Row */}
      <div className="grid-2">
        {/* Risk Overview Card with Ring & Luminous Bar Visualizer */}
        <div className="dashboard-card">
          <div className="card-title-row">
            <div className="card-title">
              <ShieldAlert size={20} style={{ color: 'var(--accent-amber)' }} />
              <span>Preliminary Risk Overview</span>
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              Deterministic internal heuristic
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.35rem' }}>
                <span className="badge badge-risk-low">Low Risk</span>
                <span style={{ fontWeight: 700 }}>{risk_counts.low} ({lowPct}%)</span>
              </div>
              <div style={{ height: '8px', background: 'var(--border-color)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${lowPct}%`, height: '100%', background: 'var(--accent-emerald)' }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.35rem' }}>
                <span className="badge badge-risk-medium">Medium Risk</span>
                <span style={{ fontWeight: 700 }}>{risk_counts.medium} ({mediumPct}%)</span>
              </div>
              <div style={{ height: '8px', background: 'var(--border-color)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${mediumPct}%`, height: '100%', background: 'var(--accent-amber)' }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.35rem' }}>
                <span className="badge badge-risk-high">High Risk</span>
                <span style={{ fontWeight: 700 }}>{risk_counts.high} ({highPct}%)</span>
              </div>
              <div style={{ height: '8px', background: 'var(--border-color)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${highPct}%`, height: '100%', background: '#f97316' }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.35rem' }}>
                <span className="badge badge-risk-critical">Critical Risk</span>
                <span style={{ fontWeight: 700 }}>{risk_counts.critical} ({criticalPct}%)</span>
              </div>
              <div style={{ height: '8px', background: 'var(--border-color)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${criticalPct}%`, height: '100%', background: 'var(--accent-rose)' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Safety Pulse Summary Card */}
        <div className="dashboard-card">
          <div className="card-title-row">
            <div className="card-title">
              <Radio size={20} style={{ color: 'var(--accent-cyan)' }} />
              <span>Safety Pulse Monitor</span>
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              LIVE TRIAGE MONITORING
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ padding: '1rem', background: 'var(--bg-card-hover)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Active Triage Queue</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {activeCasesCount} Cases Pending
                </div>
              </div>
              <span className="badge badge-status-new">Active</span>
            </div>

            <div style={{ padding: '1rem', background: 'var(--bg-card-hover)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Priority Escalation Count</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--accent-rose)' }}>
                  {urgentCasesCount} Immediate Focus
                </div>
              </div>
              <span className="badge badge-risk-critical">Priority</span>
            </div>

            <div style={{ padding: '1rem', background: 'var(--bg-card-hover)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Resolved & Closed Total</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--accent-emerald)' }}>
                  {status_counts.resolved + status_counts.closed} Completed
                </div>
              </div>
              <span className="badge badge-status-resolved"><CheckCheck size={12} /> Resolved</span>
            </div>
          </div>
        </div>
      </div>

      {/* Unique OMNITRIX Component — Safety Signal Analysis Matrix */}
      <SafetyRadarMatrix complaints={complaints} />

      {/* Recent Cases Table */}
      <div className="table-wrapper">
        <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 700 }}>Recent Safety Complaints</h3>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Privacy-safe case records from backend SQLite database</p>
          </div>
          <button className="btn-secondary" onClick={onGoToComplaints} style={{ fontSize: '0.85rem' }}>
            <span>View All Complaints</span>
            <ArrowUpRight size={14} />
          </button>
        </div>

        {complaints.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
            No complaint records in database.
          </div>
        ) : (
          <table className="custom-table">
            <thead>
              <tr>
                <th>Case ID</th>
                <th>Status</th>
                <th>Preliminary Risk</th>
                <th>Risk Score</th>
                <th>Created At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {complaints.slice(0, 5).map((item) => (
                <tr key={item.complaint_id} onClick={() => onSelectComplaint(item)}>
                  <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: '0.85rem' }}>
                    {item.complaint_id.slice(0, 13)}...
                  </td>
                  <td>
                    <span className={`badge badge-status-${item.status}`}>
                      {item.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td>
                    <span className={`badge badge-risk-${item.preliminary_risk.risk_level}`}>
                      {item.preliminary_risk.risk_level}
                    </span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <div style={{ width: '60px', height: '6px', background: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
                        <div
                          style={{
                            width: `${item.preliminary_risk.risk_score}%`,
                            height: '100%',
                            background: item.preliminary_risk.risk_level === 'critical' ? 'var(--accent-rose)' :
                              item.preliminary_risk.risk_level === 'high' ? '#f97316' : 'var(--accent-emerald)'
                          }}
                        />
                      </div>
                      <span style={{ fontSize: '0.8rem', fontWeight: 600 }}>
                        {item.preliminary_risk.risk_score}
                      </span>
                    </div>
                  </td>
                  <td style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                    {item.created_at || 'N/A'}
                  </td>
                  <td>
                    <button
                      className="btn-secondary"
                      style={{ padding: '0.25rem 0.6rem', fontSize: '0.78rem' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectComplaint(item);
                      }}
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
