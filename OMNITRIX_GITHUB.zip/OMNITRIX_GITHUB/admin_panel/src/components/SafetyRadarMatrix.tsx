import React from 'react';
import type { AdminComplaintItem } from '../types/admin';
import { Activity, AlertTriangle, LifeBuoy, Zap, MessageSquareWarning, ShieldCheck } from 'lucide-react';

interface SafetyRadarMatrixProps {
  complaints: AdminComplaintItem[];
}

export const SafetyRadarMatrix: React.FC<SafetyRadarMatrixProps> = ({ complaints }) => {
  // Aggregate real backend signal data
  let totalHelpSeeking = 0;
  let totalDistress = 0;
  let totalThreats = 0;
  let totalUrgency = 0;
  let totalSarcasmCoded = 0;
  let totalNegativeEmotion = 0;

  complaints.forEach((c) => {
    const rs = c.risk_signals || {};
    const ss = c.sarcasm_signals || {};

    if (rs.has_help_seeking || (rs.help_seeking_count && rs.help_seeking_count > 0)) totalHelpSeeking++;
    if ((rs.distress_keyword_count && rs.distress_keyword_count > 0)) totalDistress += rs.distress_keyword_count;
    if (rs.has_threat_language || (rs.threat_keyword_count && rs.threat_keyword_count > 0)) totalThreats++;
    if (rs.has_urgent_language || (rs.urgency_keyword_count && rs.urgency_keyword_count > 0)) totalUrgency++;
    if (ss.has_sarcasm_markers || ss.has_coded_language_markers || ss.has_indirect_distress) totalSarcasmCoded++;
    if (rs.negative_emotion_count && rs.negative_emotion_count > 0) totalNegativeEmotion += rs.negative_emotion_count;
  });

  const maxVal = Math.max(totalHelpSeeking, totalDistress, totalThreats, totalUrgency, totalSarcasmCoded, 1);

  const signalItems = [
    {
      label: 'Help-Seeking Indicators',
      count: totalHelpSeeking,
      color: 'var(--accent-blue)',
      icon: LifeBuoy,
      desc: 'Direct requests for assistance or protection'
    },
    {
      label: 'Distress Keyword Markers',
      count: totalDistress,
      color: 'var(--accent-cyan)',
      icon: Activity,
      desc: 'Anxiety, fear, or emotional distress keywords'
    },
    {
      label: 'Urgent Intervention Language',
      count: totalUrgency,
      color: 'var(--accent-amber)',
      icon: Zap,
      desc: 'Urgent phrasing requiring expedited triage'
    },
    {
      label: 'Threat & Harassment Signals',
      count: totalThreats,
      color: 'var(--accent-rose)',
      icon: AlertTriangle,
      desc: 'Physical threat or physical coercion markers'
    },
    {
      label: 'Sarcasm & Coded Language',
      count: totalSarcasmCoded,
      color: 'var(--accent-purple)',
      icon: MessageSquareWarning,
      desc: 'Indirect distress, coded phrasing, or double-meanings'
    }
  ];

  return (
    <div className="dashboard-card">
      <div className="card-title-row">
        <div className="card-title">
          <ShieldCheck size={20} style={{ color: 'var(--accent-cyan)' }} />
          <span>Safety Signal Analysis Matrix</span>
        </div>
        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>
          REAL-TIME AGGREGATE SIGNALS
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
        {signalItems.map((item, idx) => {
          const pct = Math.round((item.count / maxVal) * 100);
          const Icon = item.icon;
          return (
            <div
              key={idx}
              style={{
                background: 'var(--bg-card-hover)',
                border: '1px solid var(--border-color)',
                borderRadius: '10px',
                padding: '1rem 1.25rem'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)' }}>
                  <Icon size={16} style={{ color: item.color }} />
                  <span>{item.label}</span>
                </div>
                <span style={{ fontSize: '1.1rem', fontWeight: 800, color: item.color }}>
                  {item.count}
                </span>
              </div>

              <div style={{ height: '6px', background: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden', marginBottom: '0.4rem' }}>
                <div
                  style={{
                    width: `${pct}%`,
                    height: '100%',
                    backgroundColor: item.color,
                    transition: 'width 0.4s ease'
                  }}
                />
              </div>

              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {item.desc}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
