import React from 'react';
import { Shield, LayoutDashboard, FileText, ShieldAlert, Activity, Sun, Moon, Lock, UserCheck } from 'lucide-react';

interface SidebarProps {
  activeTab: 'overview' | 'complaints' | 'risk_monitor' | 'safety_signals';
  setActiveTab: (tab: 'overview' | 'complaints' | 'risk_monitor' | 'safety_signals') => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  theme,
  onToggleTheme
}) => {
  return (
    <aside className="sidebar">
      <div className="brand-container">
        <div className="brand-badge">
          <Shield size={22} />
        </div>
        <div>
          <div className="brand-title">OMNITRIX</div>
          <div className="brand-subtitle">Safety Intelligence</div>
        </div>
      </div>

      <nav>
        <ul className="nav-list">
          <li
            className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <LayoutDashboard size={18} />
            <span>Overview</span>
          </li>
          <li
            className={`nav-item ${activeTab === 'complaints' ? 'active' : ''}`}
            onClick={() => setActiveTab('complaints')}
          >
            <FileText size={18} />
            <span>Complaints</span>
          </li>
          <li
            className={`nav-item ${activeTab === 'risk_monitor' ? 'active' : ''}`}
            onClick={() => setActiveTab('risk_monitor')}
          >
            <ShieldAlert size={18} />
            <span>Risk Monitor</span>
          </li>
          <li
            className={`nav-item ${activeTab === 'safety_signals' ? 'active' : ''}`}
            onClick={() => setActiveTab('safety_signals')}
          >
            <Activity size={18} />
            <span>Safety Signals</span>
          </li>
        </ul>
      </nav>

      <div className="sidebar-footer">
        {/* Theme Toggle Button */}
        <button onClick={onToggleTheme} className="theme-toggle-btn" style={{ justifyContent: 'center', width: '100%' }}>
          {theme === 'dark' ? (
            <>
              <Sun size={16} style={{ color: '#fbbf24' }} />
              <span>Switch to Light Mode</span>
            </>
          ) : (
            <>
              <Moon size={16} style={{ color: '#6366f1' }} />
              <span>Switch to Dark Mode</span>
            </>
          )}
        </button>

        {/* Safety Officer Indicator */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.6rem',
            padding: '0.65rem 0.85rem',
            backgroundColor: 'var(--bg-card-hover)',
            borderRadius: '8px',
            fontSize: '0.8rem',
            color: 'var(--text-secondary)'
          }}
        >
          <UserCheck size={16} style={{ color: 'var(--accent-emerald)', flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Safety Officer</div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Session Active • Duty</div>
          </div>
        </div>

        {/* Zero-PII Guard Status */}
        <div
          style={{
            padding: '0.65rem 0.85rem',
            background: 'var(--accent-emerald-light)',
            border: '1px solid var(--accent-emerald)',
            borderRadius: '8px',
            fontSize: '0.75rem',
            color: 'var(--accent-emerald)',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}
        >
          <Lock size={14} style={{ flexShrink: 0 }} />
          <span style={{ fontWeight: 600 }}>Zero-PII Guard Active</span>
        </div>
      </div>
    </aside>
  );
};
