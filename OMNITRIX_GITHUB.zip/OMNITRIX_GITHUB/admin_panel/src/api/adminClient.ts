import type {
  AdminSummaryResponse,
  AdminComplaintItem,
  AdminComplaintDetailItem,
  ComplaintStatus,
  ComplaintHistoryResponse
} from '../types/admin';

// Relative path uses Vite dev proxy which automatically injects X-Admin-API-Key header
const BASE_URL = '';

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorMsg = `HTTP Error ${res.status}`;
    try {
      const errorData = await res.json();
      if (errorData && errorData.detail) {
        errorMsg = typeof errorData.detail === 'string' ? errorData.detail : JSON.stringify(errorData.detail);
      }
    } catch {
      // Fallback message
    }

    if (res.status === 401) {
      throw new Error('Authentication required. Backend rejected request (401).');
    } else if (res.status === 403) {
      throw new Error('Access denied (403). Invalid Admin API Key.');
    } else if (res.status === 404) {
      throw new Error('Requested resource or complaint not found (404).');
    } else if (res.status >= 500) {
      throw new Error(`Backend server error (${res.status}): ${errorMsg}`);
    }
    throw new Error(errorMsg);
  }
  return res.json();
}

export async function fetchAdminSummary(): Promise<AdminSummaryResponse> {
  const res = await fetch(`${BASE_URL}/api/admin/summary`);
  return handleResponse<AdminSummaryResponse>(res);
}

export async function fetchAdminComplaints(): Promise<AdminComplaintItem[]> {
  const res = await fetch(`${BASE_URL}/api/admin/complaints`);
  return handleResponse<AdminComplaintItem[]>(res);
}

export async function fetchAdminComplaintDetail(complaintId: string): Promise<AdminComplaintDetailItem> {
  const res = await fetch(`${BASE_URL}/api/admin/complaints/${complaintId}`);
  return handleResponse<AdminComplaintDetailItem>(res);
}

export async function updateComplaintStatus(
  complaintId: string,
  status: ComplaintStatus
): Promise<{ complaint_id: string; status: ComplaintStatus }> {
  const res = await fetch(`${BASE_URL}/api/admin/complaints/${complaintId}/status`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ status })
  });
  return handleResponse(res);
}

export async function fetchComplaintHistory(
  complaintId: string
): Promise<ComplaintHistoryResponse> {
  const res = await fetch(`${BASE_URL}/api/admin/complaints/${complaintId}/history`);
  return handleResponse<ComplaintHistoryResponse>(res);
}
