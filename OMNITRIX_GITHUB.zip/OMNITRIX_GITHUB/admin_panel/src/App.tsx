import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { OverviewTab } from './components/OverviewTab';
import { ComplaintsTab } from './components/ComplaintsTab';
import { SafetyRadarMatrix } from './components/SafetyRadarMatrix';
import { ComplaintDetailModal } from './components/ComplaintDetailModal';
import type { AdminSummaryResponse, AdminComplaintItem, ComplaintStatus } from './types/admin';
import { fetchAdminSummary, fetchAdminComplaints } from './api/adminClient';
import { AlertCircle, ShieldAlert, Activity } from 'lucide-react';

export const App: React.FC = () => {
  // Theme state with localStorage persistence
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('omnitrix-theme');
    return (saved === 'light' || saved === 'dark') ? saved : 'dark';
  });

  const [activeTab, setActiveTab] = useState<'overview' | 'complaints' | 'risk_monitor' | 'safety_signals'>('overview');
  const [searchTerm, setSearchTerm] = useState('');

  const [summary, setSummary] = useState<AdminSummaryResponse | null>(null);
  const [complaints, setComplaints] = useState<AdminComplaintItem[]>([]);
  const [selectedComplaint, setSelectedComplaint] = useState<AdminComplaintItem | null>(null);

  const [loading, setLoading] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Synchronize theme attribute on html element
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('omnitrix-theme', theme);
  }, [theme]);

  // Load backend data automatically on mount
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    setGlobalError(null);

    try {
      const [sumData, compData] = await Promise.all([
        fetchAdminSummary(),
        fetchAdminComplaints()
      ]);
      setSummary(sumData);
      setComplaints(compData);
    } catch (err: any) {
      setGlobalError(err.message || 'Failed to connect to local FastAPI backend server.');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleStatusUpdated = (updatedId: string, newStatus: ComplaintStatus) => {
    setComplaints((prev) =>
      prev.map((c) => (c.complaint_id === updatedId ? { ...c, status: newStatus } : c))
    );
    fetchAdminSummary().then(setSummary).catch(() => {});
  };

  const getPageTitle = () => {
    switch (activeTab) {
      case 'overview': return 'Safety Overview';
      case 'complaints': return 'Complaints Management';
      case 'risk_monitor': return 'Risk Monitor';
      case 'safety_signals': return 'Safety Signals Analysis';
    }
  };

  const getPageSubtitle = () => {
    switch (activeTab) {
      case 'overview': return 'Privacy-preserving aggregate overview of student safety reports';
      case 'complaints': return 'Filter and inspect privacy-safe student complaint records';
      case 'risk_monitor': return 'Deterministic preliminary risk distribution & triage monitor';
      case 'safety_signals': return 'Real-time aggregate safety signals & language indicators';
    }
  };

  return (
    <div className="app-container">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      <div className="main-content">
        <Header
          title={getPageTitle()}
          subtitle={getPageSubtitle()}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          onRefresh={loadDashboardData}
          loading={loading}
          theme={theme}
          onToggleTheme={handleToggleTheme}
        />

        <main className="page-container">
          {globalError && (
            <div
              style={{
                backgroundColor: 'var(--accent-rose-light)',
                border: '1px solid var(--accent-rose)',
                color: 'var(--accent-rose)',
                padding: '1rem 1.25rem',
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                fontWeight: 600,
                fontSize: '0.9rem'
              }}
            >
              <AlertCircle size={20} style={{ flexShrink: 0 }} />
              <span>{globalError}</span>
            </div>
          )}

          {activeTab === 'overview' && (
            <OverviewTab
              summary={summary}
              complaints={complaints}
              onSelectComplaint={(c) => setSelectedComplaint(c)}
              onGoToComplaints={() => setActiveTab('complaints')}
            />
          )}

          {activeTab === 'complaints' && (
            <ComplaintsTab
              complaints={complaints}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              onSelectComplaint={(c) => setSelectedComplaint(c)}
            />
          )}

          {activeTab === 'risk_monitor' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
              <div className="dashboard-card">
                <div className="card-title-row">
                  <div className="card-title">
                    <ShieldAlert size={20} style={{ color: 'var(--accent-amber)' }} />
                    <span>Deterministic Risk Monitor</span>
                  </div>
                </div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
                  Preliminary risk classifications are calculated directly by OMNITRIX's deterministic risk engine. All risk scores (0-100) are internal safety heuristics, not clinical diagnoses or statistical probabilities.
                </p>
                <ComplaintsTab
                  complaints={complaints.filter(c => c.preliminary_risk.risk_level === 'high' || c.preliminary_risk.risk_level === 'critical')}
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  onSelectComplaint={(c) => setSelectedComplaint(c)}
                />
              </div>
            </div>
          )}

          {activeTab === 'safety_signals' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
              <div className="dashboard-card">
                <div className="card-title-row">
                  <div className="card-title">
                    <Activity size={20} style={{ color: 'var(--accent-cyan)' }} />
                    <span>Real-Time Safety Signals Breakdown</span>
                  </div>
                </div>
                <SafetyRadarMatrix complaints={complaints} />
              </div>
            </div>
          )}
        </main>
      </div>

      {selectedComplaint && (
        <ComplaintDetailModal
          complaint={selectedComplaint}
          onClose={() => setSelectedComplaint(null)}
          onStatusUpdated={handleStatusUpdated}
        />
      )}
    </div>
  );
};

export default App;
