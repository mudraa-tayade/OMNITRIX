# OMNITRIX

**Privacy-Preserving Student Safety Intelligence System**

OMNITRIX is an end-to-end privacy-first student safety reporting and administration platform. It enables students to securely report sensitive incidents (bullying, harassment, safety risks) while providing administrators with real-time risk intelligence, encrypted record storage, and actionable safety insights.

---

## 1. Project Architecture

The system consists of three core components:
1. **Android Student App (`app/`)**: Native Android shell wrapping a offline-capable web UI asset bundle for student reporting.
2. **FastAPI Backend (`backend/`)**: Python REST API handling privacy protection (k-anonymity, noise addition, AES/Fernet zero-knowledge encryption), risk assessment, ML sentiment/sarcasm analysis, and encrypted storage.
3. **Admin Panel (`admin_panel/`)**: Modern React + TypeScript + Vite dashboard for administrators to inspect decrypted reports, triage risk scores, and manage campus safety trends.

---

## 2. Directory Structure

```
OMNITRIX_GITHUB/
├── admin_panel/            # React + TypeScript + Vite Admin Web Dashboard
│   ├── src/                # Dashboard UI components, hooks, and API clients
│   ├── index.html
│   ├── package.json
│   └── vite.config.ts
├── app/                    # Native Android Application (Gradle Project)
│   ├── src/main/assets/    # Bundled Student Web App assets
│   ├── src/main/java/      # Native Kotlin MainActivity & WebView setup
│   └── build.gradle.kts
├── backend/                # FastAPI Backend Application
│   ├── ml/models/          # Lightweight TF-IDF ML models for risk analysis
│   ├── privacy/            # Privacy engine, encryption & SQLite database logic
│   ├── main.py             # FastAPI entrypoint
│   └── requirements.txt    # Python dependencies
├── gradle/                 # Gradle Wrapper distribution files
├── build.gradle.kts        # Root Gradle build configuration
├── gradlew / gradlew.bat   # Gradle Wrapper executables
├── settings.gradle.kts     # Gradle settings
├── .env.example            # Safe template for local environment variables
└── .gitignore              # Repository exclusion rules
```

---

## 3. Backend Setup & Run

### Requirements
- Python 3.10+

### Installation
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # Linux/macOS:
   source .venv/bin/activate
   ```
3. Install required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Set up local environment variables (or create `.env` from `.env.example`):
   ```bash
   export OMNITRIX_ADMIN_API_KEY="your-local-admin-key"
   ```
5. Run the backend server:
   ```bash
   python serve.py
   # Or using uvicorn directly:
   uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

*Note: On first startup, an empty SQLite database will be automatically created under `backend/data/complaints.db`.*

---

## 4. Admin Panel Setup & Run

### Requirements
- Node.js 18+ and `npm`

### Installation & Run
1. Navigate to the `admin_panel` directory:
   ```bash
   cd admin_panel
   ```
2. Install npm packages:
   ```bash
   npm install
   ```
3. Run the development server with your local admin API key:
   ```bash
   # Windows (PowerShell):
   $env:VITE_ADMIN_API_KEY="your-local-admin-key"; npm run dev

   # Linux/macOS:
   VITE_ADMIN_API_KEY="your-local-admin-key" npm run dev
   ```
4. Open your browser at `http://localhost:5173`.

---

## 5. Android App Setup

### Requirements
- Android Studio Ladybug (or modern equivalent)
- Android SDK 34 / JDK 17

### Building & Running
1. Open the `OMNITRIX_GITHUB` root directory in Android Studio.
2. Let Gradle sync project dependencies.
3. Connect an Android device or launch an Android Virtual Device (Emulator).
4. Run the `:app` configuration to install the app.

---

## 6. How Components Connect

- **Android App to Backend**:
  - **Emulator**: Uses `http://10.0.2.2:8000` to reach the local backend.
  - **Physical Device**: Connect to the same Wi-Fi network as your backend host machine and use `http://<YOUR_LAPTOP_IP>:8000`. You can configure the API endpoint inside the student web UI settings panel.

- **Admin Panel to Backend**:
  - The Vite dev server proxies `/api` requests to `http://127.0.0.1:8000`.
  - Admin requests automatically attach the `X-Admin-API-Key` configured in `VITE_ADMIN_API_KEY`.

---

## 7. Important Privacy & Security Notes

- **Zero-Knowledge Encryption**: Complaint payloads are encrypted client-side or at the edge before storage using 256-bit AES / Fernet.
- **Differential Privacy & k-Anonymity**: Aggregated metrics enforce minimum group sizes to prevent student identification.

---

## 8. What is Intentionally NOT Included in GitHub

To keep the repository clean and secure:
- **No Local Secrets or API Keys**: Sample `.env.example` provided.
- **No Production/Testing Database Records**: Fresh database generated on launch.
- **No Built Binaries/Dependencies**: `node_modules/`, `.venv/`, `.gradle/`, `dist/`, and Android SDK/JDK distributions are omitted.
- **No Heavy Base ML Checkpoints**: Heavy Hugging Face model caches are excluded; lightweight TF-IDF models are included for immediate execution.
